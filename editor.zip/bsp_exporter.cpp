#define _CRT_SECURE_NO_WARNINGS
#include "bsp_exporter.h"
#include <vector>
#include <set>
#include <map>
#include "guidata.h"

class POINTF {
public:
    double x, y;
};

extern std::string basePath;

void outputDcByteArray(FILE* out, const std::vector<unsigned char>& arr) {
    int counti = 0;
    for (int i = 0; i < arr.size(); ++i) {
        if ((counti & 15) == 0) {
            fprintf(out, "\tdc.b $%02x", arr[i]);
        }
        else if ((counti & 15) == 15) {
            fprintf(out, ",$%02x\n", arr[i]);
        }
        else {
            fprintf(out, ",$%02x", arr[i]);
        }
        counti++;
    }
    if (((counti - 1) & 15) != 15)
        fprintf(out, "\n");
    fprintf(out, "\n");
}

bool POINT2D::equals(const SPECIALPOINT& b) {
    if (b.calcedX != x)
        return false;
    if (b.calcedY != y)
        return false;
    return true;
}

int getAddSpecialPoint(ROOM& r, int id1, int id2, double interpolate) {
    SPECIALPOINT p;
    p.id1 = id1;
    p.id2 = id2;
    int sx;
    int sy;
    int ex;
    int ey;
    if (id1 & FLAG_SPECIALPOINT) {
        sx = r.specialpoints[(id1) & (~FLAG_SPECIALPOINT)].calcedX;
        sy = r.specialpoints[(id1) & (~FLAG_SPECIALPOINT)].calcedY;
    }
    else {
        sx = r.points[id1].x;
        sy = r.points[id1].y;
    }
    if (id2 & FLAG_SPECIALPOINT) {
        ex = r.specialpoints[(id2) & (~FLAG_SPECIALPOINT)].calcedX;
        ey = r.specialpoints[(id2) & (~FLAG_SPECIALPOINT)].calcedY;
    }
    else {
        ex = r.points[id2].x;
        ey = r.points[id2].y;
    }


    interpolate *= 256.0;
    if (interpolate < 0) interpolate = 0;
    if (interpolate > 255) interpolate = 255;
    p.interpolate = (unsigned char)interpolate;
    int i = p.interpolate;
    if (p.interpolate == 255)
        i = 256;
    p.calcedX = (((ex - sx) * i) >> 8) + sx;
    p.calcedY = (((ey - sy) * i) >> 8) + sy;
    for (int i = 0; i < r.specialpoints.size(); ++i)
        if (r.specialpoints[i].equals(p))
            return i | FLAG_SPECIALPOINT;
    for (int i = 0; i < r.points.size(); ++i)
        if (r.points[i].equals(p))
            return i;
    r.specialpoints.push_back(p);
    return (r.specialpoints.size() - 1) | FLAG_SPECIALPOINT;
}

void remove(std::vector<POLY>& polysToProcess, const POLY& ply) {
    for (int i = 0; i < polysToProcess.size(); ++i) {
        if (polysToProcess[i].polyIndexHelper == ply.polyIndexHelper) {
            polysToProcess.erase(polysToProcess.begin() + i);
            return;
        }
    }
}

POINTF getStartPoint(ROOM& r, const POLY& ply) {
    POINTF ret;
    int index = ply.id_start;
    if (index & FLAG_SPECIALPOINT) {
        index &= ~FLAG_SPECIALPOINT;
        ret.x = r.specialpoints[index].calcedX;
        ret.y = r.specialpoints[index].calcedY;
    }
    else {
        ret.x = r.points[index].x;
        ret.y = r.points[index].y;
    }
    return ret;
}

POINTF getEndPoint(ROOM& r, const POLY& ply) {
    POINTF ret;
    int index = ply.id_end;
    if (index & FLAG_SPECIALPOINT) {
        index &= ~FLAG_SPECIALPOINT;
        ret.x = r.specialpoints[index].calcedX;
        ret.y = r.specialpoints[index].calcedY;
    }
    else {
        ret.x = r.points[index].x;
        ret.y = r.points[index].y;
    }
    return ret;
}

PLANE generatePlane(ROOM& r, const POLY& ply) {
    if (ply.polyType == POLYTYPE_BILLBOARD)
        return PLANE();
    POINTF sp = getStartPoint(r, ply);
    POINTF ep = getEndPoint(r, ply);
    PLANE ret;
    double dx = ep.x - sp.x;
    double dy = ep.y - sp.y;
    double l = dx * dx + dy * dy;
    if (l != 0.0)
        l = sqrt(l);
    ret.nx = (dy / l) * 0x7f;
    ret.ny = (-dx / l) * 0x7f;

    //int margin = 8;
    //int kx = ret.nx / (0x7f - margin);
    //int ky = ret.ny / (0x7f - margin);
    //int lx = ret.nx / margin;
    //int ly = ret.ny / margin;
    //// i hope this doesn't produce problems, we fix normals to rectangular normals by a margin here
    //if ((kx != 0 && ly == 0)) {
    //    ret.nx = kx * 0x7f;
    //    ret.ny = 0;
    //}
    //if ((ky != 0 && lx == 0)) {
    //    ret.nx = 0;
    //    ret.ny = ky * 0x7f;
    //}

    ret.px = (sp.x + ep.x) * 0.5;
    ret.py = (sp.y + ep.y) * 0.5;
    return ret;
}

int generateHeight(ROOM& r, const POLY& ply) {
    if (ply.polyType == POLYTYPE_BILLBOARD)
        return 0;
    int ret = 0;
    if (ply.stalagmite)
        ret = ply.top;
    return ret;
}

double planeDist1(ROOM& r, const PLANE& plane, const BSP* bsp) {
    POINTF p = getStartPoint(r, r.polies[bsp->polyIndex[0]]);
    if (r.polies[bsp->polyIndex[0]].polyType == POLYTYPE_BILLBOARD) {
        p.x = r.points[r.polies[bsp->polyIndex[0]].id_start].x;
        p.y = r.points[r.polies[bsp->polyIndex[0]].id_start].y;
    }
    float xp = p.x;
    float yp = p.y;
    float xd = xp - plane.px;
    float yd = yp - plane.py;
    return (xd * plane.nx + yd * plane.ny);
}

double planeDist2(ROOM& r, const PLANE& plane, const BSP* bsp) {
    if (r.polies[bsp->polyIndex[0]].polyType == POLYTYPE_BILLBOARD)
        return planeDist1(r, plane, bsp);
    POINTF p = getEndPoint(r, r.polies[bsp->polyIndex[0]]);
    float xp = p.x;
    float yp = p.y;
    float xd = xp - plane.px;
    float yd = yp - plane.py;
    return (xd * plane.nx + yd * plane.ny);
}

bool isInFrontOfPlane1(ROOM& r, const PLANE& plane, const BSP* bsp) {
    return planeDist1(r, plane, bsp) >= 0;
}

bool isInFrontOfPlane2(ROOM& r, const PLANE& plane, const BSP* bsp) {
    return planeDist2(r, plane, bsp) >= 0;
}

bool isParallelPlane(const PLANE& plane) {
    if (plane.nx == 0) {
        if (abs(plane.ny) == 0x7f)
            return true;
    }
    if (plane.ny == 0) {
        if (abs(plane.nx) == 0x7f)
            return true;
    }
    return false;
}

BSP* selectGoodPlaneAndPop(ROOM& r, std::vector<BSP*>& allToProcess) {

    // search a plane which doesn't divide too many polies
    int bestI = 0;
    int bestScore = -1;
    std::vector<int> scores;
    for (int i = 0; i < allToProcess.size(); ++i) {
        BSP* checkPlane1 = allToProcess[i];
        if (r.polies[checkPlane1->polyIndex[0]].polyType == POLYTYPE_BILLBOARD) {
            scores.push_back(1000000);
            continue; // no plane possible with this
        }
        if (r.polies[checkPlane1->polyIndex[0]].polyType == POLYTYPE_PORTAL) {
            //scores.push_back(0);
            //continue; // no plane possible with this
        }
        int score = 0;
        for (int j = 0; j < allToProcess.size(); ++j) {
            BSP* checkPlane2 = allToProcess[j];
            bool f1 = isInFrontOfPlane1(r, checkPlane1->plane, checkPlane2);
            bool f2 = isInFrontOfPlane2(r, checkPlane1->plane, checkPlane2);
            if (f1 != f2)
                score++;
        }
        scores.push_back(score);
        if (bestScore < 0)
            bestScore = score;
        if (score < bestScore) {
            bestScore = score;
            bestI = i;
        }
    }
    std::vector<int> theOnesWithTheBestScores;
    for (int i = 0; i < allToProcess.size(); ++i) {
        if (scores[i] == bestScore) {
            theOnesWithTheBestScores.push_back(i);
        }
    }
    int lastBestDifference = 10000;
    for (int i = 0; i < theOnesWithTheBestScores.size(); ++i) {
        BSP* checkPlane1 = allToProcess[theOnesWithTheBestScores[i]];
        if (isParallelPlane(checkPlane1->plane)) {
            int leftScore = 0;
            int rightScore = 0;
            for (int j = 0; j < allToProcess.size(); ++j) {
                BSP* checkPlane2 = allToProcess[j];
                bool f1 = isInFrontOfPlane1(r, checkPlane1->plane, checkPlane2);
                if (f1)
                    leftScore++;
                if (!f1)
                    rightScore++;
            }
            int difference = abs(leftScore - rightScore); // for a balanced tree
            if (difference < lastBestDifference) {
                lastBestDifference = difference;
                bestI = theOnesWithTheBestScores[i];
            }
        }
        if (r.polies[checkPlane1->polyIndex[0]].polyType == POLYTYPE_PORTAL) {
            bestI = theOnesWithTheBestScores[i];
            break; // favor portals for splitting
        }
    }

    BSP* node = allToProcess[bestI];
    allToProcess.erase(allToProcess.begin() + bestI);
    return node;
}

bool isPolyValid(ROOM& r, POLY& ply) {
    POINTF s = getStartPoint(r, ply);
    POINTF e = getEndPoint(r, ply);
    double dx = s.x - e.x;
    double dy = s.y - e.y;
    double d = sqrt(dx * dx + dy * dy);
    if (d < 50) // prevent too small polies to happen
        return false;
    return true;
}

bool allBildboardsAndAdd(ROOM& r, BSP* node, std::vector<BSP*> &allToProcess) {
    bool allAreBillBoards = true;
    for (int i = 0; i < allToProcess.size(); ++i) {
        if (allToProcess[i]->polyIndex.size() != 1) {
            while (1);
        }
        int a = allToProcess[i]->polyIndex[0];
        if (r.polies[a].polyType != POLYTYPE_BILLBOARD) {
            allAreBillBoards = false;
            break;
        }
    }
    if (allAreBillBoards) {
        for (int i = 0; i < allToProcess.size(); ++i) {
            int a = allToProcess[i]->polyIndex[0];
            node->polyIndex.push_back(a);
        }
        return true;
    }
    return false;
}
// e4cd,e347
void addAllPolysWithSamePlaneAndRemove(ROOM& r, std::vector<BSP*>& allToProcess, BSP* tree) {
    POLY p1 = r.polies[tree->polyIndex[0]];
    PLANE plane1 = tree->plane;
    for (int i = allToProcess.size() - 1; i >= 0; --i) {
        if (allToProcess[i]->polyIndex.size() == 1) {
            POLY p2 = r.polies[allToProcess[i]->polyIndex[0]];
            PLANE plane2 = generatePlane(r, p2);
            if (plane2.equals(plane1)) {
                tree->polyIndex.push_back(allToProcess[i]->polyIndex[0]);
                allToProcess.erase(allToProcess.begin() + i);
            }
        }
    }
}

void bspInsert(ROOM& r, BSP* parent, BSP* tree, std::vector<BSP*> allToProcess) {

    if (allBildboardsAndAdd(r, tree, allToProcess)) {
        return;
    }
    
    BSP* node = nullptr;
    node = selectGoodPlaneAndPop(r, allToProcess);
    tree->plane = node->plane;
    tree->height = node->height;
    tree->roomNr = node->roomNr;
    tree->polyIndex = node->polyIndex;
    // left, right = nullptr here
    addAllPolysWithSamePlaneAndRemove(r, allToProcess, tree);

    std::vector<BSP*> left;
    std::vector<BSP*> right;
    for (auto&& a : allToProcess) {
        double dist1 = planeDist1(r, tree->plane, a);
        double dist2 = planeDist2(r, tree->plane, a);
        if (dist1 == 0 && dist2 == 0) {
            // coplanar
            if (a->polyIndex.size() != 1) {
                int debug = 1;
                while (1);
            }
            tree->polyIndex.push_back(a->polyIndex[0]);
            continue;
        }
        bool f1 = isInFrontOfPlane1(r, tree->plane, a);
        bool f2 = isInFrontOfPlane2(r, tree->plane, a);
        if (dist1 == 0) {
            f1 = f2;
        }
        if (dist2 == 0) {
            f2 = f1;
        }
        if (f1 == f2) {
            if (f1)
                left.push_back(a);
            else
                right.push_back(a);
        }
        else {
            if (a->polyIndex.size() != 1) {
                int debug = 1;
                while (1);
            }
            if (r.polies[a->polyIndex[0]].polyType == POLYTYPE_BILLBOARD)
                while (1);
            bool split = true;
            if (!split) {
                tree->polyIndex.push_back(a->polyIndex[0]);
            }
            else {
                double dist = abs(dist1) + abs(dist2);
                double factor = abs(dist1) / dist;

                int id1 = r.polies[a->polyIndex[0]].id_start;
                int id2 = r.polies[a->polyIndex[0]].id_end;

                int specialPoint = getAddSpecialPoint(r, id1, id2, factor);
                POLY poly = r.polies[a->polyIndex[0]];
                POLY poly1 = poly;
                POLY poly2 = poly;
                poly1.id_end = specialPoint;
                poly2.id_start = specialPoint;
                const double tx = (double)(poly.tx_end - poly.tx_start) * factor + poly.tx_start;
                poly1.tx_end = tx;
                poly2.tx_start = tx;
                poly2.hasWhiteStartLine = false;
                bool polyValid1 = isPolyValid(r, poly1);
                bool polyValid2 = isPolyValid(r, poly2);

                if (!polyValid1) {
                    poly2.id_start = poly.id_start;
                    poly2.tx_start = poly.tx_start;
                }
                if (!polyValid2) {
                    poly1.id_end = poly.id_end;
                    poly1.tx_end = poly.tx_end;
                }

                if (polyValid1) {
                    int index = r.polies.size();
                    r.polies.push_back(poly1);
                    BSP* bsp = new BSP();
                    bsp->plane = generatePlane(r, poly1);
                    bsp->height = a->height;
                    bsp->roomNr = a->roomNr;
                    if (poly1.id_end != id2) // in case it's the same poly we use it only as splitting plane
                        bsp->polyIndex.push_back(index);
                    else {
                        r.polies.pop_back();
                        bsp->polyIndex.push_back(a->polyIndex[0]);
                    }
                    if (f1)
                        left.push_back(bsp);
                    else
                        right.push_back(bsp);
                }
                if (polyValid2) {
                    int index = r.polies.size();
                    r.polies.push_back(poly2);
                    BSP* bsp = new BSP();
                    bsp->plane = generatePlane(r, poly2);
                    bsp->height = a->height;
                    bsp->roomNr = a->roomNr;
                    if (poly2.id_start != id1) // in case it's the same poly we use it only as splitting plane
                        bsp->polyIndex.push_back(index);
                    else {
                        r.polies.pop_back();
                        bsp->polyIndex.push_back(a->polyIndex[0]);
                    }
                    if (!f1)
                        left.push_back(bsp);
                    else
                        right.push_back(bsp);
                }
            }
        }
    }

    if (!left.empty()) {
        tree->left = new BSP();
        bspInsert(r, tree, tree->left, left);
    }
    if (!right.empty()) {
        tree->right = new BSP();
        bspInsert(r, tree, tree->right, right);
    }
}

BSP* buildBsp(ROOM& r) {
    if (r.polies.empty())
        return nullptr;
    for (int i = 0; i < r.polies.size(); ++i) {
        r.polies[i].polyIndexHelper = i;
    }
    std::vector<BSP*> bspToAdd;
    for (auto&& p : r.polies) {
        BSP* b = new BSP();
        b->plane = generatePlane(r, p);
        b->height = generateHeight(r, p);
        b->roomNr = p.roomNr;
        b->polyIndex.push_back(p.polyIndexHelper);
        bspToAdd.push_back(b);
    }
    BSP* tree = new BSP();
    bspInsert(r, nullptr, tree, bspToAdd);
    return tree;
}

std::vector<BSP*> flattenBsp(BSP* bsp) {
    std::vector<BSP*> ret;
    std::vector<BSP*> list;
    std::set<BSP*> alreadyProcessed;
    list.push_back(bsp);
    while (!list.empty()) {
        BSP* here = list[0];
        ret.push_back(here);
        alreadyProcessed.insert(here);
        list.erase(list.begin());
        if (here->left != nullptr && alreadyProcessed.find(here->left) == alreadyProcessed.end())
            list.push_back(here->left);
        if (here->right != nullptr && alreadyProcessed.find(here->right) == alreadyProcessed.end())
            list.push_back(here->right);
    }
    for (int i = 0; i < ret.size(); ++i) {
        for (int j = 0; j < ret.size(); ++j) {
            if (ret[i]->left == ret[j]) {
                if (i == j) {
                    int debug = 1;
                }
                ret[i]->computedLeftArrayIndex = j;
            }
            if (ret[i]->right == ret[j]) {
                if (i == j) {
                    int debug = 1;
                }
                ret[i]->computedRightArrayIndex = j;
            }
        }
    }
    return ret;
}

std::vector<BSP*> toFlatBSP(ROOM& r) {
    return flattenBsp(buildBsp(r));
}

double convertHeight(GuiData *data, double h) {
    return data->scene.floorHeight - h;
}

POLY makeSpanPolyFromXPoly(GuiData* data, const GuiData::XPoly& s, bool floor, bool flipDirection = false, int originalPolyId = -1) {
    POLY p;
    p.id_start = flipDirection ? s.id1 : s.id2;
    p.id_end = flipDirection ? s.id2 : s.id1;
    p.top = convertHeight(data, floor ? s.floor_up : s.ceiling_up);
    p.bottom = convertHeight(data, floor ? s.floor_down : s.ceiling_down);
    p.topColor = (floor ? s.floor_color_up : s.ceiling_color_up) & 3;
    p.bottomColor = (floor ? s.floor_color_down : s.ceiling_color_down) & 3;
    if (floor) {
        p.tx_start = (!flipDirection ? s.floor_tx1 : s.floor_tx2) * 256 * data->textureWidth(s.textureFloor);
        p.tx_end = (!flipDirection ? s.floor_tx2 : s.floor_tx1) * 256 * data->textureWidth(s.textureFloor);
    }
    else {
        p.tx_start = (!flipDirection ? s.ceiling_tx1 : s.ceiling_tx2) * 256 * data->textureWidth(s.textureCeiling);
        p.tx_end = (!flipDirection ? s.ceiling_tx2 : s.ceiling_tx1) * 256 * data->textureWidth(s.textureCeiling);
    }
    p.stalagmite = floor;
    p.texture = floor ? s.textureFloor : s.textureCeiling;
    p.polyType = POLYTYPE_SPAN;
    p.hasWhiteStartLine = floor ? s.floor_has_start_white_line : s.ceiling_has_start_white_line;
    p.floorWithBillboardTransparencies = floor ? s.floorWithTransparencies : false;
    p.isTopAColorCorrectSpan = floor ? (s.hasFloor ?  s.floor_color_backface_span : false) : false;
    p.isBottomAColorCorrectSpan = floor ? false : (s.hasCeiling ? s.ceiling_color_backface_span : false);
    p.roomNr = s.roomNr;
    p.doubleSided = floor ? s.floorDoubleSided : s.ceilingDoubleSided;
    p.modifierId = floor ? (s.hasModifier ? s.modifierId : -1) : -1;
    p.isFloorDoor = floor ? s.isFloorDoor : false;
    p.originalId1 = s.id1;
    p.originalId2 = s.id2;
    p.originalPolyId = originalPolyId;
    return p;
}

ROOM toRoom(GuiData* data) {
    ROOM r;

    for (int i = 0; i < data->scene.points.size(); ++i) {
        GuiData::XPoint s = data->scene.points[i];
        POINT2D p = { (short)+s.x,(short)-s.y };
        r.points.push_back(p);
    }

    for (int i = 0; i < data->scene.polys.size(); ++i) {
        GuiData::XPoly s = data->scene.polys[i];
        if (s.portal) {
            {
                if (s.portalWithSpan && s.hasCeiling) {
                    POLY p = makeSpanPolyFromXPoly(data, s, false, s.ceilingNormalFlipped, i);
                    r.polies.push_back(p);
                }
                POLY p = makeSpanPolyFromXPoly(data, s, true, false, i);
                //p.stalagmite = false;
                p.polyType = (s.portalWithSpan && s.hasFloor) ? POLYTYPE_PORTAL_WITH_SPAN : POLYTYPE_PORTAL;
                p.roomNr = s.roomNr;
                p.portalRoomNr = s.portalRoomNrBack;
                r.polies.push_back(p);
                // some safe area behind the portal
                //PLANE pl = generatePlane(r, p);
                //POINT2D p1 = r.points[p.id_start];
                //POINT2D p2 = r.points[p.id_end];
                //p1.x -= pl.nx;
                //p1.y -= pl.ny;
                //p2.x -= pl.nx;
                //p2.y -= pl.ny;
                //p1.x = (p1.x + p2.x) * 0.5;
                //p1.y = (p1.y + p2.y) * 0.5;
                //int pid1 = r.points.size(); r.points.push_back(p1);
                //POLY q = p;
                //q.polyType = POLYTYPE_SEPERATOR;
                //q.stalagmite = true;
                //q.top = p.bottom;
                //q.bottom = p.bottom;
                //q.id_start = p.id_start; q.id_end = pid1; r.polies.push_back(q);
                //q.id_start = pid1; q.id_end = p.id_end; r.polies.push_back(q);
            }
            //{
            //    POLY p = makeSpanPolyFromXPoly(data, s, true, true);
            //    p.polyType = (s.portalWithSpan && s.hasFloor) ? POLYTYPE_PORTAL_WITH_SPAN : POLYTYPE_PORTAL;
            //    p.roomNr = s.portalRoomNrBack;
            //    p.portalRoomNr = s.roomNr;
            //    r.polies.push_back(p);
            //    if (s.hasCeiling) {
            //        POLY p = makeSpanPolyFromXPoly(data, s, false, !s.ceilingNormalFlipped);
            //        p.roomNr = s.portalRoomNrBack;
            //        r.polies.push_back(p);
            //    }
            //}
        }
        else {
            if (s.hasCeiling) {
                POLY p = makeSpanPolyFromXPoly(data, s, false, s.ceilingNormalFlipped, i);
                r.polies.push_back(p);
            }
            if (s.hasFloor) {
                POLY p = makeSpanPolyFromXPoly(data, s, true, false, i);
                r.polies.push_back(p);
            }
        }
    }
    for (int i = 0; i < data->scene.billboards.size(); ++i) {
        GuiData::XBillBoard s = data->scene.billboards[i];
        POLY p;
        p.id_start = s.id;
        p.texture = s.texture;
        p.bottom = convertHeight(data, s.ground);
        p.top = convertHeight(data, s.ground+s.height);
        if (s.ceilingBillboard) {
            p.top = convertHeight(data, s.ground);
            p.bottom = convertHeight(data, s.ground-s.height);
        }
        p.billBoardWidth = s.width;
        p.stalagmite = !s.ceilingBillboard;
        p.polyType = POLYTYPE_BILLBOARD;
        p.hasWhiteStartLine = false;
        p.topColor = s.colorUp;
        p.bottomColor = s.colorDown;
        p.roomNr = s.roomNr;
        p.modifierId = s.hasModifier ? (s.modifierId >= 0 ? s.modifierId: 0xff) : 0xff;
        p.originalId1 = s.id;
        p.originalId2 = s.id;
        p.originalPolyId = i;
        r.polies.push_back(p);
    }
    for (int i = 0; i < data->scene.rectangles.size(); ++i) {
        GuiData::XRect s = data->scene.rectangles[i];
        if (s.enabled) {
            RECT p;
            POLY tempPly;
            tempPly.id_start = s.id2;
            tempPly.id_end = s.id1;
            PLANE pl = generatePlane(r, tempPly);
            POINT2D k1 = r.points[s.id2];
            POINT2D k2 = r.points[s.id1];
            if (k1.x > k2.x) {
                double t = k1.x;
                k1.x = k2.x;
                k2.x = t;
            }
            if (k1.y > k2.y) {
                double t = k1.y;
                k1.y = k2.y;
                k2.y = t;
            }
            k1.x -= s.expandX;
            k1.y -= s.expandY;
            k2.x += s.expandX;
            k2.y += s.expandY;
            p.x0 = k1.x;
            p.y0 = k1.y;
            p.x1 = k2.x;
            p.y1 = k2.y;
            p.type = s.switchType;
            p.roomNr = s.roomNr;
            p.portalRoomNrBack = s.portalRoomNrBack;
            p.specialValue = s.switchNr;
            p.nx = pl.nx;
            p.ny = pl.ny;
            p.px = pl.px;
            p.py = pl.py;
            r.rectangles.push_back(p);
        }
    }
    return r;
}

std::vector<BSP*> toFlatBSP(GuiData* data) {
    ROOM r = toRoom(data);
    return flattenBsp(buildBsp(r));
}

int exportRoom(ROOM& r, const std::string& outputFile, const std::string& roomName) {
    std::vector<BSP*> flatBsp = toFlatBSP(r);
    r.bsp = flatBsp;
    int combinedPolyIndexMarker = r.polies.size();
    FILE* out;
    out = fopen((basePath + outputFile).c_str(), "w");
    int byteSize = 0;
    fprintf(out, ";--- ROOM FILE <%s>---\n", roomName.c_str());
    fprintf(out, "\n");
    fprintf(out, "ROOMDESC_%s\n", roomName.c_str());
    fprintf(out, "\tdc.w %d,%d ; room center (not used yet)\n", 0, 0); byteSize += 2*2;
    fprintf(out, "\tdc.w $%04x ; room point count\n", r.points.size() + r.specialpoints.size()); byteSize += 2;
    fprintf(out, "\tdc.w ROOMPOINTS_%s ; points\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w $%04x ; room poly count\n", r.polies.size()); byteSize += 2;
    fprintf(out, "\tdc.w ROOMPOLIES_%s ; points\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_LEFTNODE_%s ; bspnode->left\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_RIGHTNODE_%s ; bspnode->right\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_POLYNR_%s ; bspnode->polyIndex\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_PLANENX_%s ; bspnode->planeNormalX\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_PLANENY_%s ; bspnode->planeNormalY\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_PLANEPX_LO_%s ; bspnode->planeOrigX\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_PLANEPY_LO_%s ; bspnode->planeOrigY\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_PLANEPX_HI_%s ; bspnode->planeOrigX\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w FLATBSP_PLANEPY_HI_%s ; bspnode->planeOrigY\n", roomName.c_str()); byteSize += 2;
    //fprintf(out, "\tdc.w FLATBSP_HEIGHT_%s ; bspnode->height\n", roomName.c_str());
    fprintf(out, "\tdc.w COMBINED_POLYLIST_%s ; if more than one poly is connected to a node\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.w RECTANGLELIST_%s ; rectangles\n", roomName.c_str()); byteSize += 2;
    fprintf(out, "\tdc.b $%02x; polyindex marker for start of combined polylist\n", combinedPolyIndexMarker); byteSize += 1;
    fprintf(out, "ROOMPOINTS_%s ; x, y\n", roomName.c_str());
    const char* pointLabels[] = {
        "; xlo\n",
        "; xhi\n",
        "; ylo\n",
        "; yhi\n",
    };
    for (int j = 0; j < 4; ++j) {
        fprintf(out, "%s", pointLabels[j]);
        for (int i = 0; i < r.points.size() + r.specialpoints.size(); ++i) {
            int px = 0;
            int py = 0;
            if (i < r.points.size()) {
                px = r.points[i].x;
                py = r.points[i].y;
            }
            else {
                if (i == r.points.size()) {
                    fprintf(out, "\t\t;specialPoints\n");
                }
                px = r.specialpoints[i - r.points.size()].calcedX;
                py = r.specialpoints[i - r.points.size()].calcedY;
            }
            switch (j) {
            case 0:
                fprintf(out, "\tdc.b $%02x; <%d> <%d,%d>\n", px & 255, i, px, py);
                break;
            case 1:
                fprintf(out, "\tdc.b $%02x; <%d> <%d,%d>\n", (px >> 8) & 255, i, px, py);
                break;
            case 2:
                fprintf(out, "\tdc.b $%02x; <%d> <%d,%d>\n", py & 255, i, px, py);
                break;
            case 3:
                fprintf(out, "\tdc.b $%02x; <%d> <%d,%d>\n", (py >> 8) & 255, i, px, py);
                break;
            }
            byteSize++;
        }
    }
    fprintf(out, "ROOMPOLIES_%s ; point1, point2, texture, texture start, texture end, topy, bottomy, flags, portalroom\n", roomName.c_str());
    for (int i = 0; i < r.polies.size(); ++i) {
        const POLY& p = r.polies[i];
        int tColor = r.polies[i].topColor;
        int bColor = r.polies[i].bottomColor;

        int point1 = p.id_start;
        int point2 = p.id_end;
        if (point1 & FLAG_SPECIALPOINT) {
            point1 &= ~FLAG_SPECIALPOINT;
            point1 += r.points.size();
        }
        if (point2 & FLAG_SPECIALPOINT) {
            point2 &= ~FLAG_SPECIALPOINT;
            point2 += r.points.size();
        }
        switch (p.polyType) {
        case POLYTYPE_PORTAL_WITH_SPAN:
        case POLYTYPE_PORTAL:
        case POLYTYPE_SPAN: {
            std::string flags;
            if (p.hasWhiteStartLine)
                flags += "|POLYFLAG_WHITELINE";
            if (p.isBottomAColorCorrectSpan)
                flags += "|POLYFLAG_COLOR_CORRECTION_SPAN_DOWN";
            if (p.isTopAColorCorrectSpan)
                flags += "|POLYFLAG_COLOR_CORRECTION_SPAN_UP";
            if (p.stalagmite)
                flags += "|POLYFLAG_STALAGMITE";
            std::string flags2;
            if (p.floorWithBillboardTransparencies)
                flags2 += "|POLYFLAG2_BILLBOARDTRANSPARENCIES";
            if (p.doubleSided)
                flags2 += "|POLYFLAG2_DOUBLESIDED";
            if (p.isFloorDoor)
                flags2 += "|POLYFLAG2_FLOORDOOR";
            std::string polyType = "POLYTYPE_SPAN";
            if (p.polyType == POLYTYPE_PORTAL) polyType = "POLYTYPE_PORTAL";
            if (p.polyType == POLYTYPE_PORTAL_WITH_SPAN) polyType = "POLYTYPE_PORTAL_WITH_SPAN";
            int modifierId = p.modifierId == -1 ? 0xff : p.modifierId;
            fprintf(out, "\tdc.b %s, %d, %d, %d, [%d] & 255, [%d>>8] & 255, [%d>>16] & 255, [%d] & 255, [%d>>8] & 255, [%d>>16] & 255, %d, %d, [[[%d & 3]<<2]|[%d & 3]<<0]%s, %d, $00%s, %d; <%d,<orig:%d,origp1:%d,origp2:%d>>\n", polyType.c_str(),point1, point2, p.texture, p.tx_start, p.tx_start, p.tx_start, p.tx_end, p.tx_end, p.tx_end, p.top, p.bottom, tColor, bColor, flags.c_str(), p.portalRoomNr, flags2.c_str(), modifierId, i, p.originalPolyId, p.originalId1, p.originalId2);
            break;
        }
        case POLYTYPE_SEPERATOR: {
            fprintf(out, "\tdc.b POLYTYPE_SEPERATOR, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ; <%d,<orig:%d,origp1:%d,origp2:%d>>\n", i, p.originalPolyId, p.originalId1, p.originalId2);
            break;
        }
        case POLYTYPE_BILLBOARD: {
            std::string flags;
            if (p.stalagmite)
                flags += "|POLYFLAG_STALAGMITE";
            fprintf(out, "\tdc.b POLYTYPE_BILLBOARD, %d, %d, %d, %d, %d,[[[%d & 3]<<2]|[%d & 3]<<0]%s,%d,0,0,0,0,0,0,0,0 ; <%d,<orig:%d,origp1:%d,origp2:%d>>\n", point1, p.billBoardWidth, p.top, p.bottom, p.texture, tColor, bColor, flags.c_str(), p.modifierId, p.originalPolyId, p.originalId1, p.originalId2);
            break;
        }
        }
        byteSize += 16;
    }

    std::map<int, int> toFullRoomPolyList;
    std::vector<unsigned char> fullRoomPolyList;
    int lastAccess = 0;
    int lastlastAccess = 0;
    for (int i = 0; i < flatBsp.size(); ++i) {
        if (flatBsp[i]->polyIndex.size() > 1) {
            toFullRoomPolyList.insert(std::make_pair(i, fullRoomPolyList.size()));
            for (int j = 0; j < flatBsp[i]->polyIndex.size(); ++j) {
                int polyIndex = flatBsp[i]->polyIndex[j];
                fullRoomPolyList.push_back(polyIndex);
                if (j == flatBsp[i]->polyIndex.size() - 1) {
                    lastlastAccess = lastAccess + 1;
                    lastAccess = fullRoomPolyList.size();
                    fullRoomPolyList.push_back(0xff);
                }
            }
        }
    }
    int lastAccessIndex = combinedPolyIndexMarker + lastlastAccess;
    if (lastAccessIndex > 254) {
        while (1);
    }
    fprintf(out, "COMBINED_POLYLIST_%s ; count:%d index:%d lastaccessindex<not above 254>:%d if more than one poly is connected to a node\n", roomName.c_str(), fullRoomPolyList.size(), combinedPolyIndexMarker, lastAccessIndex);
    

    outputDcByteArray(out, fullRoomPolyList); byteSize += fullRoomPolyList.size();
    std::vector<unsigned char> bspLeftNode;
    std::vector<unsigned char> bspRightNode;
    std::vector<unsigned char> bspPolyNr;
    std::vector<unsigned char> bspPlaneNX;
    std::vector<unsigned char> bspPlaneNY;
    std::vector<unsigned char> bspPlanePX_LO;
    std::vector<unsigned char> bspPlanePY_LO;
    std::vector<unsigned char> bspPlanePX_HI;
    std::vector<unsigned char> bspPlanePY_HI;
    std::vector<unsigned char> bspPlaneHeight;
    for (int i = 0; i < flatBsp.size(); ++i) {
        bspLeftNode.push_back(flatBsp[i]->computedLeftArrayIndex);
        bspRightNode.push_back(flatBsp[i]->computedRightArrayIndex);
        int poly = 0xff;
        if (!flatBsp[i]->polyIndex.empty()) {
            poly = flatBsp[i]->polyIndex[0];
            if (flatBsp[i]->polyIndex.size() > 1) {
                poly = toFullRoomPolyList[i] + combinedPolyIndexMarker;
            }
        }
        bspPolyNr.push_back(poly);
        bspPlaneNX.push_back(flatBsp[i]->plane.nx & 255);
        bspPlaneNY.push_back(flatBsp[i]->plane.ny & 255);
        bspPlanePX_LO.push_back((flatBsp[i]->plane.px) & 255);
        bspPlanePY_LO.push_back((flatBsp[i]->plane.py) & 255);
        bspPlanePX_HI.push_back(((flatBsp[i]->plane.px) >> 8) & 255);
        bspPlanePY_HI.push_back(((flatBsp[i]->plane.py) >> 8) & 255);
        bspPlaneHeight.push_back((flatBsp[i]->height) & 255);
    }
    fprintf(out, ";BSPTREE:\n");
    fprintf(out, "\n");
    fprintf(out, "FLATBSP_LEFTNODE_%s ; bspnode->left\n", roomName.c_str());
    outputDcByteArray(out, bspLeftNode); byteSize += bspLeftNode.size();
    fprintf(out, "FLATBSP_RIGHTNODE_%s ; bspnode->right\n", roomName.c_str());
    outputDcByteArray(out, bspRightNode); byteSize += bspRightNode.size();
    fprintf(out, "FLATBSP_POLYNR_%s ; bspnode->polyIndex\n", roomName.c_str());
    outputDcByteArray(out, bspPolyNr); byteSize += bspPolyNr.size();
    fprintf(out, "FLATBSP_PLANENX_%s ; bspnode->planeNormalX\n", roomName.c_str());
    outputDcByteArray(out, bspPlaneNX);  byteSize += bspPlaneNX.size();
    fprintf(out, "FLATBSP_PLANENY_%s ; bspnode->planeNormalY\n", roomName.c_str());
    outputDcByteArray(out, bspPlaneNY);  byteSize += bspPlaneNY.size();
    fprintf(out, "FLATBSP_PLANEPX_LO_%s ; bspnode->planeOrigX\n", roomName.c_str());
    outputDcByteArray(out, bspPlanePX_LO); byteSize += bspPlanePX_LO.size();
    fprintf(out, "FLATBSP_PLANEPY_LO_%s ; bspnode->planeOrigY\n", roomName.c_str());
    outputDcByteArray(out, bspPlanePY_LO); byteSize += bspPlanePY_LO.size();
    fprintf(out, "FLATBSP_PLANEPX_HI_%s ; bspnode->planeOrigX\n", roomName.c_str());
    outputDcByteArray(out, bspPlanePX_HI); byteSize += bspPlanePX_HI.size();
    fprintf(out, "FLATBSP_PLANEPY_HI_%s ; bspnode->planeOrigY\n", roomName.c_str());
    outputDcByteArray(out, bspPlanePY_HI); byteSize += bspPlanePY_HI.size();
    //fprintf(out, "FLATBSP_HEIGHT_%s ; bspnode->height\n", roomName.c_str());
    //outputDcByteArray(out, bspPlaneHeight); byteSize += bspPlaneHeight.size();
    fprintf(out, "RECTANGLELIST_%s ; rectangles\n", roomName.c_str());
    for (int i = 0; i < r.rectangles.size(); ++i) {
        RECT p = r.rectangles[i];
        fprintf(out, "\tdc.b %d,$%02x,$%02x,%d\t; type,nx,ny,special <%d>\n", p.type, p.nx & 255, p.ny & 255, p.specialValue, i);
        fprintf(out, "\tdc.w %d,%d,%d,%d\t; x0,x1,y0,y1 <%d>\n", p.x0, p.x1, p.y0, p.y1, i);
        fprintf(out, "\tdc.w %d,%d\t\t; px,py <%d>\n", p.px, p.py, i);
        byteSize += 2 * 4 + 2 * 2 + 2 + 2;
    }
    fprintf(out, "\tdc.b $ff ; terminator\n"); byteSize+=1;

    fprintf(out, "\t;POLIES\n");
    for (int i = 0; i < r.polies.size(); ++i) {
        int point1 = r.polies[i].id_start;
        int point2 = r.polies[i].id_end;
        if (point1 & FLAG_SPECIALPOINT) {
            point1 &= ~FLAG_SPECIALPOINT;
            point1 += r.points.size();
        }
        if (point2 & FLAG_SPECIALPOINT) {
            point2 &= ~FLAG_SPECIALPOINT;
            point2 += r.points.size();
        }
        switch (r.polies[i].polyType) {
        case POLYTYPE_SPAN: {
            fprintf(out, ";<%d> [%d,%d] <<%d,%d><%d,%d>>\n", i, point1, point2, (int)getStartPoint(r, r.polies[i]).x, (int)getStartPoint(r, r.polies[i]).y, (int)getEndPoint(r, r.polies[i]).x, (int)getEndPoint(r, r.polies[i]).y);
            break;
        }
        case POLYTYPE_PORTAL: {
            fprintf(out, ";<%d> portal [%d,%d] <<%d,%d><%d,%d>>\n", i, point1, point2, (int)getStartPoint(r, r.polies[i]).x, (int)getStartPoint(r, r.polies[i]).y, (int)getEndPoint(r, r.polies[i]).x, (int)getEndPoint(r, r.polies[i]).y);
            break;
        }
        case POLYTYPE_PORTAL_WITH_SPAN: {
            fprintf(out, ";<%d> portal with span [%d,%d] <<%d,%d><%d,%d>>\n", i, point1, point2, (int)getStartPoint(r, r.polies[i]).x, (int)getStartPoint(r, r.polies[i]).y, (int)getEndPoint(r, r.polies[i]).x, (int)getEndPoint(r, r.polies[i]).y);
            break;
        }
        case POLYTYPE_BILLBOARD: {
            fprintf(out, ";<%d> billboard [%d] <%d,%d>\n", i, point1, r.points[point1].x, r.points[point1].y);
            break;
        }
        case POLYTYPE_SEPERATOR: {
            fprintf(out, ";<%d> seperator\n", i);
            break;
        }
        }

    }
    fprintf(out, "\t;BSP\n");
    for (int i = 0; i < flatBsp.size(); ++i) {
        fprintf(out, ";<%d>l=%d,r=%d :nx=%f,ny=%f :pl=%d<$%02x>\n", i, flatBsp[i]->computedLeftArrayIndex, flatBsp[i]->computedRightArrayIndex, (float)flatBsp[i]->plane.nx / 127, (float)flatBsp[i]->plane.ny / 127, bspPolyNr[i], bspPolyNr[i]);

    }
    fprintf(out, "\n");
    fprintf(out, "; -- byteSize:%d <$%04x>\n", byteSize, byteSize);
    fclose(out);
    return byteSize;
}

ROOM getBsp(GuiData* data) {
    ROOM r = toRoom(data);
    r.bsp = toFlatBSP(r);
    return r;
}

ROOM currentBSPRoom;

int convertRoomId(int roomNr, std::vector<int>& roomIds) {
    int ret = 0;
    for (int i = 0; i < roomIds.size(); ++i) {
        if (roomIds[i] == roomNr)
            ret = i;
    }
    return ret;
}

ROOM getRoomSubset(ROOM &r, int roomNr, std::vector<int> &roomIds) {
    ROOM ret;
    std::map<int, int> pointRemap;
    for (int i = 0; i < r.polies.size(); ++i) {
        POLY p = r.polies[i];
        if (p.roomNr == roomNr) {
            int t;
            t = p.id_start;
            if (pointRemap.find(t) != pointRemap.end()) {
                t = pointRemap[t];
            }
            else {
                pointRemap[t] = ret.points.size();
                ret.points.push_back(r.points[t]);
                t = pointRemap[t];
            }
            p.id_start = t;

            t = p.id_end;
            if (pointRemap.find(t) != pointRemap.end()) {
                t = pointRemap[t];
            }
            else {
                pointRemap[t] = ret.points.size();
                ret.points.push_back(r.points[t]);
                t = pointRemap[t];
            }
            p.id_end = t;
            p.roomNr = convertRoomId(p.roomNr, roomIds);
            p.portalRoomNr = convertRoomId(p.portalRoomNr, roomIds);
            ret.polies.push_back(p);
        }
    }
    for (int i = 0; i < r.rectangles.size(); ++i) {
        RECT p = r.rectangles[i];
        if (p.roomNr == roomNr) {
            p.roomNr = convertRoomId(p.roomNr, roomIds);
            p.portalRoomNrBack = convertRoomId(p.portalRoomNrBack, roomIds);
            if (p.type == SWITCH_TYPE_PORTAL)
                p.specialValue = p.portalRoomNrBack;
            ret.rectangles.push_back(p);
        }
    }
    return ret;
}

void saveBsp(GuiData* data, const std::string outputFileNameStem) {
    if (data->scene.polys.empty() || data->scene.points.empty())
        return;
    currentBSPRoom = toRoom(data);
    std::set<int> roomIds;
    for (int i = 0; i < currentBSPRoom.polies.size(); ++i) {
        roomIds.insert(currentBSPRoom.polies[i].roomNr);
    }
    std::vector<int> roomIdsV(roomIds.begin(), roomIds.end());
    FILE* out = fopen((basePath + "generated/" + outputFileNameStem + ".def").c_str(), "w");
    
    data->bspByteSize = 0;
    for (int i = 0; i < 2; ++i) { // passes
        for (auto&& roomId : roomIdsV) {
            std::string asmName = outputFileNameStem + "_" + std::to_string(roomId);
            std::string incFileName = "generated/" + outputFileNameStem + std::to_string(roomId) + ".inc";
            if (i == 0) {
                fprintf(out, "\tdc.w ROOMDESC_%s\n", asmName.c_str());
                data->bspByteSize += 2;
                ROOM r = getRoomSubset(currentBSPRoom, roomId, roomIdsV);
                data->bspByteSize += exportRoom(r, incFileName, asmName);
            }
            if (i == 1) {
                fprintf(out, "\tinclude \"%s\"\n", incFileName.c_str());
            }
        }
        fprintf(out, "\n");
    }
    fprintf(out,"DEF_CURRENTROOM = %d\n", convertRoomId(data->scene.rootRoom,roomIdsV));
    fclose(out);
    currentBSPRoom = getRoomSubset(currentBSPRoom, convertRoomId(data->highlighRoomNr, roomIdsV) , roomIdsV);
    exportRoom(currentBSPRoom, "generated/" + outputFileNameStem + ".inc", outputFileNameStem);
}

