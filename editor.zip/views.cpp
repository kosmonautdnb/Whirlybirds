#define _CRT_SECURE_NO_WARNINGS
#include "views.h"
#include "view_2dplanar.h"
#include "view_3dengine.h"
#include "view_modeselect.h"
#include "view_help.h"
#include "view_spanbox.h"
#include "view_textures.h"
#include "view_engine.h"

void paint_views(GuiData* data) {
	paint_3dengine(data);
	paint_2dplanar(data);
	paint_modeselect(data);
	paint_help(data);
	paint_spanbox(data);
	paint_textures(data);
	paint_engine(data);
}