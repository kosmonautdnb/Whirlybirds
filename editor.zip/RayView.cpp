#define _CRT_SECURE_NO_WARNINGS
#include "imgui/imgui.h"
#include "imgui/examples/imgui_impl_glfw.h"
#include "imgui/examples/imgui_impl_opengl3.h"
#include "nativefiledialog/nfd.h"
#include "views.h"
#include "guidata.h"
#include "texture_converter.h"

#include <string>
#include <set>
#include <map>
#include <vector>
#include "bitmaps.h"
#include <windows.h>

#if defined(IMGUI_IMPL_OPENGL_LOADER_GL3W)
#include "imgui/examples/libs/gl3w/GL/gl3w.h"    // Initialize with gl3wInit()
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLEW)
#include <GL/glew.h>    // Initialize with glewInit()
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLAD)
#include <glad/glad.h>  // Initialize with gladLoadGL()
#else
#include IMGUI_IMPL_OPENGL_LOADER_CUSTOM
#endif

#include "imgui/examples/libs/glfw/include/GLFW/glfw3.h"

GLFWwindow* window;

#if defined(_MSC_VER) && (_MSC_VER >= 1900) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS)
#pragma comment(lib, "legacy_stdio_definitions")
#endif

static void glfw_error_callback(int error, const char* description)
{
    fprintf(stderr, "Glfw Error %d: %s\n", error, description);
}



std::string basePath = "../../../";

//const int SPANLINEMEM = 256 * 2; // 8 * 64 = 512
//const int MAXSPANSPERX = 8;
//const int spanTextureOffset = SPANLINEMEM * 0;
//const int spanTextureTXOffset = SPANLINEMEM * 1;
//const int spanYStartOffset = SPANLINEMEM * 2;
//const int spanYEndOffset = SPANLINEMEM * 3;
//
//double overallTextureScale = 1.0;
//
//#define CP(_pix1_,_pix2_) ((_pix1_) & 3) | (((_pix2_) & 3)<<4)
//#define CP2(_pix1_,_pix2_) (((_pix1_) & 3) | (((_pix2_) & 3)<<4)|0x80)
//
//void convertTexture(const std::string& pngFile, const std::string& outputFile, int textureWidth) {
//    LoadPNG((basePath + pngFile).c_str());
//    toPlus4Colors();
//
//    struct SPAN {
//        std::vector<unsigned char> doty;
//        std::vector<unsigned char> color;
//        int firstColor = -1;
//        int lastColor = -1;
//        bool equals(const SPAN& b) {
//            if (b.doty.size() != doty.size())
//                return false;
//            for (int i = 0; i < doty.size(); ++i) {
//                if (b.doty[i] != doty[i])
//                    return false;
//                if (b.color[i] != color[i])
//                    return false;
//            }
//            if (b.firstColor != firstColor)
//                return false;
//            if (b.lastColor != lastColor)
//                return false;
//            return true;
//        }
//    };
//
//    std::vector<int> selectedSpans;
//    std::vector<SPAN> spans;
//
//    unsigned char expand[4] = { 0b00000000,0b01010101,0b10101010,0b11111111 };
//    for (int x = 0; x < textureWidth; ++x) {
//        int tx = pictureWidth * x / textureWidth;
//        SPAN here;
//        int lastColor = -1; // the upperst pixel is always stored
//        int bottomColor = 0;
//        int firstColor = 0;
//        for (int y = 0; y < pictureHeight; ++y) {
//            int c = pictureS[tx + y * pictureWidth] & 3;
//            if (c != lastColor) {
//                int eored = lastColor < 0 ? c : c ^ lastColor;
//                lastColor = c;
//                if (y != 0) {
//                    here.doty.push_back(y * 256 / pictureHeight);
//                    here.color.push_back(expand[eored]);
//                }
//                else {
//                    firstColor = eored;
//                }
//                bottomColor ^= eored;
//            }
//        }
//        here.firstColor = expand[firstColor];
//        here.lastColor = expand[bottomColor];
//        int found = -1;
//        for (int i = 0; i < spans.size(); ++i) {
//            if (spans[i].equals(here)) {
//                found = i;
//                break;
//            }
//        }
//        if (found == -1) {
//            selectedSpans.push_back(spans.size());
//            spans.push_back(here);
//        }
//        else {
//            selectedSpans.push_back(found);
//        }
//    }
//
//    // serialize
//    int dotCount = 0;
//    for (auto& a : spans) {
//        dotCount += a.doty.size();
//    }
//
//    if (dotCount > 255) {
//        OutputDebugStringA("!!ERROR!!");
//        printf("dotCount:<%d>\n", dotCount);
//        while (1) {
//        }
//    }
//
//    std::vector<int> spanBegin;
//    int k = 0;
//    for (int i = 0; i < spans.size(); ++i) {
//        spanBegin.push_back(k);
//        k += spans[i].doty.size();
//    }
//
//    FILE* out;
//    out = fopen((basePath + outputFile).c_str(), "wb");
//    unsigned char d;
//    d = dotCount;
//    fwrite(&d, 1, 1, out);
//    d = textureWidth;
//    fwrite(&d, 1, 1, out);
//    for (int i = 0; i < textureWidth; ++i) {
//        d = spanBegin[selectedSpans[i]];
//        fwrite(&d, 1, 1, out);
//    }
//    for (int i = 0; i < textureWidth; ++i) {
//        d = spans[selectedSpans[i]].doty.size() + spanBegin[selectedSpans[i]];
//        fwrite(&d, 1, 1, out);
//    }
//    for (int i = 0; i < spans.size(); ++i) {
//        for (int j = 0; j < spans[i].doty.size(); ++j) {
//            d = spans[i].doty[j];
//            fwrite(&d, 1, 1, out);
//        }
//    }
//    for (int i = 0; i < spans.size(); ++i) {
//        for (int j = 0; j < spans[i].doty.size(); ++j) {
//            d = spans[i].color[j];
//            fwrite(&d, 1, 1, out); // evens
//        }
//    }
//    for (int i = 0; i < textureWidth; ++i) {
//        d = spans[selectedSpans[i]].firstColor;
//        fwrite(&d, 1, 1, out); // upperst texpixel
//    }
//    for (int i = 0; i < textureWidth; ++i) {
//        d = spans[selectedSpans[i]].lastColor;
//        fwrite(&d, 1, 1, out); // full eored lastColor
//    }
//    fclose(out);
//}

//void generateTestFrame(const std::string& outputFile) {
//
//    std::vector<unsigned char> data(SPANLINEMEM * 4);
//    std::fill(data.begin(), data.end(), 0xff);
//
//    struct SPAN {
//        int screenX;
//        int textureNumber;
//        int textureX;
//        int screenYStart;
//        int screenYEnd;
//    };
//
//    std::vector<SPAN> spans;
//    for (int x = 0; x < 64; ++x) {
//        spans.push_back({ x,0,x % 32,0,5 });
//    }
//
//    for (int i = 0; i < spans.size(); ++i) {
//        int screenX = spans[i].screenX;
//        int offset = screenX * MAXSPANSPERX;
//        int currentSpanId = 0;
//        while (data[offset + spanTextureOffset] != 0xff && currentSpanId != MAXSPANSPERX) {
//            offset++;
//            currentSpanId++;
//        }
//        if (currentSpanId == MAXSPANSPERX)
//            while (1);
//        data[offset + spanTextureOffset] = spans[i].textureNumber;
//        data[offset + spanTextureTXOffset] = spans[i].textureX;
//        data[offset + spanYStartOffset] = spans[i].screenYStart;
//        data[offset + spanYEndOffset] = spans[i].screenYEnd;
//    }
//
//    FILE* out = fopen((basePath + outputFile).c_str(), "wb");
//    fwrite(&(data[0]), 1, data.size(), out);
//    fclose(out);
//}
//
//struct POLAR {
//    unsigned short angle = 0;
//    short distance = 0;
//};
//
//struct POINT2D {
//    short x = 0, y = 0;
//    bool equals(const class SPECIALPOINT& b);
//};
//
//
//#define FLAG_SPECIALPOINT 0x80
//class SPECIALPOINT {
//public:
//    unsigned char id1, id2;
//    unsigned char interpolate;
//    short calcedX, calcedY;
//    bool equals(const SPECIALPOINT& b) {
//        if (b.calcedX != calcedX)
//            return false;
//        if (b.calcedY != calcedY)
//            return false;
//        return true;
//    }
//};
//
//bool POINT2D::equals(const SPECIALPOINT& b) {
//    if (b.calcedX != x)
//        return false;
//    if (b.calcedY != y)
//        return false;
//    return true;
//}
//
//int interpolateSin(int ang10000, int angAdd10000) {
//    const int BITSHIFT = 6;
//    int coarse = (ang10000 >> BITSHIFT) + (angAdd10000 >> BITSHIFT);
//    int fine = (ang10000 << (8 - BITSHIFT)) & 255;
//    int sin1 = (int)(sin((float)coarse / (0x10000 >> BITSHIFT) * 2.f * 3.14159) * 0x8000);
//    int sin2 = (int)(sin((float)(coarse + 1)/ (0x10000 >> BITSHIFT) * 2.f * 3.14159) * 0x8000);
//    int ret = sin1 + (sin2 - sin1) * fine / 256;
//    return ret;
//}
//
//std::vector<POLAR> convertPoints(const std::vector<POINT2D>& points, const POINT2D& center) {
//    std::vector<POLAR> ret;
//    for (int i = 0; i < points.size(); ++i) {
//        double x = (double)points[i].x - center.x;
//        double y = (double)points[i].y - center.y;
//        int angle = (int)(atan2(x, y) / 3.1415927f * 0x8000); // -1 .. + 1
//        int distance = (int)(sqrt(x * x + y * y) * 2.0 + 0.5); // * 2 because sintab is only -0.5 till 0.5
//
//        unsigned short ang2 = (unsigned short)(angle & 0xffff);
//        int sin2 = interpolateSin(ang2, 0x0000);
//        int cos2 = interpolateSin(ang2, 0x10000 / 4);
//
//        int x2 = (sin2 * distance + 32768)>>16;
//        int y2 = (cos2 * distance + 32768)>>16;
//
//        // engine could actuall handle negative distances but not full 16 bit 0x10000 only 0x8000
//        ret.push_back({ ang2, (short)distance });
//    }
//    return ret;
//}
//
//struct POLY {
//    bool stalagmite;
//    unsigned char id_start, id_end;
//    unsigned char texture;
//    unsigned char tx_start;
//    unsigned char tx_end;
//    char top, bottom;
//    char topColor, bottomColor;
//    unsigned char polyIndexHelper;
//};
//
//struct ROOM {
//    POINT2D roomCenter;
//    std::vector<POLY> polies;
//    std::vector<POINT2D> points;
//    std::vector<SPECIALPOINT> specialpoints;
//};
//
//unsigned char getAddSpecialPoint(ROOM& r, unsigned char id1, unsigned char id2, double interpolate) {
//    SPECIALPOINT p;
//    p.id1 = id1;
//    p.id2 = id2;
//    int sx;
//    int sy;
//    int ex;
//    int ey;
//    if (id1 & FLAG_SPECIALPOINT) {
//        sx = r.specialpoints[(id1) & (~FLAG_SPECIALPOINT)].calcedX;
//        sy = r.specialpoints[(id1) & (~FLAG_SPECIALPOINT)].calcedY;
//    }
//    else {
//        sx = r.points[id1].x;
//        sy = r.points[id1].y;
//    }
//    if (id2 & FLAG_SPECIALPOINT) {
//        ex = r.specialpoints[(id2) & (~FLAG_SPECIALPOINT)].calcedX;
//        ey = r.specialpoints[(id2) & (~FLAG_SPECIALPOINT)].calcedY;
//    }
//    else {
//        ex = r.points[id2].x;
//        ey = r.points[id2].y;
//    }
//
//
//    interpolate *= 256.0;
//    if (interpolate < 0) interpolate = 0;
//    if (interpolate > 255) interpolate = 255;
//    p.interpolate = (unsigned char)interpolate;
//    int i = p.interpolate;
//    if (p.interpolate == 255)
//        i = 256;
//    p.calcedX = (((ex - sx) * i) >> 8) + sx;
//    p.calcedY = (((ey - sy) * i) >> 8) + sy;
//    for (int i = 0; i < r.specialpoints.size(); ++i)
//        if (r.specialpoints[i].equals(p))
//            return i | FLAG_SPECIALPOINT;
//    for (int i = 0; i < r.points.size(); ++i)
//        if (r.points[i].equals(p))
//            return i;
//    r.specialpoints.push_back(p);
//    return (r.specialpoints.size() - 1) | FLAG_SPECIALPOINT;
//}
//
//struct PLANE {
//    char nx = -1, ny = -1;
//    short px = -1, py = -1;
//};
//
//class BSP {
//public:
//    std::vector<int> polyIndex;
//    PLANE plane;
//    BSP *left = nullptr, *right = nullptr;
//    int computedLeftArrayIndex = -1, computedRightArrayIndex = -1;
//};
//
//void remove(std::vector<POLY>& polysToProcess, const POLY& ply) {
//    for (int i = 0; i < polysToProcess.size(); ++i) {
//        if (polysToProcess[i].polyIndexHelper == ply.polyIndexHelper) {
//            polysToProcess.erase(polysToProcess.begin() + i);
//            return;
//        }
//    }
//}
//
//class POINTF {
//public:
//    double x, y;
//};
//
//POINTF getStartPoint(ROOM& r, const POLY& ply) {
//    POINTF ret;
//    int index = ply.id_start;
//    if (index & FLAG_SPECIALPOINT) {
//        index &= ~FLAG_SPECIALPOINT;
//        ret.x = r.specialpoints[index].calcedX;
//        ret.y = r.specialpoints[index].calcedY;
//    }
//    else {
//        ret.x = r.points[index].x;
//        ret.y = r.points[index].y;
//    }
//    return ret;
//}
//
//POINTF getEndPoint(ROOM& r, const POLY& ply) {
//    POINTF ret;
//    int index = ply.id_end;
//    if (index & FLAG_SPECIALPOINT) {
//        index &= ~FLAG_SPECIALPOINT;
//        ret.x = r.specialpoints[index].calcedX;
//        ret.y = r.specialpoints[index].calcedY;
//    }
//    else {
//        ret.x = r.points[index].x;
//        ret.y = r.points[index].y;
//    }
//    return ret;
//}
//
//PLANE generatePlane(ROOM &r, const POLY& ply) {
//    POINTF sp = getStartPoint(r, ply);
//    POINTF ep = getEndPoint(r, ply);
//    PLANE ret;
//    double dx = ep.x - sp.x;
//    double dy = ep.y - sp.y;
//    double l = dx * dx + dy * dy;
//    if (l != 0.0)
//        l = sqrt(l);
//    ret.nx = (dy / l) * 0x7f;
//    ret.ny = (-dx / l) * 0x7f;
//    ret.px = sp.x;
//    ret.py = sp.y;
//    return ret;
//}
//
//double planeDist1(ROOM& r, const PLANE& plane, const BSP* bsp) {
//    POINTF p = getStartPoint(r, r.polies[bsp->polyIndex[0]]);
//    float xp = p.x;
//    float yp = p.y;
//    float xd = xp - plane.px;
//    float yd = yp - plane.py;
//    return (xd * plane.nx + yd * plane.ny);
//}
//
//double planeDist2(ROOM& r, const PLANE& plane, const BSP* bsp) {
//    POINTF p = getEndPoint(r, r.polies[bsp->polyIndex[0]]);
//    float xp = p.x;
//    float yp = p.y;
//    float xd = xp - plane.px;
//    float yd = yp - plane.py;
//    return (xd * plane.nx + yd * plane.ny);
//}
//
//bool isInFrontOfPlane1(ROOM& r, const PLANE& plane, const BSP* bsp) {
//    return planeDist1(r, plane, bsp) >= 0;
//}
//
//bool isInFrontOfPlane2(ROOM& r, const PLANE& plane, const BSP* bsp) {
//    return planeDist2(r, plane, bsp) >= 0;
//}
//
//BSP* selectGoodPlaneAndPop(ROOM& r, std::vector<BSP*>& allToProcess) {
//    int bestI = 0;
//    int bestScore = -1;
//    for (int i = 0; i < allToProcess.size(); ++i) {
//        BSP* checkPlane1 = allToProcess[i];
//        int score = 0;
//        for (int j = 0; j < allToProcess.size(); ++j) {
//            BSP* checkPlane2 = allToProcess[j];        
//            bool f1 = isInFrontOfPlane1(r, checkPlane1->plane, checkPlane2);
//            bool f2 = isInFrontOfPlane2(r, checkPlane1->plane, checkPlane2);
//            if (f1 != f2)
//                score++;
//        }
//        if (bestScore < 0)
//            bestScore = score;
//        if (score < bestScore) {
//            bestScore = score;
//            bestI = i;
//        }
//    }
//    BSP* node = allToProcess[bestI];
//    allToProcess.erase(allToProcess.begin() + bestI);
//    return node;
//}
//
//bool isPolyValid(ROOM &r, POLY &ply) {
//    POINTF s = getStartPoint(r, ply);
//    POINTF e = getEndPoint(r, ply);
//    if (s.x == e.x && s.y == e.y)
//        return false;
//    return true;
//}
//
//void bspInsert(ROOM &r, BSP* tree, std::vector<BSP*> allToProcess) {
//    BSP* node = selectGoodPlaneAndPop(r, allToProcess);
//    tree->plane = node->plane;
//    tree->polyIndex = node->polyIndex;
//    // left, right = nullptr here
//
//    std::vector<BSP*> left;
//    std::vector<BSP*> right;
//    for (auto&& a : allToProcess) {
//        double dist1 = planeDist1(r, tree->plane, a);
//        double dist2 = planeDist2(r, tree->plane, a);
//        bool f1 = isInFrontOfPlane1(r, tree->plane, a);
//        bool f2 = isInFrontOfPlane2(r, tree->plane, a);
//        if (dist1 == 0) {
//            f1 = f2;
//        }
//        if (dist2 == 0) {
//            f2 = f1;
//        }
//        if (f1 == f2) {
//            if (f1)
//                left.push_back(a);
//            else
//                right.push_back(a);
//        }
//        else {
//            //while (1);
//            if (a->polyIndex.size() != 1) {
//                int debug = 1;
//                while (1);
//            }
//            const bool split = true;
//            if (!split) {
//                tree->polyIndex.push_back(a->polyIndex[0]);
//            }
//            else {
//                double dist = abs(dist1) + abs(dist2);
//                double factor = abs(dist1) / dist;
//
//                int id1 = r.polies[a->polyIndex[0]].id_start;
//                int id2 = r.polies[a->polyIndex[0]].id_end;
//
//                unsigned char specialPoint = getAddSpecialPoint(r, id1, id2, factor);
//                POLY poly1 = r.polies[a->polyIndex[0]];
//                POLY poly2 = r.polies[a->polyIndex[0]];
//                poly1.id_end = specialPoint;
//                poly2.id_start = specialPoint;
//                poly1.tx_end = (poly1.tx_end - poly1.tx_start) * factor + poly1.tx_start;
//                poly2.tx_start = (poly1.tx_end - poly1.tx_start) * factor + poly1.tx_start;
//
//                if (isPolyValid(r, poly1)) {
//                    int index = r.polies.size();
//                    r.polies.push_back(poly1);
//                    BSP* bsp = new BSP();
//                    bsp->plane = generatePlane(r, poly1);
//                    if (poly1.id_end != id2) // in case it's the same poly we use it only as splitting plane
//                        bsp->polyIndex.push_back(index);
//                    else {
//                        r.polies.pop_back();
//                        bsp->polyIndex.push_back(a->polyIndex[0]);
//                    }
//                    if (f1)
//                        left.push_back(bsp);
//                    else
//                        right.push_back(bsp);
//                }
//                if (isPolyValid(r, poly2)) {
//                    int index = r.polies.size();
//                    r.polies.push_back(poly2);
//                    BSP* bsp = new BSP();
//                    bsp->plane = generatePlane(r, poly2);
//                    if (poly2.id_start != id1) // in case it's the same poly we use it only as splitting plane
//                        bsp->polyIndex.push_back(index);
//                    else {
//                        r.polies.pop_back();
//                        bsp->polyIndex.push_back(a->polyIndex[0]);
//                    }
//                    if (!f1)
//                        left.push_back(bsp);
//                    else
//                        right.push_back(bsp);
//                }
//            }
//        }
//    }
//    if (!left.empty()) {
//        tree->left = new BSP();
//        bspInsert(r, tree->left, left);
//    }
//    if (!right.empty()) {
//        tree->right = new BSP();
//        bspInsert(r, tree->right, right);
//    }
//}
//
//BSP *buildBsp(ROOM& r) {
//    if (r.polies.empty())
//        return nullptr;
//    for (int i = 0; i < r.polies.size(); ++i) {
//        r.polies[i].polyIndexHelper = i;
//    }
//    std::vector<BSP*> bspToAdd;
//    for (auto&& p : r.polies) {
//        BSP *b = new BSP();
//        b->plane = generatePlane(r, p);
//        b->polyIndex.push_back(p.polyIndexHelper);
//        bspToAdd.push_back(b);
//    }
//    BSP* tree = new BSP();
//    bspInsert(r, tree, bspToAdd);
//    return tree;
//}
//
//std::vector<BSP*> flattenBsp(BSP* bsp) {
//    std::vector<BSP*> ret;
//    std::vector<BSP*> list;
//    std::set<BSP*> alreadyProcessed;
//    list.push_back(bsp);
//    while (!list.empty()) {
//        BSP* here = list[0];
//        ret.push_back(here);
//        alreadyProcessed.insert(here);
//        list.erase(list.begin());
//        if (here->left != nullptr && alreadyProcessed.find(here->left) == alreadyProcessed.end())
//            list.push_back(here->left);
//        if (here->right != nullptr && alreadyProcessed.find(here->right) == alreadyProcessed.end())
//            list.push_back(here->right);
//    }
//    for (int i = 0; i < ret.size(); ++i) {
//        for (int j = 0; j < ret.size(); ++j) {
//            if (ret[i]->left == ret[j]) {
//                if (i == j) {
//                    int debug = 1;
//                }
//                ret[i]->computedLeftArrayIndex = j;
//            }
//            if (ret[i]->right == ret[j]) {
//                if (i == j) {
//                    int debug = 1;
//                }
//                ret[i]->computedRightArrayIndex = j;
//            }
//        }
//    }
//    return ret;
//}
//
//void exportRoom(ROOM& r, const std::string& outputFile, const std::string &roomName) {
//    std::vector<BSP*> flatBsp = flattenBsp(buildBsp(r));
//    FILE* out;
//    out = fopen((basePath + outputFile).c_str(), "w");
//    //std::vector<POLAR> polar = convertPoints(r.points, r.roomCenter);
//    int byteSize = 0;
//    fprintf(out, ";--- ROOM FILE <%s>---\n", roomName.c_str());
//    fprintf(out, "\n");
//    fprintf(out, "ROOMDESC_%s\n", roomName.c_str());
//    fprintf(out, "\tdc.w %d,%d ; room center\n", r.roomCenter.x, r.roomCenter.y); byteSize += 4;
//    fprintf(out, "\tdc.w $%04x ; room point count\n", r.points.size()); byteSize += 2;
//    fprintf(out, "\tdc.w ROOMPOINTS_%s ; points\n", roomName.c_str()); byteSize += 2;
//    fprintf(out, "\tdc.w $%04x ; room poly count\n", r.polies.size()); byteSize += 2;
//    fprintf(out, "\tdc.w ROOMPOLIES_%s ; points\n", roomName.c_str()); byteSize += 2;
//    fprintf(out, "\tdc.w FLATBSP_LEFTNODE_%s ; bspnode->left\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_RIGHTNODE_%s ; bspnode->right\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_POLYNR_%s ; bspnode->polyIndex\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_PLANENX_%s ; bspnode->planeNormalX\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_PLANENY_%s ; bspnode->planeNormalY\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_PLANEPX_LO_%s ; bspnode->planeOrigX\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_PLANEPY_LO_%s ; bspnode->planeOrigY\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_PLANEPX_HI_%s ; bspnode->planeOrigX\n", roomName.c_str());
//    fprintf(out, "\tdc.w FLATBSP_PLANEPY_HI_%s ; bspnode->planeOrigY\n", roomName.c_str());
//    fprintf(out, "\tdc.w COMBINED_POLYLIST_%s ; if more than one poly is connected to a node\n", roomName.c_str());
//    fprintf(out, "ROOMPOINTS_%s ; x, y\n", roomName.c_str());
//    const char* pointLabels[] = {
//        "; xlo\n",
//        "; xhi\n",
//        "; ylo\n",
//        "; yhi\n",
//    };
//    for (int j = 0; j < 4; ++j) {
//        fprintf(out, "%s",pointLabels[j]);
//        for (int i = 0; i < r.points.size() + r.specialpoints.size(); ++i) {
//            int px = 0;
//            int py = 0;
//            if (i < r.points.size()) {
//                px = r.points[i].x;
//                py = r.points[i].y;
//            }
//            else {
//                if (i == r.points.size()) {
//                    fprintf(out, "\t\t;specialPoints\n");
//                }
//                px = r.specialpoints[i- r.points.size()].calcedX;
//                py = r.specialpoints[i - r.points.size()].calcedY;
//            }
//            switch (j) {
//            case 0:
//                fprintf(out, "\tdc.b $%02x; <%d> x=%d,y=%d\n", px & 255, i, px, py);
//                break;
//            case 1:
//                fprintf(out, "\tdc.b $%02x; <%d> x=%d,y=%d\n", (px >> 8) & 255, i, px, py);
//                break;
//            case 2:
//                fprintf(out, "\tdc.b $%02x; <%d> x=%d,y=%d\n", py & 255, i, px, py);
//                break;
//            case 3:
//                fprintf(out, "\tdc.b $%02x; <%d> x=%d,y=%d\n", (py >> 8) & 255, i, px, py);
//                break;
//            }
//            byteSize++;
//        }
//    }
//    fprintf(out, "ROOMPOLIES_%s ; point1, point2, texture, texture start, texture end, topy, bottomy\n", roomName.c_str());
//    for (int i = 0; i < r.polies.size(); ++i) {
//        const POLY& p = r.polies[i];
//        unsigned char stalagmiteFlag = r.polies[i].stalagmite ? 0x40 : 0x00;
//        int tColor = r.polies[i].topColor;
//        int bColor = r.polies[i].bottomColor;
//
//        int point1 = p.id_start;
//        int point2 = p.id_end;
//        if (point1 & FLAG_SPECIALPOINT) {
//            point1 &= ~FLAG_SPECIALPOINT;
//            point1 += r.points.size();
//        }
//        if (point2 & FLAG_SPECIALPOINT) {
//            point2 &= ~FLAG_SPECIALPOINT;
//            point2 += r.points.size();
//        }
//        fprintf(out, "\tdc.b %d, %d, %d, %d, %d, %d, %d, [[[%d & 3]<<2]|[%d & 3]<<0]|POLYGON_FLAG_NONE; <%d>\n", point1, point2, p.texture | stalagmiteFlag, p.tx_start, p.tx_end, p.top, p.bottom, tColor, bColor, i);
//        byteSize += 8;
//    }
//
//    std::map<int, int> toFullRoomPolyList;
//    std::vector<unsigned char> fullRoomPolyList;
//    for (int i = 0; i < flatBsp.size(); ++i) {
//        if (flatBsp[i]->polyIndex.size() > 1) {
//            toFullRoomPolyList.insert(std::make_pair(i, fullRoomPolyList.size()));
//            for (int j = 0; j < flatBsp[i]->polyIndex.size(); ++j) {
//                int polyIndex = flatBsp[i]->polyIndex[j];
//                if (j == flatBsp[i]->polyIndex.size() - 1)
//                    polyIndex |= 0x80; // terminator
//                fullRoomPolyList.push_back(polyIndex);
//            }
//        }
//    }
//    fprintf(out, "COMBINED_POLYLIST_%s ; if more than one poly is connected to a node\n", roomName.c_str());
//    outputDcByteArray(out, fullRoomPolyList); byteSize += fullRoomPolyList.size();
//    std::vector<unsigned char> bspLeftNode;
//    std::vector<unsigned char> bspRightNode;
//    std::vector<unsigned char> bspPolyNr;
//    std::vector<unsigned char> bspPlaneNX;
//    std::vector<unsigned char> bspPlaneNY;
//    std::vector<unsigned char> bspPlanePX_LO;
//    std::vector<unsigned char> bspPlanePY_LO;
//    std::vector<unsigned char> bspPlanePX_HI;
//    std::vector<unsigned char> bspPlanePY_HI;
//    for (int i = 0; i < flatBsp.size(); ++i) {
//        bspLeftNode.push_back(flatBsp[i]->computedLeftArrayIndex);
//        bspRightNode.push_back(flatBsp[i]->computedRightArrayIndex);
//        int poly = 0xff;
//        if (!flatBsp[i]->polyIndex.empty()) {
//            poly = flatBsp[i]->polyIndex[0];
//            if (flatBsp[i]->polyIndex.size() > 1) {
//                poly = toFullRoomPolyList[i] | 0x80;
//            }
//        }
//        bspPolyNr.push_back(poly);
//        bspPlaneNX.push_back(flatBsp[i]->plane.nx & 255);
//        bspPlaneNY.push_back(flatBsp[i]->plane.ny & 255);
//        bspPlanePX_LO.push_back((flatBsp[i]->plane.px) & 255);
//        bspPlanePY_LO.push_back((flatBsp[i]->plane.py) & 255);
//        bspPlanePX_HI.push_back(((flatBsp[i]->plane.px)>>8) & 255);
//        bspPlanePY_HI.push_back(((flatBsp[i]->plane.py)>>8) & 255);
//    }
//    fprintf(out, "BSPTREE:\n");
//    fprintf(out, "\n");
//    fprintf(out, "FLATBSP_LEFTNODE_%s ; bspnode->left\n", roomName.c_str());
//    outputDcByteArray(out, bspLeftNode); byteSize += bspLeftNode.size();
//    fprintf(out, "FLATBSP_RIGHTNODE_%s ; bspnode->right\n", roomName.c_str());
//    outputDcByteArray(out, bspRightNode); byteSize += bspRightNode.size();
//    fprintf(out, "FLATBSP_POLYNR_%s ; bspnode->polyIndex\n", roomName.c_str());
//    outputDcByteArray(out, bspPolyNr); byteSize += bspPolyNr.size();
//    fprintf(out, "FLATBSP_PLANENX_%s ; bspnode->planeNormalX\n", roomName.c_str());
//    outputDcByteArray(out, bspPlaneNX);  byteSize += bspPlaneNX.size();
//    fprintf(out, "FLATBSP_PLANENY_%s ; bspnode->planeNormalY\n", roomName.c_str());
//    outputDcByteArray(out, bspPlaneNY);  byteSize += bspPlaneNY.size();
//    fprintf(out, "FLATBSP_PLANEPX_LO_%s ; bspnode->planeOrigX\n", roomName.c_str());
//    outputDcByteArray(out, bspPlanePX_LO); byteSize += bspPlanePX_LO.size();
//    fprintf(out, "FLATBSP_PLANEPY_LO_%s ; bspnode->planeOrigY\n", roomName.c_str());
//    outputDcByteArray(out, bspPlanePY_LO); byteSize += bspPlanePY_LO.size();
//    fprintf(out, "FLATBSP_PLANEPX_HI_%s ; bspnode->planeOrigX\n", roomName.c_str());
//    outputDcByteArray(out, bspPlanePX_HI); byteSize += bspPlanePX_HI.size();
//    fprintf(out, "FLATBSP_PLANEPY_HI_%s ; bspnode->planeOrigY\n", roomName.c_str());
//    outputDcByteArray(out, bspPlanePY_HI); byteSize += bspPlanePY_HI.size();
//
//    fprintf(out, "\t;POLIES\n");
//    for (int i = 0; i < r.polies.size(); ++i) {
//        fprintf(out, ";<%d> <<%d,%d><%d,%d>>\n", i, (int)getStartPoint(r, r.polies[i]).x, (int)getStartPoint(r, r.polies[i]).y, (int)getEndPoint(r,r.polies[i]).x, (int)getEndPoint(r, r.polies[i]).y);
//
//    }
//    fprintf(out, "\t;BSP\n");
//    for (int i = 0; i < flatBsp.size(); ++i) {
//        fprintf(out, ";<%d>l=%d,r=%d :nx=%f,ny=%f :pl=%d<$%02x>\n", i, flatBsp[i]->computedLeftArrayIndex, flatBsp[i]->computedRightArrayIndex, (float)flatBsp[i]->plane.nx / 127, (float)flatBsp[i]->plane.ny / 127, bspPolyNr[i], bspPolyNr[i]);
//
//    }
//    fprintf(out, "\n");
//    fprintf(out, "; -- byteSize:%d <$%04x>\n", byteSize, byteSize);
//    fclose(out);
//}
//
//void exportTestRoom() {
//
//    const int texWidth = 85;
//    unsigned char t = texWidth;
//
//    convertTexture("data/texture1.png", "generated/texture1.bin", (int)(texWidth));
//
//    ROOM r;
//    //double K = 6;
//    //r.points = {
//    //    {(short)(-10 * K),(short)(+10 * K)}, 
//    //    {(short)(+10 * K),(short)(+10 * K)},
//    //    {(short)(+10 * K),(short)(-10 * K)},
//    //    {(short)(-10 * K),(short)(-10 * K)},
//    //
//    //    {(short)(-20 * K),(short)(+20 * K)},
//    //    {(short)(+20 * K),(short)(+20 * K)},
//    //    {(short)(+20 * K),(short)(-20 * K)},
//    //    {(short)(-20 * K),(short)(-20 * K)},
//    //
//    //    {(short)(-3 * K),(short)(+3 * K)},
//    //    {(short)(+3 * K),(short)(+3 * K)},
//    //    {(short)(+3 * K),(short)(-3 * K)},
//    //    {(short)(-3 * K),(short)(-3 * K)},
//    //};
//    //
//    //double SC = 0.25;
//    //r.polies = {
//    //{true, 1, 0, 0, 0, t, (char)(-127 * SC), (char)(127 * SC)},
//    //{true, 2, 1, 0, 0, t, (char)(-127 * SC), (char)(127 * SC)},
//    //{true, 3, 2, 0, 0, t, (char)(-127 * SC), (char)(127 * SC)},
//    //{true, 0, 3, 0, 0, t, (char)(-127 * SC), (char)(127 * SC)},
//    //
//    //{true, 5, 4, 0, 0, t, (char)(0), (char)(127 * SC)},
//    //{true, 6, 5, 0, 0, t, (char)(0), (char)(127 * SC)},
//    //{true, 7, 6, 0, 0, t, (char)(0), (char)(127 * SC)},
//    //{true, 4, 7, 0, 0, t, (char)(0), (char)(127 * SC)},
//    //
//    //{true, 9, 8, 0, 0, t, (char)(-40 * SC), (char)(127 * SC)},
//    //{true, 10, 9, 0, 0, t, (char)(-40 * SC), (char)(127 * SC)},
//    //{true, 11, 10, 0, 0, t, (char)(-40 * SC), (char)(127 * SC)},
//    //{true, 8, 11, 0, 0, t, (char)(-40 * SC), (char)(127 * SC)},
//    //
//    //};
//    
//    {
//        int baseId = r.points.size();
//        int polyCount = 20;
//        for (int i = 0; i < polyCount; ++i) {
//            float ri = (float)i / polyCount;
//            double rad = 50 * 6 * (sin(ri * 3.14159f * 8.f) * 0.15 + 1.0);
//            double x = sin(ri * 2.f * 3.14159f) * rad;
//            double y = cos(ri * 2.f * 3.14159f) * rad;
//            int id1 = i + baseId;
//            int id2 = ((i + 1) % polyCount) + baseId;
//            r.points.push_back({ (short)x,(short)y });
//            r.polies.push_back(
//                { true, (unsigned char)id1, (unsigned char)(id2), 0, 0, t, (char)(-27 - (rand() % 100)), (char)(27), 0, 2 }
//            );
//        }
//    }
//    //
//    //{
//    //    int baseId = r.points.size();
//    //    int polyCount = 5;
//    //    for (int i = 0; i < polyCount; ++i) {
//    //        float ri = (float)i / polyCount;
//    //        double rad = 5 * 6 * (sin(ri * 3.14159f * 8.f) * 0.15 + 1.0);
//    //        double x = sin(ri * 2.f * 3.14159f) * rad;
//    //        double y = cos(ri * 2.f * 3.14159f) * rad;
//    //        int id2 = i + baseId;
//    //        int id1 = ((i + 1) % polyCount) + baseId;
//    //        r.points.push_back({ (short)x,(short)y });
//    //        r.polies.push_back(
//    //            { true, (unsigned char)id1, (unsigned char)(id2), 0, 0, t, (char)(-80), (char)(127), 0, 2 }
//    //        );
//    //    }
//    //}
//
//
//    {
//        int baseId = r.points.size();
//        int polyCount = 4;
//        for (int i = 0; i < polyCount; ++i) {
//            float ri = (float)i / polyCount;
//            double rad = 5 * 6 * (sin(ri * 3.14159f * 8.f) * 0.15 + 1.0);
//            double x = sin(ri * 2.f * 3.14159f) * rad + 80;
//            double y = cos(ri * 2.f * 3.14159f) * rad + 80;
//            int id2 = i + baseId;
//            int id1 = ((i + 1) % polyCount) + baseId;
//            r.points.push_back({ (short)x,(short)y });
//            r.polies.push_back(
//                { false, (unsigned char)id1, (unsigned char)(id2), 0, 0, t, (char)(-127), (char)(20), 0, 0 }
//            );
//        }
//    }
//
//
//    exportRoom(r, "generated/room1.inc","ROOM1");
//}

void endObjectMoveMode(GuiData* data, bool placeIt);

void exportTextureDefinitions(const std::string &outputFileName, std::vector<GuiData::XTexture>& textures) {
    FILE* out = fopen((basePath + outputFileName).c_str(), "wb");
    for (int i = 0; i < textures.size(); ++i) {
        const GuiData::XTexture &texture = textures[i];
        fprintf(out, "TEXTURE_%d; <$%02x>\n", i, i);
        fprintf(out, "\tincbin \"%s\" ; %s\n", texture.binFileName.c_str(), texture.fileName.c_str());
    }
    fprintf(out, "\ntextures\n");
    for (int i = 0; i < textures.size(); ++i) {
        const GuiData::XTexture& texture = textures[i];
        fprintf(out, "\tADDTEXTURE TEXTURE_%d ; <$%02x> %s <w:%d,h:%d>(originalwidth:%d)\n", i, i, texture.fileName.c_str(), texture.convertedWidth, texture.height, texture.width);
    }
    fprintf(out, "\tADDTEXTURE $ffff ; endmarker\n");
    fclose(out);
}

void convertBWBitmap(const std::string& pngFileName, const std::string& outputBinFileName) {
    LoadPNG(pngFileName.c_str());
    toPlus4Colors();
    FILE* out = fopen(outputBinFileName.c_str(), "wb");
    for (int y = 0; y < 200; y += 8) {
        for (int x = 0; x < 320; x += 8) {
            for (int y2 = 0; y2 < 8; ++y2) {
                unsigned char c = 0;
                for (int x2 = 0; x2 < 8; ++x2) {
                    int p = pictureS[(x + x2) + (y + y2) * pictureWidth];
                    int b = 1;
                    if (p == 0x71)
                        b = 0;
                    c |= b << (7 - x2);
                }
                fwrite(&c, 1, 1, out);
            }
        }
    }
    fclose(out);
}

int main()
{
    setupPalette(basePath + "data/Plus4ColsMeasured.asc");
    convertBWBitmap(basePath + "data/whirly.png", basePath + "generated/bitmap_whirly.bin");
    convertBWBitmap(basePath + "data/text.png", basePath + "generated/bitmap_text.bin");

    FILE* out;
    out = fopen((basePath + "generated/scaletab1.bin").c_str(), "wb");
    // a = 0..255, b = 0..255
    // ((a+b)/2)^2 (hibyte)
    for (int i = 0; i < 256*2; ++i) {
        int k = i;
        int value = k * k / 4;
        unsigned char d = (value >> 8) & 255;
        fwrite(&d, 1, 1, out);
    }
    fclose(out);
    out = fopen((basePath + "generated/scaletab1l.bin").c_str(), "wb");
    // a = 0..255, b = 0..255
    // ((a+b)/2)^2 (hibyte)
    for (int i = 0; i < 256 * 2; ++i) {
        int k = i;
        int value = k * k / 4;
        unsigned char d = (value) & 255;
        fwrite(&d, 1, 1, out);
    }
    fclose(out);
    out = fopen((basePath + "generated/scaletab2.bin").c_str(), "wb");
    // a = 0..255, b = 0..255
    // -((a-b)/2)^2 (hibyte)
    for (int i = 0; i < 256 * 2; ++i) {
        int k = i - 256+1; // +1 because of missing adc #$01 before after eor #$ff
        int value = -(k * k)/4;
        unsigned char d = ((value >> 8)+1) & 255; // +1 because of some rounding error
        fwrite(&d, 1, 1, out);
    }
    fclose(out);

    std::vector<short> sintab(1024);
    for (int i = 0; i < sintab.size(); ++i) {
        double angle = (double)i / sintab.size() * 2.f * 3.1415927f;
        double value = sin(angle) * 0x8000;
        if (i == 0x1ff)
            int debug = 1;
        sintab[i] = value < -0x8000 ? -0x8000 : value > 0x7fff ? 0x7fff : value;
    }
    out = fopen((basePath + "generated/sintablo.bin").c_str(), "wb");
    for (int i = 0; i < sintab.size(); ++i) {
        unsigned char d = sintab[i] & 255;
        fwrite(&d, 1, 1, out);
    }
    fclose(out);
    out = fopen((basePath + "generated/sintabhi.bin").c_str(), "wb");
    for (int i = 0; i < sintab.size(); ++i) {
        unsigned char d = (sintab[i]>>8) & 255;
        fwrite(&d, 1, 1, out);
    }
    fclose(out);

    const int SCREENX8 = 40;
    std::vector<int> p(SCREENX8 * 4);
    std::vector<int> q(SCREENX8 * 4);
    const int rad = 10000;
    const float fov = 4.0f;
    const float fscal = 2.f;
    for (int i = 0; i < rad; ++i) {
        float angle = (float)(i - rad / 2) / (rad / 2) * 3.14159 * 0.5;
        float x = sin(angle);
        float z = cos(angle)*fov+1;
        float sx = x * SCREENX8 * 4 / 2 * fscal / z + SCREENX8 * 4 / 2;
        float sy = 32 / z;
        int d = sx;
        if (d >= 0 && d < SCREENX8 * 4) {
            p[d] = i * SCREENX8 * 4 / rad;
            q[d] = sy;
        }
    }
    out = fopen((basePath + "generated/skyboxdistort.bin").c_str(), "wb");
    for (int i = 0; i < SCREENX8 * 4; ++i) {
        unsigned char d = p[i];
        fwrite(&d, 1, 1, out);
    }
    fclose(out);

    out = fopen((basePath + "generated/skyboxymove.bin").c_str(), "wb");
    for (int i = 0; i < SCREENX8 * 4; ++i) {
        unsigned char d = q[i];
        fwrite(&d, 1, 1, out);
    }
    fclose(out);

    out = fopen((basePath + "generated/cloudanimtab.bin").c_str(), "wb");
    for (int i = 0; i < 32; ++i) {
        unsigned char d = (int)(sin(i/32.f * 2.f * 3.14159)*2.f) & 255;
        fwrite(&d, 1, 1, out);
    }
    fclose(out);

    LoadPNG((basePath + "data/surround.png").c_str());
    toPlus4Colors();
    std::vector<unsigned char> charset;
    std::vector<unsigned char> colorandscreenram(0x400 * 2);
    std::vector<unsigned char> cols = { 0x53,0x32,0x00,0x71 };
    for (int y = 0; y < 25; ++y)
        for (int x = 0; x < 40; ++x) {
            unsigned char d[8];
            for (int y2 = 0; y2 < 8; ++y2) {
                unsigned char c = 0x00;
                for (int x2 = 0; x2 < 8; x2 += 2) {
                    int d = pictureS[x * 8 + x2 + (y * 8 + y2) * pictureWidth];
                    int b = 0;
                    for (int i = 0; i < cols.size(); ++i)
                        if (d == cols[i]) b = i;
                    c |= b << (6 - x2);
                }
                d[y2] = c;
            }
            int found = -1;
            for (int i = 0; i < charset.size(); i += 8) {
                found = i/8;
                for (int j = 0; j < 8; ++j)
                    if (charset[i+j] != d[j])
                        found = -1;
                if (found != -1)
                    break;
            }
            if (found == -1) {
                found = charset.size() / 8;
                for (int i = 0; i < 8; ++i)
                    charset.push_back(d[i]);
            }
            colorandscreenram[x + y * 40 + 0x400] = found+28*9;
            if (y >= 18)
                colorandscreenram[x + y * 40 + 0x400] = 0x80;
            colorandscreenram[x + y * 40] = (0x71|0x08);
        }
    std::vector<unsigned char> charset2(8);
    LoadPNG((basePath + "data/whirlybirds.png").c_str());
    for (int y = 0; y < pictureHeight / 8; ++y) {
        for (int x = 0; x < pictureWidth / 8; ++x) {
            unsigned char d[8];
            for (int y2 = 0; y2 < 8; ++y2) {
                unsigned char c = 0x00;
                for (int x2 = 0; x2 < 8; x2++) {
                    int d = pictureS[x * 8 + x2 + (y * 8 + y2) * pictureWidth];
                    int b = (d & 255) < 128 ? 0 : 1;
                    c |= b << (7 - x2);
                }
                d[y2] = c;
            }
            int found = -1;
            for (int i = 0; i < charset2.size(); i += 8) {
                found = i / 8;
                for (int j = 0; j < 8; ++j)
                    if (charset2[i + j] != d[j])
                        found = -1;
                if (found != -1)
                    break;
            }
            if (found == -1) {
                found = charset2.size() / 8;
                for (int i = 0; i < 8; ++i)
                    charset2.push_back(d[i]);
            }
            colorandscreenram[(x + 5) + (y + 18) * 40 + 0x400] = found + 0x80; // from $0400 onwards
            colorandscreenram[(x + 5) + (y + 18) * 40] = 0x71;
        }
    }


    out = fopen((basePath + "generated/hud_screenram.bin").c_str(), "wb");
    fwrite(&(colorandscreenram[0]), 1, colorandscreenram.size(), out);
    fclose(out);
    out = fopen((basePath + "generated/hud_screenramc64.bin").c_str(), "wb");
    fwrite(&(colorandscreenram[0x400]), 1, 0x400, out);
    fclose(out);
    out = fopen((basePath + "generated/hud_charset.bin").c_str(), "wb");
    fwrite(&(charset[0*8]), 1, charset.size(), out);
    fclose(out);
    out = fopen((basePath + "generated/hud_charset2.bin").c_str(), "wb");
    fwrite(&(charset2[0 * 8]), 1, charset2.size(), out);
    fclose(out);

    //exportTestRoom();
    //generateTestFrame("generated/testFrame.bin");

    glfwSetErrorCallback(glfw_error_callback);
    if (!glfwInit())
        return 1;

    // Decide GL+GLSL versions
#if __APPLE__
    // GL 3.2 + GLSL 150
    const char* glsl_version = "#version 150";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);  // 3.2+ only
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);            // Required on Mac
#else
    // GL 3.0 + GLSL 130
    const char* glsl_version = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);  // 3.2+ only
    //glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);            // 3.0+ only
#endif

    window = glfwCreateWindow(1920-200, 1080-200, "RayView Editor", NULL, NULL);
    if (window == NULL)
        return 1;
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync

#if defined(IMGUI_IMPL_OPENGL_LOADER_GL3W)
    bool err = gl3wInit() != 0;
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLEW)
    bool err = glewInit() != GLEW_OK;
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLAD)
    bool err = gladLoadGL() == 0;
#else
    bool err = false; // If you use IMGUI_IMPL_OPENGL_LOADER_CUSTOM, your loader is likely to requires some form of initialization.
#endif
    if (err)
    {
        fprintf(stderr, "Failed to initialize OpenGL loader!\n");
        return 1;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    ImGui::StyleColorsDark();

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init(glsl_version);

    bool show_demo_window = true;
    bool show_another_window = false;
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    // load default settings if any
    ImGui::LoadIniSettingsFromDisk("defaultImguiSettings.dat");

    GuiData* data = new GuiData();

    data->load(basePath + SAVE_FILENAME);
    GuiData::XTexture t;
    loadTexture("data/texture3.png", &t);
    saveTexture("generated/texture3.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/background_nature.png", &t, true, 256);
    saveTexture("generated/background_nature.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_girl1.png", &t);
    saveTexture("generated/billboard_girl1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_tree2.png", &t);
    saveTexture("generated/billboard_tree2.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_grass1.png", &t);
    saveTexture("generated/billboard_grass1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_fences1.png", &t);
    saveTexture("generated/texture_fences1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_textline1.png", &t);
    saveTexture("generated/texture_textline1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_door1.png", &t);
    saveTexture("generated/texture_door1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_wall3.png", &t);
    saveTexture("generated/texture_wall3.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_emblem1.png", &t);
    saveTexture("generated/texture_emblem1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_bowel1.png", &t);
    saveTexture("generated/billboard_bowel1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_emblem2.png", &t);
    saveTexture("generated/texture_emblem2.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_textline2.png", &t);
    saveTexture("generated/texture_textline2.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_wall4.png", &t);
    saveTexture("generated/texture_wall4.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_marble1.png", &t);
    saveTexture("generated/texture_marble1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_wichtel1.png", &t);
    saveTexture("generated/billboard_wichtel1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_ceillamp1.png", &t);
    saveTexture("generated/billboard_ceillamp1.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_wall5.png", &t);
    saveTexture("generated/texture_wall5.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/background_castle.png", &t, true, 256);
    saveTexture("generated/background_castle.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_girl2.png", &t);
    saveTexture("generated/billboard_girl2.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_wall2.png", &t);
    saveTexture("generated/texture_wall2.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/billboard_girl3.png", &t);
    saveTexture("generated/billboard_girl3.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/background_cave.png", &t, true, 256);
    saveTexture("generated/background_cave.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/texture_wall6.png", &t);
    saveTexture("generated/texture_wall6.bin", &t);
    data->textures.textures.push_back(t);
    loadTexture("data/overlay_curtain.png", &t);
    saveTexture("generated/overlay_curtain.bin", &t);
    data->textures.textures.push_back(t);

    exportTextureDefinitions("generated/texturedefinitions.inc",data->textures.textures);

    // Main loop
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        paint_views(data);

        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }
    endObjectMoveMode(data, true);

    data->save(basePath + SAVE_FILENAME);

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}

