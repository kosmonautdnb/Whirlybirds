#define _CRT_SECURE_NO_WARNINGS
#include "view_modeselect.h"
#include "nativefiledialog/nfd.h"
#include "guidata.h"
#include "imgui/imgui.h"
#include "bsp_exporter.h"
namespace g = ImGui;

extern std::string basePath;

void paint_modeselect(GuiData* data) {
	g::Begin("Edit Mode");
	g::RadioButton("VertexMode", &(data->editMode), MODE_VERTEXMODE);
	g::Separator();
	if (g::Button("Save Scene")) {
		data->save(basePath + SAVE_FILENAME);
	}
	if (g::Button("Render Bsp")) {
		saveBsp(data, BSP_FILENAMESTEM);
	}
	g::InputInt("HighlightRoomNr##SPBD", &(data->highlighRoomNr));
	int polyCount = 0;
	for (int i = 0; i < data->scene.polys.size(); ++i) {
		if (data->scene.polys[i].hasFloor) polyCount++;
		if (data->scene.polys[i].hasCeiling) polyCount++;
	}
	g::Text("Poly Count:%d\n", polyCount);
	g::Text("Point Count:%d\n", data->scene.points.size());
	g::Text("BillBoard Count:%d\n", data->scene.billboards.size());
	g::Text("Rectangle Count:%d\n", data->scene.rectangles.size());
	g::Text("Last BSP ByteSize:$%04x <%d>\n", data->bspByteSize, data->bspByteSize);
	g::InputInt("CeilY##MSL", &(data->scene.ceilingHeight));
	g::InputInt("FloorY##MSL", &(data->scene.floorHeight));
	g::Checkbox("showAllBSPPlanes##MSL", &(data->showAllBSPPlanes));
	static double scaleBy = 1.0;
	g::InputDouble("ScaleBy##MSL", &scaleBy);
	if (g::Button("scaleAll##MSL")) {
		for (int i = 0; i < data->scene.points.size(); ++i) {
			data->scene.points[i].x *= scaleBy;
			data->scene.points[i].y *= scaleBy;
		}
		for (int i = 0; i < data->selectedPoints.size(); ++i) {
			data->selectedPoints[i].x *= scaleBy;
			data->selectedPoints[i].y *= scaleBy;
		}
	}
	g::InputInt("StartRoom##SPBD", &(data->scene.rootRoom));
	if (g::Button("ClearAllOtherRoomPolys##SPBD")) {
		for (int i = data->scene.polys.size() - 1; i >= 0; --i) {
			data->scene.polys[i].otherRoomPoly = -1;
			if (data->scene.polys[i].isOtherRoomPoly)
				data->scene.polys.erase(data->scene.polys.begin() + i);
		}
	}
	g::End();
}