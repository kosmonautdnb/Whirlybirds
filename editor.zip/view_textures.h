#pragma once

void paint_textures(class GuiData *data);