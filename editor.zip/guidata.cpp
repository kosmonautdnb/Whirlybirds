#include "guidata.h"

#include "nativefiledialog/nfd.h"
#include "imgui/imgui.h"
namespace g = ImGui;

void GuiData::XTexture::serialize(class Serializer& ser) {
}

void GuiData::XTextures::serialize(class Serializer& ser) {
}

void GuiData::X3DEngine::serialize(Serializer& ser) {
	ser.serialize("playerRotation", playerRotation);
	ser.serialize("playerPosX", playerPosX);
	ser.serialize("playerPosY", playerPosY);
	ser.serialize("playerHeight", playerHeight);
}

void GuiData::XPoly::serialize(Serializer& ser) {
	ser.serialize("modifierId", modifierId);
	ser.serialize("hasModifier", hasModifier);
	ser.serialize("otherRoomPoly", otherRoomPoly);
	ser.serialize("isOtherRoomPoly", isOtherRoomPoly);
	ser.serialize("id1", id1);
	ser.serialize("id2", id2);
	ser.serialize("ceiling_tx1", ceiling_tx1);
	ser.serialize("ceiling_tx2", ceiling_tx2);
	ser.serialize("floor_tx1", floor_tx1);
	ser.serialize("floor_tx2", floor_tx2);
	ser.serialize("divisions", divisions);
	ser.serialize("hasCeiling", hasCeiling);
	ser.serialize("hasFloor", hasFloor);
	ser.serialize("ceilingNormalFlipped", ceilingNormalFlipped);
	ser.serialize("floorWithTransparencies", floorWithTransparencies);
	ser.serialize("floorDoubleSided", floorDoubleSided);
	ser.serialize("ceilingDoubleSided", ceilingDoubleSided);
	ser.serialize("isFloorDoor", isFloorDoor);
	ser.serialize("ceiling_up", ceiling_up);
	ser.serialize("ceiling_down", ceiling_down);
	ser.serialize("floor_up", floor_up);
	ser.serialize("floor_down", floor_down);
	ser.serialize("floor_color_up", floor_color_up);
	ser.serialize("floor_color_down", floor_color_down);
	ser.serialize("floor_color_backface_span", floor_color_backface_span);
	ser.serialize("ceiling_color_up", ceiling_color_up);
	ser.serialize("ceiling_color_down", ceiling_color_down);
	ser.serialize("ceiling_color_backface_span", ceiling_color_backface_span);
	ser.serialize("floor_has_start_white_line", floor_has_start_white_line);
	ser.serialize("ceiling_has_start_white_line", ceiling_has_start_white_line);
	ser.serialize("textureFloor", textureFloor);
	ser.serialize("textureCeiling", textureCeiling);
	ser.serialize("portal", portal);
	ser.serialize("portalWithSpan", portalWithSpan);
	ser.serialize("roomNr", roomNr);
	ser.serialize("portalRoomNrBack", portalRoomNrBack);
	ser.serialize("hasRectangle", hasRectangle);
	ser.serialize("rectangleNr", rectangleNr);
}

void GuiData::XBillBoard::serialize(Serializer& ser) {
	ser.serialize("id", id);
	ser.serialize("ground", ground);
	ser.serialize("height", height);
	ser.serialize("width", width);
	ser.serialize("texture", texture);
	ser.serialize("roomNr", roomNr);
	ser.serialize("colorUp", colorUp);
	ser.serialize("colorDown", colorDown);
	ser.serialize("hasRectangle", hasRectangle);
	ser.serialize("rectangleNr", rectangleNr);
	ser.serialize("ceilingBillboard", ceilingBillboard);
	ser.serialize("hasModifier", hasModifier);
	ser.serialize("modifierId", modifierId);
}

void GuiData::XPoint::serialize(Serializer& ser) {
	ser.serialize("x", x);
	ser.serialize("y", y);
}

void GuiData::XRect::serialize(Serializer& ser) {
	ser.serialize("id1", id1);
	ser.serialize("id2", id2);
	ser.serialize("expandX", expandX);
	ser.serialize("expandY", expandY);
	ser.serialize("polyNr", polyNr);
	ser.serialize("switchType", switchType);
	ser.serialize("switchNr", switchNr);
	ser.serialize("roomNr", roomNr);
	ser.serialize("portalRoomNrBack", portalRoomNrBack);
	ser.serialize("enabled", enabled);
}

void GuiData::XBBox::serialize(Serializer& ser) {
	ser.serialize("xmin", xmin);
	ser.serialize("ymin", ymin);
	ser.serialize("xmax", xmax);
	ser.serialize("ymax", ymax);
}

void GuiData::XScene::serialize(Serializer& ser) {
	ser.serialize("sceneBound", sceneBound);
	ser.serialize("polys", polys);
	ser.serialize("points", points);
	ser.serialize("billboards", billboards);
	ser.serialize("rectangles", rectangles);
	ser.serialize("zoom", zoom);
	ser.serialize("center", center);
	ser.serialize("floorHeight", floorHeight);
	ser.serialize("ceilingHeight", ceilingHeight);
	ser.serialize("rootRoom", rootRoom);
}

void GuiData::serialize(Serializer& ser) {
	ser.serialize("editMode", editMode);
	ser.serialize("texCoordToWorld", texCoordToWorld);
	ser.serialize("scene", scene);
	ser.serialize("engine", engine);
}

#define Logit(...) { printf(__VA_ARGS__); printf("\n");}  

void GuiData::load(const std::string& path) {
	Logit("loading project file:%s", path.c_str());
	Serializer ser(true);
	ser.jsVal = toJson(stringFromFile(path));
	ser.serialize("DataFile", *this);
}

void GuiData::save(const std::string& path) {
	Logit("saving project file:%s", path.c_str());
	Serializer ser(false);
	ser.serialize("DataFile", *this);
	std::string json = toString(ser.jsVal);
	toFileReadableJson(json, path);
}
