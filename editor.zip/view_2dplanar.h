#pragma once

void paint_2dplanar(class GuiData *data);