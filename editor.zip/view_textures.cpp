#define _CRT_SECURE_NO_WARNINGS
#include "view_2dplanar.h"
#include "imgui/imgui.h"
#include "guidata.h"
namespace g = ImGui;

void paint_textures(GuiData* data) {
}
