#define _CRT_SECURE_NO_WARNINGS
#include "view_3dengine.h"
#include "imgui/imgui.h"
#include "guidata.h"
#include "bitmaps.h"
namespace g = ImGui;

const int SCREENX8 = 40;
const int SCREENY8 = 24;

#include "bsp_exporter.h"
extern ROOM currentBSPRoom;

const int backgroundColor = 0x00;
std::vector<unsigned char> xcols = { 0x53,0x32,0x00,0x71,0x44 };

std::vector<int> clipUp(SCREENX8 * 4), clipDown(SCREENX8 * 4);

bool paintPlus4Bitmap(Plus4Bitmap& bitmap, float zoomX, float zoomY) {
	g::Image((void*)bitmap.openGLId, ImVec2(bitmap.width * zoomX, bitmap.height * zoomY));
	return g::IsItemHovered();
}

Plus4Bitmap engineScreen;
double nearPlane = 0.0;
double farPlane = nearPlane + 256.0*4;

double translatedPlayerPosX, translatedPlayerPosY;

class TransformedPoint {
public:
	int pX = -1;
	double depthScale = -1;
	bool nearClip = false, farClip = false;
};

class POINT2DX {
public:
	double x, y;
};

POINT2DX rotated(GuiData *data, POINT2D p) {
	POINT2DX k,k2;
	k.x = (double)p.x - translatedPlayerPosX;
	k.y = (double)p.y - translatedPlayerPosY;
	double sn = sin((double)data->engine.playerRotation / 0x10000 * 2.0 * 3.14159) * 0.5f; // -$8000 to $7ffff
	double cs = cos((double)data->engine.playerRotation / 0x10000 * 2.0 * 3.14159) * 0.5f; // -$8000 to $7ffff
	k2.x = (k.x * cs + k.y * sn) * 8;
	k2.y = (k.x * -sn + k.y * cs);
	return k2;
}

double persp(double k, double z) {
	double r = 12 / (z+1);
	if (r > (double)0xffff/0x10000)
		r = (double)0xffff/0x10000;
	return k * r;
}

TransformedPoint transformPoint(GuiData* data, POINT2DX p) {
	TransformedPoint ret;
	if (p.y < nearPlane) {
		ret.nearClip = true;
	}
	if (p.y > farPlane) {
		ret.farClip = true;
	}
	if (!ret.nearClip) {
		ret.pX = (int)(persp(p.x*0.25,p.y*0.25) + SCREENX8 * 4 / 2);
		ret.depthScale = persp(1.0,(int)p.y*0.25);
	}
	return ret;
}

double getHeight(GuiData* data, double depthScale, double y) {
	return (y * 4 + data->engine.playerHeight) * depthScale + SCREENY8*4/2;
}

double tx_start;
double tx_end;

void paintPoly(GuiData* data, TransformedPoint p0, TransformedPoint p1, POLY &p, const Plus4Bitmap& screen, ROOM& room, bool billboard = false) {
	int xs = p0.pX;
	int xe = p1.pX;
	
	if (billboard) {
		xs -= p.billBoardWidth * p0.depthScale;
		xe += p.billBoardWidth * p0.depthScale;
	}

	if (xe <= 0 || xs >= SCREENX8*4)
		return;
	int xl = xe - xs;
	if (xl <= 0)
		return;
	double topLeft = getHeight(data, p0.depthScale, p.top);
	double topRight = getHeight(data, p1.depthScale, p.top);
	double bottomLeft = getHeight(data, p0.depthScale, p.bottom);
	double bottomRight = getHeight(data, p1.depthScale, p.bottom);
	double texLeft = tx_start;
	double texRight = tx_end;
	if (billboard) {
		texLeft = 0;
		texRight = data->getTexture(p.texture).convertedWidth * 0x100;
	}

	double topYPos = topLeft;
	double bottomYPos = bottomLeft;
	double texPos = texLeft;
	double topYAdd = (topRight - topLeft) / xl;
	double bottomYAdd = (bottomRight - bottomLeft) / xl;
	double texAdd = (texRight - texLeft) / xl;

	if (xs < 0) {
		topYPos += -xs * topYAdd;
		bottomYPos += -xs * bottomYAdd;
		texPos += -xs * texAdd;
		xs = 0;
	}
	
	if (xe > SCREENX8 * 4)
		xe = SCREENX8 * 4;

	if (xe - xs <= 0)
		return;

	GuiData::XTexture& tex = data->getTexture(p.texture);
	for (int i = xs; i < xe; ++i) {
		int yp = (int)topYPos;
		while (yp < (int)bottomYPos) {
			if (yp >= SCREENY8 * 4)
				break;
			if (yp >= 0) {
				if (yp >= clipUp[i] && yp < clipDown[i]) {
					int tx = (int)(((double)texPos/0x100)*tex.width/tex.convertedWidth + tex.width) % tex.width;
					int ty = (int)((yp - (int)topYPos) * tex.height / ((int)bottomYPos - (int)topYPos) + tex.height) % tex.height;
					int col = tex.pixels[tx + ty * tex.width];
					if (col < 4)
					engineScreen.pixels[i + yp * engineScreen.width] = (int)xcols[col];
				}
			}
			yp++;
		}
		if (p.stalagmite) {
			if (topYPos < clipDown[i]) {
				if (topYPos >= clipUp[i])
					clipDown[i] = topYPos;
				else
					clipDown[i] = clipUp[i];
			}
		}
		else {
			if (bottomYPos > clipUp[i]) {
				if (bottomYPos < clipDown[i])
					clipUp[i] = bottomYPos;
				else
					clipUp[i] = clipDown[i];
			}
		}
		topYPos += topYAdd;
		bottomYPos += bottomYAdd;
		texPos += texAdd;
	}
}

POINT2D getPoint(const ROOM &room, int id) {
	if (id & FLAG_SPECIALPOINT) {
		POINT2D ret;
		ret.x = room.specialpoints[id & (~FLAG_SPECIALPOINT)].calcedX;
		ret.y = room.specialpoints[id & (~FLAG_SPECIALPOINT)].calcedY;
		return ret;
	}
	return room.points[id];
}

void paintPolys(GuiData* data, BSP* node, const Plus4Bitmap& screen, ROOM& room) {
	for (int i = 0; i < node->polyIndex.size(); ++i) {
		POLY p = room.polies[node->polyIndex[i]];
		switch (p.polyType) {
		case POLYTYPE_SPAN: {
			POINT2DX i0 = rotated(data, getPoint(room, p.id_start));
			POINT2DX i1 = rotated(data, getPoint(room, p.id_end));
			TransformedPoint p0 = transformPoint(data, i0);
			TransformedPoint p1 = transformPoint(data, i1);
			tx_start = p.tx_start;
			tx_end = p.tx_end;
			if (p0.nearClip && p1.nearClip)
				continue;
			if (p0.farClip && p1.farClip)
				continue;
			if (p0.nearClip) {
				int factor = (double)(nearPlane - i0.y) * 0x10000 / abs(i1.y - i0.y);
				i0.x += (i1.x - i0.x) * factor / 0x10000;
				tx_start += (tx_end - tx_start) * factor / 0x10000;
				i0.y = nearPlane;
				p0 = transformPoint(data, i0);
			}
			if (p1.nearClip) {
				double factor = (double)(nearPlane - i1.y) * 0x10000 / abs(i1.y - i0.y);
				i1.x += (i1.x - i0.x) * factor / 0x10000;
				tx_end += (tx_end - tx_start) * factor / 0x10000;
				i1.y = nearPlane;
				p1 = transformPoint(data, i1);
			}
			if (p0.farClip) {
				i0.y = farPlane;
				p0 = transformPoint(data, i0);
			}
			if (p1.farClip) {
				i1.y = farPlane;
				p1 = transformPoint(data, i1);
			}
			paintPoly(data, p0, p1, p, screen, room);
			break;
		}
		case POLYTYPE_PORTAL: {
			break;
		}
		case POLYTYPE_BILLBOARD: {
			POINT2DX i0 = rotated(data, getPoint(room, p.id_start));
			TransformedPoint p0 = transformPoint(data, i0);
			if (p0.nearClip)
				continue;
			if (p0.farClip)
				continue;
			paintPoly(data, p0, p0, p, screen, room, true);
			break;
		}
		}
	}
}

void paintBspNode(GuiData *data, int nr, const Plus4Bitmap& screen, ROOM &room) {
	if (nr == -1)
		return;
	BSP* node = room.bsp[nr];
	double nx = node->plane.nx;
	double ny = node->plane.ny;
	double px = node->plane.px;
	double py = node->plane.py;
	double dotti = nx * (translatedPlayerPosX - px) + ny * (translatedPlayerPosY - py);
	if (dotti >= 0) { // bmi otherorder
		paintBspNode(data, node->computedLeftArrayIndex, screen, room);
		paintPolys(data, node, screen, room);
		paintBspNode(data, node->computedRightArrayIndex, screen, room);
	}
	else {
		paintBspNode(data, node->computedRightArrayIndex, screen, room);
		paintPolys(data, node, screen, room);
		paintBspNode(data, node->computedLeftArrayIndex, screen, room);
	}
}

void paintBsp(GuiData *data,ROOM &room, const Plus4Bitmap &screen) {
	if (room.bsp.empty())
		return;
	paintBspNode(data, 0, screen, room);
}

void paint_3dengine(GuiData* data) {
	g::SetNextWindowSize(ImVec2(640, 480), ImGuiCond_FirstUseEver);
	g::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1));
	g::Begin("3D Engine View");

	if (engineScreen.width == 0) {
		engineScreen.width = SCREENX8 * 4;
		engineScreen.height = SCREENY8 * 4;
		engineScreen.pixels.resize(engineScreen.width * engineScreen.height);
	}

	translatedPlayerPosX = data->engine.playerPosX;
	translatedPlayerPosY = -data->engine.playerPosY;

	for (int i = 0; i < engineScreen.width * engineScreen.height; ++i) engineScreen.pixels[i] = xcols[backgroundColor];
	for (int i = 0; i < SCREENX8 * 4; ++i) {
		clipUp[i] = 0;
		clipDown[i] = SCREENY8 * 4;
	}

	paintBsp(data,currentBSPRoom, engineScreen);

	engineScreen.upload(false);

	double zoomX = (double)640/engineScreen.width, zoomY = (double)480/engineScreen.height;

	g::BeginChild((ImGuiID)IMGUIID_3DENGINE, ImVec2(0, 0), false, 0);// ImGuiWindowFlags_AlwaysVerticalScrollbar | ImGuiWindowFlags_AlwaysHorizontalScrollbar);
	g::Image((void*)engineScreen.openGLId, ImVec2(engineScreen.width * zoomX, engineScreen.height * zoomY));
	g::EndChild();

	g::End();
	g::PopStyleColor();
}