#pragma once

void paint_help(class GuiData *data);