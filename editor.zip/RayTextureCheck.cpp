#define _CRT_SECURE_NO_WARNINGS
#include "texture_converter.h"
#include "bitmaps.h"
#include "guidata.h"

std::string basePath = "";

int main(int argc, const char* argv[])
{
    if (argc != 2) {
        printf("raytexturecheck usage:\n");
        printf("raytexturecheck.exe <inputpng.png>\n");
        return 0;
    }

    setupPalette("plus4ColsMeasured.asc");

    GuiData::XTexture t;
    loadTexture(argv[1], &t);
    saveTexture("checkTexture.bin", &t);
    return 0;
}

