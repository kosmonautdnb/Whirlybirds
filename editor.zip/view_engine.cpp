#define _CRT_SECURE_NO_WARNINGS
#include "view_3dengine.h"
#include "imgui/imgui.h"
#include "guidata.h"
#include "bitmaps.h"
namespace g = ImGui;

void paint_engine(GuiData* data) {
	g::Begin("Engine");
	g::InputInt("playerX", &data->engine.playerPosX);
	g::InputInt("playerY", &data->engine.playerPosY);
	g::InputInt("playerRot", &data->engine.playerRotation);
	g::InputInt("playerHeight", &data->engine.playerHeight);
	g::End();
}