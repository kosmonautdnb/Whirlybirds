#define _CRT_SECURE_NO_WARNINGS
#include "view_help.h"
#include "imgui/imgui.h"
#include "guidata.h"
namespace g = ImGui;

void paint_help(GuiData* data) {
	g::Begin("Help");
	g::Text("a = add vertex");
	g::Text("b = add billboard");
	g::Text("d = delete vertex");
	g::Text("d = delete face");
	g::Text("d = delete billboard");
	g::Text("s = place center");
	g::Text("t = split poly");
	g::Text("u = collapse");
	g::Text("x = lock mouse x");
	g::Text("y = lock mouse y");
	g::Text("z = snap to point");
	g::Text("i = invert normal");
	g::Text("shift = select add");
	g::Text("ctrl = select remove");
	g::Text("c = copy");
	g::Text("m = move");
	g::Text("p = place player");
	g::End();
}
