#define _CRT_SECURE_NO_WARNINGS

#include "bitmaps.h"
#include "png/png.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <istream>
#include <fstream>
#include <string>
#include <fstream>

unsigned int pictureS[MAXWIDTH*MAXHEIGHT];
unsigned int pictureWriteOut[MAXWIDTH*MAXHEIGHT];
int pictureWidth;
int pictureHeight;

extern "C"
{
#if defined(HAVE_LIBPNG) && defined(HAVE_LIBZ)
#  include <zlib.h>
#  ifdef HAVE_PNG_H
#    include <png.h>
#  else
#    include <libpng/png.h>
#  endif // HAVE_PNG_H
#endif // HAVE_LIBPNG && HAVE_LIBZ
}

#define PALENTRY(__a__) 0x##__a__

unsigned int paletteC64[17] = {
	PALENTRY(FF000000), // palette r is >> 16
	PALENTRY(FFFFFFFF),
	PALENTRY(FF7E352B),
	PALENTRY(FF6EB7C1),
	PALENTRY(FF7F3BA6),
	PALENTRY(FF5CA035),
	PALENTRY(FF332799),
	PALENTRY(FFCBD765),
	PALENTRY(FF85531C),
	PALENTRY(FF503C00),
	PALENTRY(FFB46B61),
	PALENTRY(FF4A4A4A),
	PALENTRY(FF757575),
	PALENTRY(FFA3E77C),
	PALENTRY(FF7064D6),
	PALENTRY(FFA3A3A3),

	PALENTRY(FFFF00FF)
};

#ifndef STANDALONE
#include "imgui/examples/libs/gl3w/GL/gl3w.h"
#endif

unsigned int getPalette(unsigned char color) {
	return ((palette[color] >> 16) & 255) | (palette[color] & 0x0000ff00) | ((palette[color] << 16) & 0x00ff0000) | 0xff000000;
}

unsigned int getPaletteC64(unsigned char color) {
	return ((paletteC64[color] >> 16) & 255) | (paletteC64[color] & 0x0000ff00) | ((paletteC64[color] << 16) & 0x00ff0000) | 0xff000000;
}


void Plus4Bitmap::upload(bool asC64) {
#ifndef STANDALONE
	if (openGLId == 0)
		glGenTextures(1, &openGLId);
	glBindTexture(GL_TEXTURE_2D, openGLId);
	std::vector<unsigned int> data;
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			if (!asC64 || (pixels[x + y * width] > 16))
				data.push_back(getPalette(pixels[x + y * width]));
			else
				data.push_back(getPaletteC64(pixels[x + y * width]));
		}
	}
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data.data());
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glBindTexture(GL_TEXTURE_2D, 0x00);
#endif
}

/**
  The constructor loads the named PNG image from the given png filename.
  <P>The destructor free all memory and server resources that are used by
  the image.
*/
void LoadPNG(const char *png) // I - File to read
{
  int		i;			// Looping var
  FILE		*fp;			// File pointer
  int		channels;		// Number of color channels
  png_structp	pp;			// PNG read pointer
  png_infop	info;			// PNG info pointers
  png_bytep	*rows;			// PNG row pointers

  memset(pictureS, 0, sizeof(pictureS));

  // Open the PNG file...
  if ((fp = fopen(png, "rb")) == NULL) return;

  // Setup the PNG data structures...
  pp   = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
  info = png_create_info_struct(pp);

  if (setjmp(pp->jmpbuf))
  {
	  int debug = 1;
	  return;
  }

  // Initialize the PNG read "engine"...
  png_init_io(pp, fp);

  // Get the image dimensions and convert to grayscale or RGB...
  png_read_info(pp, info);

  if (info->color_type == PNG_COLOR_TYPE_PALETTE)
    png_set_expand(pp);

  if (info->color_type & PNG_COLOR_MASK_COLOR)
    channels = 3;
  else
    channels = 1;

  if ((info->color_type & PNG_COLOR_MASK_ALPHA) || info->num_trans)
    channels ++;

  int w = (int)(info->width);
  int h = (int)(info->height);
  int d = channels;
  pictureWidth = w;
  pictureHeight = h;

  if (info->bit_depth < 8)
  {
    png_set_packing(pp);
    png_set_expand(pp);
  }
  else if (info->bit_depth == 16)
    png_set_strip_16(pp);

#  if defined(HAVE_PNG_GET_VALID) && defined(HAVE_PNG_SET_TRNS_TO_ALPHA)
  // Handle transparency...
  if (png_get_valid(pp, info, PNG_INFO_tRNS))
    png_set_tRNS_to_alpha(pp);
#  endif // HAVE_PNG_GET_VALID && HAVE_PNG_SET_TRNS_TO_ALPHA

  unsigned char *array = (unsigned char *)pictureS;

  // Allocate pointers...
  rows = new png_bytep[h];

  for (i = 0; i < h; i ++)
    rows[i] = (png_bytep)(array + i * w * d); // we flip it

  // Read the image, handling interlacing as needed...
  for (i = png_set_interlace_handling(pp); i > 0; i --)
    png_read_rows(pp, rows, NULL, h);

#ifdef WIN32
  // Some Windows graphics drivers don't honor transparency when RGB == white
  if (channels == 4) 
  {
    // Convert RGB to 0 when alpha == 0...
    unsigned char *ptr = (unsigned char *)array;
    for (i = w * h; i > 0; i --, ptr += 4)
      if (!ptr[3]) ptr[0] = ptr[1] = ptr[2] = 0;
  }
#endif // WIN32

  if (channels == 3)
  {
	  unsigned char *array2 = new unsigned char[pictureWidth * pictureHeight * 4];
	  for (int i = w * h - 1; i >= 0; --i)
	  {
		  array2[i*4+0] = array[i*3+0];
		  array2[i*4+1] = array[i*3+1];
		  array2[i*4+2] = array[i*3+2];
		  array2[i*4+3] = 255;
	  }
	  memcpy(array, array2, w * h * 4);
	  delete[] array2;
  }

  // Free memory and return...
  delete[] rows;

  png_read_end(pp, info);
  png_destroy_read_struct(&pp, &info, NULL);

  fclose(fp);
}

void abort_(const char * s, ...)
{
	va_list args;
	va_start(args, s);
	vfprintf(stderr, s, args);
	fprintf(stderr, "\n");
	va_end(args);
	abort();
}

void SavePNG(const char* file_name, bool flipped)
{
	png_structp png_ptr;
	png_infop info_ptr;

	/* create file */
	FILE *fp = fopen(file_name, "wb");
	if (!fp)
		abort_("[write_png_file] File %s could not be opened for writing", file_name);


	/* initialize stuff */
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

	if (!png_ptr) {
		fclose(fp);
		abort_("[write_png_file] png_create_write_struct failed");
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		fclose(fp);
		abort_("[write_png_file] png_create_info_struct failed");
	}

	if (setjmp(png_jmpbuf(png_ptr))) {
		fclose(fp);
		abort_("[write_png_file] Error during init_io");
	}

	png_init_io(png_ptr, fp);

	/* write header */
	if (setjmp(png_jmpbuf(png_ptr))) {
		fclose(fp);
		abort_("[write_png_file] Error during writing header");
	}

	png_set_IHDR(png_ptr, info_ptr, pictureWidth, pictureHeight,
		8, PNG_COLOR_TYPE_RGBA, PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	png_write_info(png_ptr, info_ptr);


	/* write bytes */
	if (setjmp(png_jmpbuf(png_ptr))) {
		fclose(fp);
		abort_("[write_png_file] Error during writing bytes");
	}

	png_bytep * row_pointers;

	unsigned char *array = new unsigned char[pictureWidth * pictureHeight * 4 + 4];
	for (int i = pictureWidth * pictureHeight; i >= 0; --i)
	{
		array[i * 4 + 0] = ((unsigned char*)pictureWriteOut)[i * 4 + (flipped ? 2 : 0)];
		array[i * 4 + 1] = ((unsigned char*)pictureWriteOut)[i * 4 + 1];
		array[i * 4 + 2] = ((unsigned char*)pictureWriteOut)[i * 4 + (flipped ? 0 : 2)];
		array[i * 4 + 3] = ((unsigned char*)pictureWriteOut)[i * 4 + 3];
	}


	// Allocate pointers...
	row_pointers = new png_bytep[pictureHeight];

	for (int i = 0; i < pictureHeight; i++)
		row_pointers[i] = (png_bytep)(array + (i)* pictureWidth * 4); // we flip it

	png_write_image(png_ptr, row_pointers);

	/* end write */
	if (setjmp(png_jmpbuf(png_ptr)))
		abort_("[write_png_file] Error during end of write");

	png_write_end(png_ptr, NULL);

	/* cleanup heap allocation */
	delete[] row_pointers;

	fclose(fp);
}

unsigned int palette[256];

std::vector<std::string> split(const std::string& s, char seperator)
{
	std::vector<std::string> output;
	std::string::size_type prev_pos = 0, pos = 0;
	while ((pos = s.find(seperator, pos)) != std::string::npos)
	{
		std::string substring(s.substr(prev_pos, pos - prev_pos));
		output.push_back(substring);
		prev_pos = ++pos;
	}
	output.push_back(s.substr(prev_pos, pos - prev_pos)); // Last word
	return output;
}

void setupPalette(const std::string& paletteKichyPath) {
	std::ifstream file(paletteKichyPath);
	std::string zeile;
	int nr = 0;
	while (std::getline(file, zeile) && zeile != "") {
		std::vector<std::string> values = split(zeile, ' ');
		if (values.size() == 3) {
			int r = atoi(values[0].c_str());
			int g = atoi(values[1].c_str());
			int b = atoi(values[2].c_str());
			palette[nr] = b | (g << 8) | (r << 16) | 0xff000000;
			nr++;
		}
	}
	file.close();
}

int getPlus4Color(unsigned int color32) {
	bool a = (color32 >> 24) > 128;
	int r = color32 & 255;
	int g = (color32 >> 8) & 255;
	int b = (color32 >> 16) & 255;
	int lastDelta = 10000 * 10000;
	int ri = 0;
	unsigned int colorEnabled[16] = { 1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1 };

	for (int i = 0; i < 128; ++i)
	{
		int cr = (palette[i] >> 16) & 255;
		int cg = (palette[i] >> 8) & 255;
		int cb = palette[i] & 255;
		int dr = cr - r;
		int dg = cg - g;
		int db = cb - b;
		int d = dr * dr + dg * dg + db * db;

		if (d < lastDelta && (colorEnabled[i & 15] != 0))
		{
			lastDelta = d;
			ri = i;
		}
	}
	if ((ri & 0x0f) == 0x00)
		ri = 0;
	return ri;
}

void toPlus4Colors() {
	for (int i = 0; i < pictureWidth * pictureHeight; ++i) {
		pictureS[i] = getPlus4Color(pictureS[i]);
	}
}