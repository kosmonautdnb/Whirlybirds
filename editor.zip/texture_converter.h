#pragma once

#include <string>

void loadTexture(const std::string &fileName, void *dest, bool noTopBottomColors = false, int internalY = 256);
void saveTexture(const std::string& fileName, void* source);