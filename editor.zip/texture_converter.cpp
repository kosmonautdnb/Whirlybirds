#define _CRT_SECURE_NO_WARNINGS
#include "texture_converter.h"
#include <vector>
#include "bitmaps.h"
#include "guidata.h"

extern std::string basePath;

std::vector<unsigned char> cols = { 0x53,0x32,0x00,0x71,0x44 };
int colorChangeCount = -1;

int nearestColor(int plus4col, int* plus4cols)
{
    int color = palette[plus4col];
    int r = color & 255;
    int g = (color >> 8) & 255;
    int b = (color >> 16) & 255;
    int lastDelta = 10000 * 10000;
    int ri = 0;
    for (int i = 0; i < 4; ++i)
    {
        if (plus4cols[i] != -1)
        {
            int cr = (palette[plus4cols[i]]) & 255;
            int cg = (palette[plus4cols[i]] >> 8) & 255;
            int cb = (palette[plus4cols[i]] >> 16) & 255;
            int dr = cr - r;
            int dg = cg - g;
            int db = cb - b;
            int d = dr * dr + dg * dg + db * db;
            if (d < lastDelta)
            {
                lastDelta = d;
                ri = i;
            }
        }
    }
    //if (ri == 0) ri = 0x2D;
    return ri;
}

void loadTextureToConvert(const std::string& pngFile, int maxYHeight = -1) {
    LoadPNG((basePath + pngFile).c_str());
    if (maxYHeight != -1 && maxYHeight < pictureHeight) {
        for (int y = 0; y < maxYHeight; ++y) {
            for (int x = 0; x < pictureWidth; ++x) {
                pictureS[x + y * pictureWidth] = pictureS[x + y * pictureHeight / maxYHeight * pictureWidth];
            }
        }
        pictureHeight = maxYHeight;
    }
 
    toPlus4Colors();
    bool isHalvePixelTexture = true;
    for (int x = 0; x < pictureWidth-1; x += 2) {
        for (int y = 0; y < pictureHeight; ++y) {
            bool isSame = pictureS[x + y * pictureWidth] == pictureS[(x + 1) + y * pictureWidth];
            if (!isSame) {
                isHalvePixelTexture = false;
                break;
            }
        }
    }
    if (isHalvePixelTexture) {
        std::vector<int> k(pictureWidth / 2 * pictureHeight);
        for (int x = 0; x < pictureWidth; x += 2) {
            for (int y = 0; y < pictureHeight; ++y) {
                k[x / 2 + y * pictureWidth/2] = pictureS[x + y * pictureWidth];
            }
        }
        pictureWidth /= 2;
        for (int x = 0; x < pictureWidth; x++)
            for (int y = 0; y < pictureHeight; ++y)
                pictureS[x + y * pictureWidth] = k[x + y * pictureWidth];
    }
    bool transparent = false;
    bool firstLineFullyTransparent = true;
    bool lastLineFullyTransparent = true;
    for (int i = 0; i < pictureWidth * pictureHeight; ++i) {
        unsigned int k = pictureS[i];
        for (int j = 0; j < cols.size(); ++j) {
            if (cols[j] == k) {
                k = j;
                break;
            }
        }
        pictureS[i] = k;
        if (k == 4)
            transparent = true;
        if (i < pictureWidth && k != 4)
            firstLineFullyTransparent = false;
        if (i > pictureWidth*pictureHeight-pictureWidth && k != 4)
            lastLineFullyTransparent = false;
    }
    if ((!firstLineFullyTransparent) && transparent) {
        for (int i = pictureWidth * pictureHeight - 1; i >= 0; --i) {
            pictureS[i + pictureWidth] = pictureS[i];
        }
        for (int i = 0; i < pictureWidth; ++i)
            pictureS[i] = 4;
        pictureHeight++;
    }

    //if ((!lastLineFullyTransparent) && transparent) {
    //    for (int i = 0; i < pictureHeight; ++i) {
    //        pictureS[i] = pictureS[i+pictureWidth];
    //    }
    //    for (int i = 0; i < pictureWidth; ++i)
    //        pictureS[i+pictureWidth*pictureHeight] = 4;
    //    pictureHeight++;
    //}
}

const int minSpanYLength = 0;

bool convertTexture(std::vector<unsigned char> &result, int textureWidth, bool noTopBottomColors = false, int internaly = 256) {
    int pictureHeightWithoutClip = noTopBottomColors ? pictureHeight : pictureHeight - 1; // last pixel is not taken into account

    struct SPAN {
        std::vector<unsigned char> doty;
        std::vector<unsigned char> color;
        int firstColor = -1;
        int lastColor = -1;
        bool equals(const SPAN& b) {
            if (b.doty.size() != doty.size())
                return false;
            for (int i = 0; i < doty.size(); ++i) {
                if (b.doty[i] != doty[i])
                    return false;
                if (b.color[i] != color[i])
                    return false;
            }
            if (b.firstColor != firstColor)
                return false;
            if (b.lastColor != lastColor)
                return false;
            return true;
        }
    };

    std::vector<int> selectedSpans;
    std::vector<SPAN> spans;

    unsigned char expand[8] = { 0b00000000,0b01010101,0b10101010,0b11111111,0b00000000,0b01010101,0b10101010,0b11111111};
    for (int x = 0; x < textureWidth; ++x) {
        int tx = pictureWidth * x / textureWidth;
        SPAN here;
        int lastColor = -1; // the upperst pixel is always stored
        int bottomColor = 0;
        int firstColor = 0;
        int lastAddedSpanY = -1;
        for (int y = 0; y < pictureHeightWithoutClip; ++y) {
            int c = pictureS[tx + y * pictureWidth];
            if (c != lastColor) {
                int eored = lastColor < 0 ? c : c ^ lastColor;
                if (y != 0) {
                    if (lastAddedSpanY == -1 || (y - lastAddedSpanY) >= minSpanYLength) {
                        lastColor = c;
                        lastAddedSpanY = y;
                        here.doty.push_back(y * internaly / pictureHeight);
                        here.color.push_back(expand[eored]);
                        bottomColor ^= eored;
                    }
                }
                else {
                    lastColor = c;
                    firstColor = eored;
                    bottomColor ^= eored;
                }
            }
        }
        here.firstColor = expand[firstColor];
        here.lastColor = expand[bottomColor];
        int found = -1;
        for (int i = 0; i < spans.size(); ++i) {
            if (spans[i].equals(here)) {
                found = i;
                break;
            }
        }
        if (found == -1) {
            selectedSpans.push_back(spans.size());
            spans.push_back(here);
        }
        else {
            selectedSpans.push_back(found);
        }
    }

    // serialize
    int dotCount = 0;
    for (auto& a : spans) {
        dotCount += a.doty.size();
    }

    colorChangeCount = dotCount;
    if (dotCount > 255) {
        return false;
    }

    std::vector<int> spanBegin;
    int k = 0;
    for (int i = 0; i < spans.size(); ++i) {
        spanBegin.push_back(k);
        k += spans[i].doty.size();
    }

    result.clear();
    unsigned char d;
    d = dotCount;
    result.push_back(d);
    d = textureWidth;
    result.push_back(d);
    for (int i = 0; i < textureWidth; ++i) {
        d = spanBegin[selectedSpans[i]];
        result.push_back(d);
    }
    for (int i = 0; i < textureWidth; ++i) {
        d = spans[selectedSpans[i]].doty.size() + spanBegin[selectedSpans[i]];
        result.push_back(d);
    }
    for (int i = 0; i < spans.size(); ++i) {
        for (int j = 0; j < spans[i].doty.size(); ++j) {
            d = (spans[i].doty[j] & (~0x03)) | (spans[i].color[j] & 0x03);
            result.push_back(d);
        }
    }
    //for (int i = 0; i < spans.size(); ++i) {
    //    for (int j = 0; j < spans[i].doty.size(); ++j) {
    //        d = spans[i].color[j];
    //        result.push_back(d);
    //    }
    //}
    if (!noTopBottomColors) {
        for (int i = 0; i < textureWidth; ++i) {
            d = (spans[selectedSpans[i]].firstColor & 0x03) | ((spans[selectedSpans[i]].lastColor & 0x03)<<2);
            result.push_back(d);
        }
        //for (int i = 0; i < textureWidth; ++i) {
        //    d = spans[selectedSpans[i]].lastColor;
        //    result.push_back(d);
        //}
    }
    return true;
}

bool convertTexture(const std::string& pngFile, std::vector<unsigned char>& result, int textureWidth) {
    loadTextureToConvert(pngFile);
    return convertTexture(result, textureWidth);
}

void loadTexture(const std::string& fileName, void *dest, bool noTopBottomColors, int internaly) {
    const int SCREENY8 = 24;
    loadTextureToConvert(fileName, noTopBottomColors ? -1 : SCREENY8*8/2);
    std::vector<unsigned char> result;
    int size = pictureWidth > 255 ? 255 : pictureWidth;
    int lowerBound = 0;
    int upperBound = size;
    bool first = true;

    int w = size;
    while(1) {
        std::vector<unsigned char> r2;
        bool res = convertTexture(r2, size, noTopBottomColors, internaly);
        if (first) {
            first = false;
            printf("color change count:%d\n", colorChangeCount);
        }

        if (!res) {
            if (lowerBound >= upperBound - 1)
                break;
            upperBound = size;
        }
        else {
            w = size;
            result = r2;
            if (lowerBound >= upperBound - 1)
                break;
            lowerBound = size;
        }
        size = (lowerBound + upperBound) >> 1;
    }
    printf("original width:%d\n", pictureWidth);
    printf("fitting width:%d\n", w);
    GuiData::XTexture *ret = (GuiData::XTexture*)dest;
    ret->convertedWidth = w;
    ret->width = pictureWidth;
    ret->height = pictureHeight;
    ret->fileName = fileName;
    ret->pixels = std::vector<unsigned int>(pictureS, pictureS + pictureWidth * pictureHeight);
    ret->converted = result;
}

void saveTexture(const std::string& fileName, void* source) {
    GuiData::XTexture* t = (GuiData::XTexture*)source;
    t->binFileName = fileName;
    FILE* out = fopen((basePath + fileName).c_str(), "wb");
    fwrite(&(t->converted[0]), 1, t->converted.size(), out);
    fclose(out);
}