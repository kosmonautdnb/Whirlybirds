#pragma once

#include <string>
#include <vector>

#define POLYTYPE_SPAN 0
#define POLYTYPE_BILLBOARD 1
#define POLYTYPE_PORTAL 2
#define POLYTYPE_PORTAL_WITH_SPAN 3
#define POLYTYPE_SEPERATOR 4

#define SWITCH_TYPE_PORTAL 0
#define SWITCH_TYPE_COLLISION 1

struct PLANE {
    char nx = -1, ny = -1;
    short px = -1, py = -1;
    bool equals(const PLANE& b) {
        if (nx != b.nx || ny != b.ny || px != b.px || py != b.py)
            return false;
        return true;
    }
};

class BSP {
public:
    std::vector<int> polyIndex;
    PLANE plane;
    BSP* left = nullptr, * right = nullptr;
    unsigned char height = 0;
    int roomNr = 0;
    int computedLeftArrayIndex = -1, computedRightArrayIndex = -1;
};

struct POINT2D {
    POINT2D(short x = 0, short y = 0) {
        this->x = x;
        this->y = y;
    }
    short x = 0, y = 0;
    bool equals(const class SPECIALPOINT& b);
};

#define FLAG_SPECIALPOINT 0x4000
class SPECIALPOINT {
public:
    unsigned int id1, id2;
    unsigned char interpolate;
    short calcedX, calcedY;
    bool equals(const SPECIALPOINT& b) {
        if (b.calcedX != calcedX)
            return false;
        if (b.calcedY != calcedY)
            return false;
        return true;
    }
};

struct POLY {
    bool stalagmite = false;
    bool hasWhiteStartLine = false;
    bool isTopAColorCorrectSpan = false;
    bool isBottomAColorCorrectSpan = false;
    bool floorWithBillboardTransparencies = false;
    bool isFloorDoor = false;
    int id_start = 0, id_end = 0;
    unsigned char texture = 0;
    int tx_start = 0;
    int tx_end = 0;
    char top = 0, bottom = 0;
    char topColor = 0, bottomColor = 0;
    int polyIndexHelper = 0;
    int polyType = POLYTYPE_SPAN;
    unsigned char billBoardWidth = 0;
    int roomNr = 0;
    int portalRoomNr = 0;
    bool doubleSided = false;
    int modifierId = -1;
    int originalId1 = -1, originalId2 = -1;
    int originalPolyId = -1;
};

struct RECT {
    int x0 = 0, y0 = 0, x1 = 0, y1 = 0;
    int type = 0;
    int px = 0, py = 0;
    int nx = 0, ny = 0;
    int roomNr = 0;
    int portalRoomNrBack = -1;
    int specialValue = 0;
};

struct ROOM {
    std::vector<BSP*> bsp;
    std::vector<POLY> polies;
    std::vector<POINT2D> points;
    std::vector<RECT> rectangles;
    std::vector<SPECIALPOINT> specialpoints;
};

ROOM getBsp(class GuiData* data);
void saveBsp(class GuiData *data, const std::string outputFileName);