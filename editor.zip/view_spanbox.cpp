#define _CRT_SECURE_NO_WARNINGS
#include "view_3dengine.h"
#include "imgui/imgui.h"
#include "guidata.h"
#include "bsp_exporter.h"
namespace g = ImGui;

bool maybeFlip(GuiData *data, std::vector<GuiData::XPoly*>& p, std::vector<GuiData::XPoly*>& endOnes) {
	const int p1 = endOnes[0]->id1;
	const int p2 = endOnes[0]->id2;
	if (((p1 & 0x10000) == 0) && ((p2 & 0x10000) == 0)) {
		const GuiData::XPoint& pp1 = data->scene.points[p1];
		const GuiData::XPoint& pp2 = data->scene.points[p2];
		double dx = pp2.x - pp1.x;
		double dy = pp2.y - pp1.y;
		double d = dx;
		if (abs(dx) < abs(dy))
			d = dy;
		return d > 0;
	}
	return false;
}

bool allPolysConnected(std::vector<GuiData::XPoly*> &p, std::vector<GuiData::XPoly*> &endOnes) {
	if (p.size() < 2)
		return false;
	bool allConnected = true;
	endOnes.clear();
	for (int i1 = 0; i1 < p.size(); ++i1) {
		GuiData::XPoly* p1 = p[i1];
		int connectedCount = 0;
		bool found = false;
		for (int i2 = 0; i2 < p.size(); ++i2) {
			GuiData::XPoly* p2 = p[i2];
			if (i1 != i2 && (p1->id1 == p2->id1 || p1->id2 == p2->id2 || p1->id1 == p2->id2 || p1->id2 == p2->id1)) {
				if (((p1->id1 & 0x10000) == 0) || ((p1->id2 & 0x10000) == 0)) {
					found = true;
					++connectedCount;
				}
			}
		}
		if (!found)
			allConnected = false;
		if (connectedCount == 1) {
			endOnes.push_back(p1);
		}
	}
	return allConnected;
}

double textureUniformLength(GuiData* data, std::vector<GuiData::XPoly*>& p) {
	double length = 0;
	for (auto& l : p) {
		int p1 = l->id1;
		int p2 = l->id2;
		if (((p1 & 0x10000) == 0) && ((p2 & 0x10000) == 0)) {
			const GuiData::XPoint& pp1 = data->scene.points[p1];
			const GuiData::XPoint& pp2 = data->scene.points[p2];
			double dx = pp2.x - pp1.x;
			double dy = pp2.y - pp1.y;
			double l = sqrt(dx * dx + dy * dy);
			length += l;
		}
	}
	return length;
}

void assignTextureUniform(GuiData *data, std::vector<GuiData::XPoly*>& p, std::vector<GuiData::XPoly*>& endOnes, bool floor, bool flipped) {
	double txStart, txEnd;
	if (floor) {
		txStart = endOnes[0]->floor_tx1;
		txEnd = endOnes[1]->floor_tx2;
	}
	else {
		txStart = endOnes[0]->ceiling_tx1;
		txEnd = endOnes[1]->ceiling_tx2;
	}
	double length = textureUniformLength(data, p);
	std::vector<GuiData::XPoly*> orig = p;
	std::vector<GuiData::XPoly*> sorted;
	GuiData::XPoly* current = endOnes[0];
	sorted.push_back(current);
	for (int i = 0; i < orig.size(); ++i) {
		if (orig[i] == current) {
			orig.erase(orig.begin() + i);
			break;
		}
	}
	bool nextOne;
	do {
		nextOne = false;
		for (int i = orig.size() - 1; i >= 0; --i) {
			GuiData::XPoly* h = orig[i];
			if (h != current && ((current->id1 == h->id1) || (current->id2 == h->id2) || (current->id1 == h->id2) || (current->id2 == h->id1))) {
				nextOne = true;
				sorted.push_back(h);
				orig.erase(orig.begin() + i);
				current = h;
			}
		}
	} while(nextOne);

	double currentL = 0;
	for (int i = 0; i < sorted.size(); ++i) {
		GuiData::XPoly* h = sorted[i];
		int p1 = h->id1;
		int p2 = h->id2;
		if (((p1 & 0x10000) == 0) && ((p2 & 0x10000) == 0)) {
			const GuiData::XPoint& pp1 = data->scene.points[p1];
			const GuiData::XPoint& pp2 = data->scene.points[p2];
			double dx = pp2.x - pp1.x;
			double dy = pp2.y - pp1.y;
			double l = sqrt(dx * dx + dy * dy);
			double currentL0 = currentL / length;
			currentL += l;
			double currentL1 = currentL / length;
			
			//if (flipped) {
			//	double t = currentL0;
			//	currentL0 = currentL1;
			//	currentL1 = t;
			//}
			
			if (floor) {
				if (h->textureFloor == endOnes[0]->textureFloor) {
					h->floor_tx1 = txStart + currentL0 * (txEnd - txStart);
					h->floor_tx2 = txStart + currentL1 * (txEnd - txStart);
				}
			}
			else {
				if (h->textureCeiling == endOnes[0]->textureCeiling) {
					h->ceiling_tx1 = txStart + currentL0 * (txEnd - txStart);
					h->ceiling_tx2 = txStart + currentL1 * (txEnd - txStart);
				}
			}
		}
	}
}

void bakeDivs(GuiData *data, int polyNr) {
	GuiData::XPoly poly = data->scene.polys[polyNr];
	int k = poly.divisions;
	int id1 = poly.id1;
	int id2 = poly.id2;
	double xs = data->scene.points[id1].x;
	double ys = data->scene.points[id1].y;
	double xe = data->scene.points[id2].x;
	double ye = data->scene.points[id2].y;
	double oldTxFloor = poly.floor_tx1;
	double oldTxCeil = poly.ceiling_tx1;
	int oldId = id1;
	for (int i = 1; i < k+1; ++i) {
		double f = (double)i / k;
		GuiData::XPoint p;
		p.x = (xe - xs) * f + xs;
		p.y = (ye - ys) * f + ys;
		int newId = data->scene.points.size();
		if (i != k)
			data->scene.points.push_back(p);
		const double newTxCeil = (poly.ceiling_tx2 - poly.ceiling_tx1) * f + poly.ceiling_tx1;
		const double newTxFloor = (poly.floor_tx2 - poly.floor_tx1) * f + poly.floor_tx1;
		GuiData::XPoly pl = poly;
		pl.ceiling_tx1 = oldTxCeil;
		pl.ceiling_tx2 = newTxCeil;
		pl.floor_tx1 = oldTxFloor;
		pl.floor_tx2 = newTxFloor;
		pl.id1 = oldId;
		pl.divisions = 1;
		if (i == k) {
			data->scene.polys[polyNr] = pl;
		}
		else {
			pl.id2 = newId; // last poly keeps its id2 (no point added also)
			data->scene.polys.push_back(pl);
		}
		oldId = newId;
		oldTxFloor = newTxFloor;
		oldTxCeil = newTxCeil;
	}
}

void paint_spanbox(GuiData* data) {
	g::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1));
	g::SetNextWindowSize(ImVec2(100, 200), ImGuiCond_FirstUseEver);
	g::Begin("SpanBox");

	int pointNr, polyNr, billBoardNr, rectNr;
	std::vector<GuiData::XPoint*> allPoints = data->collectAllSelectedPoints(pointNr);
	std::vector<GuiData::XPoly*> allPolys = data->collectAllSelectedPolys(polyNr);
	std::vector<GuiData::XBillBoard*> allBillBoards = data->collectAllSelectedBillBoards(billBoardNr);
	std::vector<GuiData::XRect*> allRectangles = data->collectAllSelectedRectangles(rectNr);

	if (!allPolys.empty()) {
		g::Separator();
		if (polyNr >= 0) {
			g::Text("PolyNr:%d", polyNr);
			GuiData::XPoly* poly = &data->scene.polys[polyNr];
			if (g::Checkbox("EditOtherRoomPoly##SPBD", &(poly->editOtherRoomPoly))) {
				if (poly->editOtherRoomPoly && ((unsigned int)poly->otherRoomPoly >= data->scene.polys.size())) {
					data->scene.polys[polyNr].otherRoomPoly = data->addPoly(*poly, true);
					GuiData::XPoly& op = data->scene.polys[data->scene.polys[polyNr].otherRoomPoly];
					op.isOtherRoomPoly = true;
					op.rectangleNr = -1;
					op.hasRectangle = false;
					g::End();
					g::PopStyleColor();
					return; // this modified data->scene.polys, so pointers aren't valid anymore
				}
			}
			if (poly->editOtherRoomPoly) {
				if ((unsigned int)poly->otherRoomPoly < data->scene.polys.size()) {
					g::Text("PolyNrOtherRoom:%d", poly->otherRoomPoly);
					poly = &data->scene.polys[poly->otherRoomPoly];
				}
			}
			g::Checkbox("IsPortal##SPBD", &(poly->portal));
			if (poly->portal) {
				g::Checkbox("portalWitSpan##SPBD", &(poly->portalWithSpan));
			}
			if ((!poly->portal) || poly->portalWithSpan) {
				g::InputInt("Div##SPBD", &(poly->divisions));
				if (poly->divisions > 1) {
					if (g::Button("Bake Divs##SPBD")) {
						bakeDivs(data, polyNr);
					}
				}
				g::InputInt("PNT1##SPBD", &(poly->id1));
				g::InputInt("PNT2##SPBD", &(poly->id2));
				g::Checkbox("Ceiling##SPBD", &(poly->hasCeiling));
				if (poly->hasCeiling) {
					g::Checkbox("CeilingNormalFlipped##SPBD", &(poly->ceilingNormalFlipped));
					g::InputInt("Ceil Up##SPBD", &(poly->ceiling_up));
					g::InputInt("Ceil Down##SPBD", &(poly->ceiling_down));
					g::InputInt("CeilTex##SPBD", &(poly->textureCeiling));
					g::InputDouble("Ceil_TX1##SPBD", &(poly->ceiling_tx1));
					g::InputDouble("Ceil_TX2##SPBD", &(poly->ceiling_tx2));
					g::InputInt("CeilColUp##SPBD", &(poly->ceiling_color_up));
					g::InputInt("CeilColDown##SPBD", &(poly->ceiling_color_down));
					g::Checkbox("CeilColSpan##SPBD", &(poly->ceiling_color_backface_span));
					g::Checkbox("CeilingDoubleSided##SPBD", &(poly->ceilingDoubleSided));
					g::Checkbox("CeilingWhiteLine##SPBD", &(poly->ceiling_has_start_white_line));
				}
				g::Checkbox("Floor##SPBD", &(poly->hasFloor));
				if (poly->hasFloor) {
					g::Checkbox("Floor Transparencies##SPBD", &(poly->floorWithTransparencies));
					g::InputInt("Floor Up##SPBD", &(poly->floor_up));
					g::InputInt("Floor Down##SPBD", &(poly->floor_down));
					g::InputInt("FloorTex##SPBD", &(poly->textureFloor));
					g::InputDouble("Floor_TX1##SPBD", &(poly->floor_tx1));
					g::InputDouble("Floor_TX2##SPBD", &(poly->floor_tx2));
					g::InputInt("FloorColUp##SPBD", &(poly->floor_color_up));
					g::InputInt("FloorColDown##SPBD", &(poly->floor_color_down));
					g::Checkbox("FloorColSpan##SPBD", &(poly->floor_color_backface_span));
					g::Checkbox("FloorDoubleSided##SPBD", &(poly->floorDoubleSided));
					g::Checkbox("FloorWhiteLine##SPBD", &(poly->floor_has_start_white_line));
					g::Checkbox("IsFloorDoor##SPBD", &(poly->isFloorDoor));
				}
			}
			g::InputInt("RoomNr##SPBD", &(poly->roomNr));
			if (poly->portal) {
				g::InputInt("PortalBackRoomNr##SPBD", &(poly->portalRoomNrBack));
			}
			g::Checkbox("HasModifier##SPBD", &(poly->hasModifier));
			if (poly->hasModifier)
				g::InputInt("ModifierId##SPBD", &(poly->modifierId));
			g::Checkbox("HasRectangle##SPBD", &(poly->hasRectangle));
			if (poly->hasRectangle)	{
				poly->rectangleNr = data->getAddRectangle(poly->rectangleNr);
				GuiData::XRect* rect = &(data->scene.rectangles[poly->rectangleNr]);
				rect->enabled = true;
				//rect->switchType = SWITCH_TYPE_PORTAL;
				//g::Text("RectNr:%d", poly.rectangleNr);
				//g::Text("PNT1:%d", rect->id1);
				//g::Text("PNT2:%d", rect->id2);
				//g::InputInt("RectExpandX##SPBD", &(rect->expandX));
				//g::InputInt("RectExpandY##SPBD", &(rect->expandY));
				//g::InputInt("SwitchNr##SPBD", &(rect->switchNr));
			}
			else {
				int nr = poly->rectangleNr;
				if (nr != -1) {
					GuiData::XRect* rect = &(data->scene.rectangles[nr]);
					rect->enabled = false;
				}
			}
			if (poly->isOtherRoomPoly && g::Button("Delete##SPBD")) {
				GuiData::XPoly* poly = &data->scene.polys[polyNr];
				data->removePoly(poly->otherRoomPoly);
			}
		}
		else {
			bool allTheSame_FLOOR_TX1 = true;
			bool allTheSame_FLOOR_TX2 = true;
			bool allTheSame_CEILING_TX1 = true;
			bool allTheSame_CEILING_TX2 = true;
			bool allTheSame_DIVISIONS = true;
			bool allTheSame_HASCEILING = true;
			bool allTheSame_HASFLOOR = true;
			bool allTheSame_CEILING_UP = true;
			bool allTheSame_CEILING_DOWN = true;
			bool allTheSame_FLOOR_UP = true;
			bool allTheSame_FLOOR_DOWN = true;
			bool allTheSame_TEXTUREFLOOR = true;
			bool allTheSame_TEXTURECEILING = true;
			bool allTheSame_PORTAL = true;
			bool allTheSame_PORTAL_WITH_SPAN = true;
			bool allTheSame_FLOOR_COLOR_UP = true;
			bool allTheSame_FLOOR_COLOR_DOWN = true;
			bool allTheSame_CEILING_COLOR_UP = true;
			bool allTheSame_CEILING_COLOR_DOWN = true;
			bool allTheSame_FLOOR_COLOR_BACKFACE_SPAN = true;
			bool allTheSame_CEILING_COLOR_BACKFACE_SPAN = true;
			bool allTheSame_ROOMNR = true;
			bool allTheSame_HASRECTANGLE = true;
			bool allTheSame_CEILINGNORMALFLIPPED = true;
			bool allTheSame_FLOORTRANSPARENCIES = true;
			bool allTheSame_FLOORDOUBLESIDED = true;
			bool allTheSame_CEILINGDOUBLESIDED = true;
			bool allTheSame_HASMODIFIER = true;
			bool allTheSame_MODIFIERID = true;
			bool allTheSame_ISFLOORDOOR = true;
			bool allTheSame_FLOORWHITELINE = true;
			bool allTheSame_CEILINGWHITELINE = true;
			for (int i = 1; i < allPolys.size(); ++i) {
				if (allPolys[i]->floor_tx1 != allPolys[0]->floor_tx1) allTheSame_FLOOR_TX1 = false;
				if (allPolys[i]->floor_tx2 != allPolys[0]->floor_tx2) allTheSame_FLOOR_TX2 = false;
				if (allPolys[i]->ceiling_tx1 != allPolys[0]->ceiling_tx1) allTheSame_CEILING_TX1 = false;
				if (allPolys[i]->ceiling_tx2 != allPolys[0]->ceiling_tx2) allTheSame_CEILING_TX2 = false;
				if (allPolys[i]->divisions != allPolys[0]->divisions) allTheSame_DIVISIONS = false;
				if (allPolys[i]->hasCeiling != allPolys[0]->hasCeiling) allTheSame_HASCEILING = false;
				if (allPolys[i]->hasFloor != allPolys[0]->hasFloor) allTheSame_HASFLOOR = false;
				if (allPolys[i]->ceiling_up != allPolys[0]->ceiling_up) allTheSame_CEILING_UP = false;
				if (allPolys[i]->ceiling_down != allPolys[0]->ceiling_down) allTheSame_CEILING_DOWN = false;
				if (allPolys[i]->floor_up != allPolys[0]->floor_up) allTheSame_FLOOR_UP = false;
				if (allPolys[i]->floor_down != allPolys[0]->floor_down) allTheSame_FLOOR_DOWN = false;
				if (allPolys[i]->textureFloor != allPolys[0]->textureFloor) allTheSame_TEXTUREFLOOR = false;
				if (allPolys[i]->textureCeiling != allPolys[0]->textureCeiling) allTheSame_TEXTURECEILING = false;
				if (allPolys[i]->ceiling_color_up != allPolys[0]->ceiling_color_up) allTheSame_CEILING_COLOR_UP = false;
				if (allPolys[i]->ceiling_color_down != allPolys[0]->ceiling_color_down) allTheSame_CEILING_COLOR_DOWN = false;
				if (allPolys[i]->floor_color_up != allPolys[0]->floor_color_up) allTheSame_FLOOR_COLOR_UP = false;
				if (allPolys[i]->floor_color_down != allPolys[0]->floor_color_down) allTheSame_FLOOR_COLOR_DOWN = false;
				if (allPolys[i]->ceiling_color_backface_span != allPolys[0]->ceiling_color_backface_span) allTheSame_CEILING_COLOR_BACKFACE_SPAN = false;
				if (allPolys[i]->floor_color_backface_span != allPolys[0]->floor_color_backface_span) allTheSame_FLOOR_COLOR_BACKFACE_SPAN = false;
				if (allPolys[i]->isFloorDoor != allPolys[0]->isFloorDoor) allTheSame_ISFLOORDOOR = false;

				if (allPolys[i]->portal != allPolys[0]->portal) allTheSame_PORTAL = false;
				if (allPolys[i]->portalWithSpan != allPolys[0]->portalWithSpan) allTheSame_PORTAL_WITH_SPAN = false;
				if (allPolys[i]->roomNr != allPolys[0]->roomNr) allTheSame_ROOMNR = false;
				if (allPolys[i]->hasRectangle != allPolys[0]->hasRectangle) allTheSame_HASRECTANGLE = false;
				if (allPolys[i]->ceilingNormalFlipped != allPolys[0]->ceilingNormalFlipped) allTheSame_CEILINGNORMALFLIPPED = false;
				if (allPolys[i]->floorWithTransparencies != allPolys[0]->floorWithTransparencies) allTheSame_FLOORTRANSPARENCIES = false;
				if (allPolys[i]->floorDoubleSided != allPolys[0]->floorDoubleSided) allTheSame_FLOORDOUBLESIDED = false;
				if (allPolys[i]->ceilingDoubleSided != allPolys[0]->ceilingDoubleSided) allTheSame_CEILINGDOUBLESIDED = false;
				if (allPolys[i]->ceiling_has_start_white_line != allPolys[0]->ceiling_has_start_white_line) allTheSame_CEILINGWHITELINE = false;
				if (allPolys[i]->floor_has_start_white_line != allPolys[0]->floor_has_start_white_line) allTheSame_FLOORWHITELINE = false;

				if (allPolys[i]->hasModifier != allPolys[0]->hasModifier) allTheSame_HASMODIFIER = false;
				if (allPolys[i]->modifierId != allPolys[0]->modifierId) allTheSame_MODIFIERID = false;
			}
			g::Text("Polys");
			bool b = false;
			if (!allTheSame_DIVISIONS && g::Checkbox("DIVS for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->divisions = allPolys[0]->divisions;
			if (allTheSame_DIVISIONS) g::InputInt("DIVS##SPBR", &(allPolys[0]->divisions));

			if (!allTheSame_HASCEILING && g::Checkbox("HasCeil for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasCeiling = allPolys[0]->hasCeiling;
			if (allTheSame_HASCEILING) {
				g::Checkbox("Ceiling##SPBR", &(allPolys[0]->hasCeiling));
				if (allPolys[0]->hasCeiling) {
					if (!allTheSame_CEILINGNORMALFLIPPED && g::Checkbox("CeilNormalFlipped for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceilingNormalFlipped = allPolys[0]->ceilingNormalFlipped;
					if (allTheSame_CEILINGNORMALFLIPPED) g::Checkbox("CeilNormalFlipped##SPBR", &(allPolys[0]->ceilingNormalFlipped));
					if (!allTheSame_CEILING_UP && g::Checkbox("CeilUp for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_up = allPolys[0]->ceiling_up;
					if (allTheSame_CEILING_UP) g::InputInt("CeilUp Height##SPBR", &(allPolys[0]->ceiling_up));
					if (!allTheSame_CEILING_DOWN && g::Checkbox("CeilDown for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_down = allPolys[0]->ceiling_down;
					if (allTheSame_CEILING_DOWN) g::InputInt("CeilDown Height##SPBR", &(allPolys[0]->ceiling_down));
					if (!allTheSame_TEXTURECEILING && g::Checkbox("CeilTex for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->textureCeiling = allPolys[0]->textureCeiling;
					if (allTheSame_TEXTURECEILING) g::InputInt("CEILTEX##SPBR", &(allPolys[0]->textureCeiling));
					if (!allTheSame_CEILING_TX1 && g::Checkbox("FloorTX1 for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_tx1 = allPolys[0]->ceiling_tx1;
					if (allTheSame_CEILING_TX1) g::InputDouble("CeilTX1##SPBR", &(allPolys[0]->ceiling_tx1));
					if (!allTheSame_CEILING_TX2 && g::Checkbox("FloorTX2 for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_tx2 = allPolys[0]->ceiling_tx2;
					if (allTheSame_CEILING_TX2) g::InputDouble("CeilTX2##SPBR", &(allPolys[0]->ceiling_tx2));
					if (!allTheSame_CEILING_COLOR_UP && g::Checkbox("CeilColUp for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_color_up = allPolys[0]->ceiling_color_up;
					if (allTheSame_CEILING_COLOR_UP) g::InputInt("CeilColUp##SPBR", &(allPolys[0]->ceiling_color_up));
					if (!allTheSame_CEILING_COLOR_DOWN && g::Checkbox("CeilColDown for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_color_down = allPolys[0]->ceiling_color_down;
					if (allTheSame_CEILING_COLOR_DOWN) g::InputInt("CeilColDown##SPBR", &(allPolys[0]->ceiling_color_down));
					if (!allTheSame_CEILING_COLOR_BACKFACE_SPAN && g::Checkbox("CeilColSpan for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_color_backface_span = allPolys[0]->ceiling_color_backface_span;
					if (allTheSame_CEILING_COLOR_BACKFACE_SPAN) g::Checkbox("CeilColSpan##SPBR", &(allPolys[0]->ceiling_color_backface_span));
					if (!allTheSame_CEILINGDOUBLESIDED && g::Checkbox("CeilDoubleSided for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceilingDoubleSided = allPolys[0]->ceilingDoubleSided;
					if (allTheSame_CEILINGDOUBLESIDED) g::Checkbox("CeilDoubleSided##SPBR", &(allPolys[0]->ceilingDoubleSided));
					if (!allTheSame_CEILINGWHITELINE && g::Checkbox("CeilWhiteline for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_has_start_white_line = allPolys[0]->ceiling_has_start_white_line;
					if (allTheSame_CEILINGWHITELINE) g::Checkbox("CeilWhiteline##SPBR", &(allPolys[0]->ceiling_has_start_white_line));
				}
			}

			if (!allTheSame_HASFLOOR && g::Checkbox("HasFloor for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasFloor = allPolys[0]->hasFloor;
			if (allTheSame_HASFLOOR) {
				g::Checkbox("Floor##SPBR", &(allPolys[0]->hasFloor));
				if (allPolys[0]->hasFloor) {
					if (!allTheSame_FLOORTRANSPARENCIES && g::Checkbox("FloorTransparencies for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floorWithTransparencies = allPolys[0]->floorWithTransparencies;
					if (allTheSame_FLOORTRANSPARENCIES) g::Checkbox("FloorTransparencies##SPBR", &(allPolys[0]->floorWithTransparencies));
					if (!allTheSame_FLOOR_UP && g::Checkbox("FloorUp for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_up = allPolys[0]->floor_up;
					if (allTheSame_FLOOR_UP) g::InputInt("FloorUp Height##SPBR", &(allPolys[0]->floor_up));
					if (!allTheSame_FLOOR_DOWN && g::Checkbox("FloorDown for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_down = allPolys[0]->floor_down;
					if (allTheSame_FLOOR_DOWN) g::InputInt("FloorDown Height##SPBR", &(allPolys[0]->floor_down));
					if (!allTheSame_TEXTUREFLOOR && g::Checkbox("FloorTex for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->textureFloor = allPolys[0]->textureFloor;
					if (allTheSame_TEXTUREFLOOR) g::InputInt("FLOORTEX##SPBR", &(allPolys[0]->textureFloor));
					if (!allTheSame_FLOOR_TX1 && g::Checkbox("FloorTX1 for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_tx1 = allPolys[0]->floor_tx1;
					if (allTheSame_FLOOR_TX1) g::InputDouble("FloorTX1##SPBR", &(allPolys[0]->floor_tx1));
					if (!allTheSame_FLOOR_TX2 && g::Checkbox("FloorTX2 for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_tx2 = allPolys[0]->floor_tx2;
					if (allTheSame_FLOOR_TX2) g::InputDouble("FloorTX2##SPBR", &(allPolys[0]->floor_tx2));
					if (!allTheSame_FLOOR_COLOR_UP && g::Checkbox("FloorColUp for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_color_up = allPolys[0]->floor_color_up;
					if (allTheSame_FLOOR_COLOR_UP) g::InputInt("FloorColUp##SPBR", &(allPolys[0]->floor_color_up));
					if (!allTheSame_FLOOR_COLOR_DOWN && g::Checkbox("FloorColDown for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_color_down = allPolys[0]->floor_color_down;
					if (allTheSame_FLOOR_COLOR_DOWN) g::InputInt("FloorColDown##SPBR", &(allPolys[0]->floor_color_down));
					if (!allTheSame_FLOOR_COLOR_BACKFACE_SPAN && g::Checkbox("FloorColSpan for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_color_backface_span = allPolys[0]->floor_color_backface_span;
					if (allTheSame_FLOOR_COLOR_BACKFACE_SPAN) g::Checkbox("FloorColSpan##SPBR", &(allPolys[0]->floor_color_backface_span));
					if (!allTheSame_FLOORDOUBLESIDED && g::Checkbox("FloorDoubleSided for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floorDoubleSided = allPolys[0]->floorDoubleSided;
					if (allTheSame_FLOORDOUBLESIDED) g::Checkbox("FloorDoubleSided##SPBR", &(allPolys[0]->floorDoubleSided));
					if (!allTheSame_ISFLOORDOOR && g::Checkbox("IsFloorDoor for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->isFloorDoor = allPolys[0]->isFloorDoor;
					if (allTheSame_ISFLOORDOOR) g::Checkbox("IsFloorDoor##SPBR", &(allPolys[0]->isFloorDoor));
					if (!allTheSame_FLOORWHITELINE && g::Checkbox("FloorWhiteline for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_has_start_white_line = allPolys[0]->floor_has_start_white_line;
					if (allTheSame_FLOORWHITELINE) g::Checkbox("FloorWhiteline##SPBR", &(allPolys[0]->floor_has_start_white_line));
				}
			}
			if (!allTheSame_ROOMNR && g::Checkbox("RoomNr for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->roomNr = allPolys[0]->roomNr;
			if (allTheSame_ROOMNR) g::InputInt("RoomNr##SPBR", &(allPolys[0]->roomNr));

			if (!allTheSame_HASMODIFIER && g::Checkbox("HasModifier for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasModifier = allPolys[0]->hasModifier;
			if (allTheSame_HASMODIFIER) g::Checkbox("HasModifier##SPBR", &(allPolys[0]->hasModifier));
			if (allTheSame_HASMODIFIER && (allPolys[0]->hasModifier)) {
				if (!allTheSame_MODIFIERID && g::Checkbox("ModifierID for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->modifierId = allPolys[0]->modifierId;
				if (allTheSame_MODIFIERID) g::InputInt("ModifierID##SPBR", &(allPolys[0]->modifierId));
			}

			if (!allTheSame_PORTAL && g::Checkbox("Portal for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->portal = allPolys[0]->portal;
			if (allTheSame_PORTAL) g::Checkbox("isPortal##SPBR", &(allPolys[0]->portal));
			if (allTheSame_PORTAL && allPolys[0]->portal) {
				if (!allTheSame_PORTAL_WITH_SPAN && g::Checkbox("PortalWithSpan for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->portalWithSpan = allPolys[0]->portalWithSpan;
				if (allTheSame_PORTAL_WITH_SPAN) g::Checkbox("portalWithSpan##SPBR", &(allPolys[0]->portalWithSpan));
			}
			if (!allTheSame_HASRECTANGLE && g::Checkbox("HasRectangle for all##SPBR", &b)) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasRectangle = allPolys[0]->hasRectangle;
			if (allTheSame_HASRECTANGLE) g::Checkbox("HasRectangle##SPBR", &(allPolys[0]->hasRectangle));

			if (allTheSame_FLOOR_TX1) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_tx1 = allPolys[0]->floor_tx1;
			if (allTheSame_FLOOR_TX2) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_tx2 = allPolys[0]->floor_tx2;
			if (allTheSame_CEILING_TX1) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_tx1 = allPolys[0]->ceiling_tx1;
			if (allTheSame_CEILING_TX2) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_tx2 = allPolys[0]->ceiling_tx2;
			if (allTheSame_DIVISIONS) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->divisions = allPolys[0]->divisions;
			if (allTheSame_HASFLOOR) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasFloor = allPolys[0]->hasFloor;
			if (allTheSame_HASCEILING) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasCeiling = allPolys[0]->hasCeiling;
			if (allTheSame_CEILING_UP) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_up = allPolys[0]->ceiling_up;
			if (allTheSame_CEILING_DOWN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_down = allPolys[0]->ceiling_down;
			if (allTheSame_FLOOR_UP) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_up = allPolys[0]->floor_up;
			if (allTheSame_FLOOR_DOWN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_down = allPolys[0]->floor_down;
			if (allTheSame_TEXTUREFLOOR) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->textureFloor = allPolys[0]->textureFloor;
			if (allTheSame_TEXTURECEILING) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->textureCeiling = allPolys[0]->textureCeiling;
			if (allTheSame_FLOOR_COLOR_UP) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_color_up = allPolys[0]->floor_color_up;
			if (allTheSame_FLOOR_COLOR_DOWN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_color_down = allPolys[0]->floor_color_down;
			if (allTheSame_CEILING_COLOR_UP) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_color_up = allPolys[0]->ceiling_color_up;
			if (allTheSame_CEILING_COLOR_DOWN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_color_down = allPolys[0]->ceiling_color_down;
			if (allTheSame_CEILING_COLOR_BACKFACE_SPAN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_color_backface_span = allPolys[0]->ceiling_color_backface_span;
			if (allTheSame_FLOOR_COLOR_BACKFACE_SPAN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_color_backface_span = allPolys[0]->floor_color_backface_span;
			if (allTheSame_FLOORDOUBLESIDED) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floorDoubleSided = allPolys[0]->floorDoubleSided;
			if (allTheSame_CEILINGDOUBLESIDED) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceilingDoubleSided = allPolys[0]->ceilingDoubleSided;
			if (allTheSame_ISFLOORDOOR) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->isFloorDoor = allPolys[0]->isFloorDoor;
			if (allTheSame_CEILINGWHITELINE) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceiling_has_start_white_line = allPolys[0]->ceiling_has_start_white_line;
			if (allTheSame_FLOORWHITELINE) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floor_has_start_white_line = allPolys[0]->floor_has_start_white_line;

			if (allTheSame_ROOMNR) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->roomNr = allPolys[0]->roomNr;
			if (allTheSame_PORTAL) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->portal = allPolys[0]->portal;
			if (allTheSame_PORTAL_WITH_SPAN) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->portalWithSpan = allPolys[0]->portalWithSpan;
			if (allTheSame_HASRECTANGLE) for (int i = 0; i < allPolys.size(); ++i) {
				allPolys[i]->hasRectangle = allPolys[0]->hasRectangle;
				if (allPolys[i]->hasRectangle) {
					allPolys[i]->rectangleNr = data->getAddRectangle(allPolys[i]->rectangleNr);
				}
			}
			if (allTheSame_CEILINGNORMALFLIPPED) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->ceilingNormalFlipped = allPolys[0]->ceilingNormalFlipped;
			if (allTheSame_FLOORTRANSPARENCIES) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->floorWithTransparencies = allPolys[0]->floorWithTransparencies;
			if (allTheSame_HASMODIFIER) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->hasModifier = allPolys[0]->hasModifier;
			if (allTheSame_MODIFIERID) for (int i = 1; i < allPolys.size(); ++i) allPolys[i]->modifierId = allPolys[0]->modifierId;
		}
	}
	
	if (!allPoints.empty()) {
		g::Separator();
		if (pointNr >= 0) {
			g::Text("PointNr:%d", pointNr);
			GuiData::XPoint& point = data->scene.points[pointNr];
			g::InputInt("X##SPBD", &(point.x));
			g::InputInt("Y##SPBD", &(point.y));
		}
		else {
			bool allTheSame_X = true;
			bool allTheSame_Y = true;
			for (int i = 1; i < allPoints.size(); ++i) {
				if (allPoints[i]->x != allPoints[0]->x) allTheSame_X = false;
				if (allPoints[i]->y != allPoints[0]->y) allTheSame_Y = false;
			}
			g::Text("Points");

			bool b = false;
			if (!allTheSame_X && g::Checkbox("X for all##SPBR", &b)) {
				double v = 0;
				for (int i = 0; i < allPoints.size(); ++i) v += allPoints[i]->x;
				for (int i = 0; i < allPoints.size(); ++i) allPoints[i]->x = v / (double)allPoints.size();
			}
			if (allTheSame_X) g::InputInt("X##SPBR", &(allPoints[0]->x));

			if (!allTheSame_Y && g::Checkbox("Y for all##SPBR", &b)) {
				double v = 0;
				for (int i = 0; i < allPoints.size(); ++i) v += allPoints[i]->y;
				for (int i = 0; i < allPoints.size(); ++i) allPoints[i]->y = v / (double)allPoints.size();
			}
			if (allTheSame_Y) g::InputInt("Y##SPBR", &(allPoints[0]->y));

			if (allTheSame_X) for (int i = 1; i < allPoints.size(); ++i) allPoints[i]->x = allPoints[0]->x;
			if (allTheSame_Y) for (int i = 1; i < allPoints.size(); ++i) allPoints[i]->y = allPoints[0]->y;
		}
	}

	if (!allBillBoards.empty()) {
		g::Separator();
		if (billBoardNr >= 0) {
			g::Text("BillBoardNr:%d", billBoardNr);
			GuiData::XBillBoard& bboard = data->scene.billboards[billBoardNr];
			g::InputInt("PNT##BBBD", &(bboard.id));
			g::InputInt("Width##BBBD", &(bboard.width));
			g::InputInt("BaseLine##BBBD", &(bboard.ground));
			g::InputInt("Height##BBBD", &(bboard.height));
			g::InputInt("Tex##BBBD", &(bboard.texture));
			g::InputInt("ColUp##BBBD", &(bboard.colorUp));
			g::InputInt("ColDown##BBBD", &(bboard.colorDown));
			g::Checkbox("ceilingBillboard##BBBD", &(bboard.ceilingBillboard));
			g::InputInt("RoomNr##BBBD", &(bboard.roomNr));
			g::Checkbox("HasRectangle##BBBD", &(bboard.hasRectangle));
			if (bboard.hasRectangle) {
				bboard.rectangleNr = data->getAddRectangle(bboard.rectangleNr);
				GuiData::XRect* rect = &(data->scene.rectangles[bboard.rectangleNr]);
				rect->enabled = true;
				//rect->switchType = SWITCH_TYPE_COLLISION;
				//g::Text("RectNr:%d", bboard.rectangleNr);
				//g::Text("PNT1:%d", rect->id1);
				//g::Text("PNT2:%d", rect->id2);
				//g::InputInt("RectExpandX##BBBD", &(rect->expandX));
				//g::InputInt("RectExpandY##BBBD", &(rect->expandY));
				//g::InputInt("SwitchNr##BBBD", &(rect->switchNr));
			}
			else {
				int nr = bboard.rectangleNr;
				if (nr != -1) {
					GuiData::XRect* rect = &(data->scene.rectangles[nr]);
					rect->enabled = false;
				}
			}
			g::Checkbox("HasModifier##BBBD", &(bboard.hasModifier));
			if (bboard.hasModifier)
				g::InputInt("ModifierId##BBBD", &(bboard.modifierId));
		}
		else {
			bool allTheSame_WIDTH = true;
			bool allTheSame_GROUND = true;
			bool allTheSame_HEIGHT = true;
			bool allTheSame_TEX = true;
			bool allTheSame_CEILINGBILLBOARD = true;
			bool allTheSame_ROOMNR = true;
			bool allTheSame_HASRECTANGLE = true;
			bool allTheSame_HASMODIFIER = true;
			bool allTheSame_MODIFIERID = true;
			for (int i = 1; i < allBillBoards.size(); ++i) {
				if (allBillBoards[i]->width != allBillBoards[0]->width) allTheSame_WIDTH = false;
				if (allBillBoards[i]->ground != allBillBoards[0]->ground) allTheSame_GROUND = false;
				if (allBillBoards[i]->height != allBillBoards[0]->height) allTheSame_HEIGHT = false;
				if (allBillBoards[i]->texture != allBillBoards[0]->texture) allTheSame_TEX = false;
				if (allBillBoards[i]->ceilingBillboard != allBillBoards[0]->ceilingBillboard) allTheSame_CEILINGBILLBOARD = false;
				if (allBillBoards[i]->roomNr != allBillBoards[0]->roomNr) allTheSame_ROOMNR = false;
				if (allBillBoards[i]->hasRectangle != allBillBoards[0]->hasRectangle) allTheSame_HASRECTANGLE = false;
				if (allBillBoards[i]->hasModifier != allBillBoards[0]->hasModifier) allTheSame_HASMODIFIER = false;
				if (allBillBoards[i]->modifierId != allBillBoards[0]->modifierId) allTheSame_MODIFIERID = false;
			}
			g::Text("BillBoards");
			bool b = false;

			if (!allTheSame_WIDTH && g::Checkbox("Width for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->width = allBillBoards[0]->width;
			if (allTheSame_WIDTH) g::InputInt("Width##BBBE", &(allBillBoards[0]->width));
			if (!allTheSame_GROUND && g::Checkbox("BaseLine for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->ground = allBillBoards[0]->ground;
			if (allTheSame_GROUND) g::InputInt("BaseLine##BBBE", &(allBillBoards[0]->ground));
			if (!allTheSame_HEIGHT && g::Checkbox("Height for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->height = allBillBoards[0]->height;
			if (allTheSame_HEIGHT) g::InputInt("Height##BBBE", &(allBillBoards[0]->height));
			if (!allTheSame_TEX && g::Checkbox("Tex for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->texture = allBillBoards[0]->texture;
			if (allTheSame_TEX) g::InputInt("Tex##BBBE", &(allBillBoards[0]->texture));
			if (!allTheSame_CEILINGBILLBOARD && g::Checkbox("CeilingBillboard for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->ceilingBillboard = allBillBoards[0]->ceilingBillboard;
			if (allTheSame_CEILINGBILLBOARD) g::Checkbox("CeilingBillboard##BBBE", &(allBillBoards[0]->ceilingBillboard));

			if (!allTheSame_ROOMNR && g::Checkbox("RoomNr for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->roomNr = allBillBoards[0]->roomNr;
			if (allTheSame_ROOMNR) g::InputInt("RoomNr##BBBE", &(allBillBoards[0]->roomNr));
			if (!allTheSame_HASRECTANGLE && g::Checkbox("HasRect for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->hasRectangle = allBillBoards[0]->hasRectangle;
			if (allTheSame_HASRECTANGLE) g::Checkbox("HasRectangle##BBBE", &(allBillBoards[0]->hasRectangle));
			if (!allTheSame_HASMODIFIER && g::Checkbox("HasModifier for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->hasModifier = allBillBoards[0]->hasModifier;
			if (allTheSame_HASMODIFIER) g::Checkbox("HasModifier##BBBE", &(allBillBoards[0]->hasModifier));
			if (allTheSame_HASMODIFIER && allBillBoards[0]->hasModifier) {
				if (!allTheSame_MODIFIERID && g::Checkbox("ModifierId for all##BBBE", &b)) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->modifierId = allBillBoards[0]->modifierId;
				if (allTheSame_MODIFIERID) g::InputInt("ModifierId##BBBE", &(allBillBoards[0]->modifierId));
			}

			if (allTheSame_WIDTH) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->width = allBillBoards[0]->width;
			if (allTheSame_GROUND) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->ground = allBillBoards[0]->ground;
			if (allTheSame_HEIGHT) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->height = allBillBoards[0]->height;
			if (allTheSame_TEX) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->texture = allBillBoards[0]->texture;
			if (allTheSame_CEILINGBILLBOARD) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->ceilingBillboard = allBillBoards[0]->ceilingBillboard;
			if (allTheSame_ROOMNR) for (int i = 1; i < allBillBoards.size(); ++i) allBillBoards[i]->roomNr = allBillBoards[0]->roomNr;
			if (allTheSame_HASRECTANGLE) for (int i = 0; i < allBillBoards.size(); ++i) {
				allBillBoards[i]->hasRectangle = allBillBoards[0]->hasRectangle;
				if (allBillBoards[i]->hasRectangle) allBillBoards[i]->rectangleNr = data->getAddRectangle(allBillBoards[i]->rectangleNr);
			}
			if (allTheSame_HASMODIFIER) for (int i = 0; i < allBillBoards.size(); ++i)	allBillBoards[i]->hasModifier = allBillBoards[0]->hasModifier;
		}
	}

	if (!allRectangles.empty()) {
		g::Separator();
		if (rectNr >= 0) {
			g::Text("RectangleNr:%d", rectNr);
			GuiData::XRect* rect = &(data->scene.rectangles[rectNr]);
			g::Checkbox("Enabled##RCTD", &(rect->enabled));
			g::InputInt("PNT1##SPBD", &(rect->id1));
			g::InputInt("PNT2##SPBD", &(rect->id2));
			g::InputInt("PolyNr##RCTD", &(rect->polyNr));
			g::InputInt("ExpandX##RCTD", &(rect->expandX));
			g::InputInt("ExpandY##RCTD", &(rect->expandY));
			g::InputInt("SwitchType##RCTD", &(rect->switchType));
			g::InputInt("SwitchVal##RCTD", &(rect->switchNr));
			g::InputInt("RoomNr##RCTD", &(rect->roomNr));
			g::InputInt("PortalRoomBackNr##RCTD", &(rect->portalRoomNrBack));
		}
		else {
			bool allTheSame_POLYNR = true;
			bool allTheSame_ENABLED = true;
			bool allTheSame_EXPANDX = true;
			bool allTheSame_EXPANDY = true;
			bool allTheSame_SWITCHTYPE = true;
			bool allTheSame_SWITCHNR = true;
			bool allTheSame_ROOMNR = true;
			bool allTheSame_PORTALROOMNRBACK = true;
			for (int i = 1; i < allRectangles.size(); ++i) {
				if (allRectangles[i]->polyNr != allRectangles[0]->polyNr) allTheSame_POLYNR = false;
				if (allRectangles[i]->enabled != allRectangles[0]->enabled) allTheSame_ENABLED = false;
				if (allRectangles[i]->expandX != allRectangles[0]->expandX) allTheSame_EXPANDX = false;
				if (allRectangles[i]->expandY != allRectangles[0]->expandY) allTheSame_EXPANDY = false;
				if (allRectangles[i]->switchType != allRectangles[0]->switchType) allTheSame_SWITCHTYPE = false;
				if (allRectangles[i]->switchNr != allRectangles[0]->switchNr) allTheSame_SWITCHNR = false;
				if (allRectangles[i]->roomNr != allRectangles[0]->roomNr) allTheSame_ROOMNR = false;
				if (allRectangles[i]->portalRoomNrBack != allRectangles[0]->portalRoomNrBack) allTheSame_PORTALROOMNRBACK = false;
			}
			g::Text("Rectangles");
			bool b = false;

			if (!allTheSame_ENABLED && g::Checkbox("Enabled for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->enabled = allRectangles[0]->enabled;
			if (allTheSame_ENABLED) g::Checkbox("Enabled##RCTE", &(allRectangles[0]->enabled));
			if (!allTheSame_POLYNR && g::Checkbox("PolyNr for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->polyNr = allRectangles[0]->polyNr;
			if (allTheSame_POLYNR) g::InputInt("PolyNr##RCTE", &(allRectangles[0]->polyNr));
			if (!allTheSame_EXPANDX && g::Checkbox("ExpandX for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->expandX = allRectangles[0]->expandX;
			if (allTheSame_EXPANDX) g::InputInt("ExpandX##RCTE", &(allRectangles[0]->expandX));
			if (!allTheSame_EXPANDY && g::Checkbox("ExpandY for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->expandY = allRectangles[0]->expandY;
			if (allTheSame_EXPANDY) g::InputInt("ExpandY##RCTE", &(allRectangles[0]->expandY));
			if (!allTheSame_SWITCHTYPE && g::Checkbox("SwitchType for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->switchType = allRectangles[0]->switchType;
			if (allTheSame_SWITCHTYPE) g::InputInt("SwitchType##RCTE", &(allRectangles[0]->switchType));
			if (!allTheSame_SWITCHNR && g::Checkbox("SwitchVal for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->switchNr = allRectangles[0]->switchNr;
			if (allTheSame_SWITCHNR) g::InputInt("SwitchVal##RCTE", &(allRectangles[0]->switchNr));
			if (!allTheSame_ROOMNR && g::Checkbox("RoomNr for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->roomNr = allRectangles[0]->roomNr;
			if (allTheSame_ROOMNR) g::InputInt("RoomNr##RCTE", &(allRectangles[0]->roomNr));
			if (!allTheSame_PORTALROOMNRBACK && g::Checkbox("PortalRoomNrBack for all##RCTE", &b)) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->portalRoomNrBack = allRectangles[0]->portalRoomNrBack;
			if (allTheSame_PORTALROOMNRBACK) g::InputInt("PortalRoomNrBack##RCTE", &(allRectangles[0]->portalRoomNrBack));

			if (allTheSame_POLYNR) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->polyNr = allRectangles[0]->polyNr;
			if (allTheSame_ENABLED) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->enabled = allRectangles[0]->enabled;
			if (allTheSame_EXPANDX) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->expandX = allRectangles[0]->expandX;
			if (allTheSame_EXPANDY) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->expandY = allRectangles[0]->expandY;
			if (allTheSame_SWITCHTYPE) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->switchType = allRectangles[0]->switchType;
			if (allTheSame_SWITCHNR) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->switchNr = allRectangles[0]->switchNr;
			if (allTheSame_ROOMNR) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->roomNr = allRectangles[0]->roomNr;
			if (allTheSame_PORTALROOMNRBACK) for (int i = 1; i < allRectangles.size(); ++i) allRectangles[i]->portalRoomNrBack = allRectangles[0]->portalRoomNrBack;
		}
	}

	std::vector<GuiData::XPoly*> endOnes;
	if (allPolysConnected(allPolys, endOnes)) {
		g::Separator();
		if (endOnes.size() == 2) {
			bool flipped = maybeFlip(data, allPolys, endOnes);
			if (flipped) {
				GuiData::XPoly* p = endOnes[0];
				endOnes[0] = endOnes[1];
				endOnes[1] = p;
			}
			g::InputDouble("texCoordToWorld##PPM", &(data->texCoordToWorld));
			GuiData::XPoly* p0 = endOnes[0];
			GuiData::XPoly* p1 = endOnes[1];
			if (p0->hasFloor && p1->hasFloor) {
				g::InputDouble("FloorTexStart##PPM", &(p0->floor_tx1));
				g::InputDouble("FloorTexEnd##PPM", &(p1->floor_tx2));
				if (g::Button("FloorTexCoordAssign##PPM")) {
					assignTextureUniform(data, allPolys, endOnes, true, flipped);
				}
				if (g::Button("calcFloorTexFromWorld##PPM")) {
					if (data->texCoordToWorld > 0) {
						double length = textureUniformLength(data, allPolys);
						p1->floor_tx2 = length / data->texCoordToWorld;
					}
				}
			}
			if (p0->hasCeiling && p1->hasCeiling) {
				g::InputDouble("CeilTexStart##PPM", &(p0->ceiling_tx1));
				g::InputDouble("CeilTexEnd##PPM", &(p1->ceiling_tx2));
				if (g::Button("CeilTexCoordAssign##PPM")) {
					assignTextureUniform(data, allPolys, endOnes, false, flipped);
				}
				if (g::Button("calcCeilTexFromWorld##PPM")) {
					if (data->texCoordToWorld > 0) {
						double length = textureUniformLength(data, allPolys);
						p1->ceiling_tx2 = length / data->texCoordToWorld;
					}
				}
			}
		}
	}

	g::End();
	g::PopStyleColor();
}