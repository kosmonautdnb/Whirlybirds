#pragma once

void paint_views(class GuiData *data);