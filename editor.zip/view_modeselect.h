#pragma once

void paint_modeselect(class GuiData *data);