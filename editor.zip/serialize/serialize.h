#pragma once

#include <vector>
#include <string>
#include <sstream>
#include <iterator>
#include "../json/json.h"

class SerializeInterface {
public:
	virtual void serialize(class Serializer& ser) = 0;
};

void write_escaped(std::string const& s, std::stringstream& out);

class Serializer {
public:
	bool fromSerializeToClass; 
	json::Value jsVal;

	Serializer(bool fromSerializeToClass) : fromSerializeToClass(fromSerializeToClass) {
		jsVal = json::Object();
	}

	void serialize(const std::string &name, SerializeInterface& val) {
		if (fromSerializeToClass) {
			if (jsVal.GetType() != json::ValueType::NULLVal && jsVal.HasKey(name)) {
				Serializer b = Serializer(fromSerializeToClass);
				b.jsVal = jsVal[name];
				val.serialize(b);
			}
		}
		else {
			Serializer b = Serializer(fromSerializeToClass);
			val.serialize(b);
			jsVal[name] = b.jsVal;
		}
	}

	template <typename T>
	void serialize(const std::string& name, std::vector<T>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					Serializer b = Serializer(fromSerializeToClass);
					b.jsVal = arr[i];
					val[i].serialize(b);
				}
			}
		}
		else {
			if (val.size() > 0) {
				json::Array arr;
				for (int i = 0; i < val.size(); ++i) {
					Serializer b = Serializer(fromSerializeToClass);
					val[i].serialize(b);
					arr.push_back(b.jsVal);
				}
				jsVal[name] = json::Value(arr);
			}
		}
	}

	void serialize(const std::string& name, int& val) {
		if (fromSerializeToClass) {
			if (jsVal.HasKey(name))
				val = jsVal[name].ToInt();
		}
		else {
			jsVal[name] = json::Value(val);
		}
	}

	void serialize(const std::string& name, float& val) {
		if (fromSerializeToClass) {
			if (jsVal.HasKey(name))
				val = jsVal[name].ToFloat();
		}
		else {
			jsVal[name] = json::Value(val);
		}
	}

	void serialize(const std::string& name, double& val) {
		if (fromSerializeToClass) {
			if (jsVal.HasKey(name))
				val = jsVal[name].ToFloat();
		}
		else {
			jsVal[name] = json::Value(val);
		}
	}

	void serialize(const std::string& name, bool& val) {
		if (fromSerializeToClass) {
			if (jsVal.HasKey(name))
				val = jsVal[name].ToBool();
		}
		else {
			jsVal[name] = json::Value(val);
		}
	}

	void serialize(const std::string& name, std::string& val) {
		if (fromSerializeToClass) {
			if (jsVal.HasKey(name))
				val = jsVal[name].ToString();
		}
		else {
			std::stringstream stream;
			write_escaped(val, stream);
			jsVal[name] = json::Value(stream.str());
		}
	}

	void serialize(const std::string& name, std::vector<int>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					val[i] = arr[i].ToInt();
				}
			}
		}
		else {
			json::Array arr;
			for (int i = 0; i < val.size(); ++i) {
				arr.push_back(json::Value(val[i]));
			}
			jsVal[name] = arr;
		}
	}

	void serialize(const std::string& name, std::vector<unsigned int>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					val[i] = arr[i].ToInt();
				}
			}
		}
		else {
			json::Array arr;
			for (int i = 0; i < val.size(); ++i) {
				arr.push_back(json::Value((int)val[i]));
			}
			jsVal[name] = arr;
		}
	}

	void serialize(const std::string& name, std::vector<unsigned char>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					val[i] = arr[i].ToInt();
				}
			}
		}
		else {
			json::Array arr;
			for (int i = 0; i < val.size(); ++i) {
				arr.push_back(json::Value((int)val[i]));
			}
			jsVal[name] = arr;
		}
	}

	void serialize(const std::string& name, std::vector<bool>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					val[i] = arr[i].ToBool();
				}
			}
		}
		else {
			json::Array arr;
			for (int i = 0; i < val.size(); ++i) {
				arr.push_back(json::Value((bool)val[i]));
			}
			jsVal[name] = arr;
		}
	}

	void serialize(const std::string& name, std::vector<float>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					val[i] = arr[i].ToFloat();
				}
			}
		}
		else {
			json::Array arr;
			for (int i = 0; i < val.size(); ++i) {
				arr.push_back(json::Value((float)val[i]));
			}
			jsVal[name] = arr;
		}
	}

	void serialize(const std::string& name, std::vector<std::string>& val) {
		if (fromSerializeToClass) {
			val.clear();
			if (jsVal.HasKey(name)) {
				json::Array arr = jsVal[name].ToArray();
				val.resize(arr.size());
				for (int i = 0; i < arr.size(); ++i) {
					val[i] = arr[i].ToString();
				}
			}
		}
		else {
			json::Array arr;
			for (int i = 0; i < val.size(); ++i) {
				std::stringstream stream;
				write_escaped(val[i], stream);
				arr.push_back(json::Value(stream.str()));
			}
			jsVal[name] = arr;
		}
	}
};

std::string toString(const json::Value& jsonObject);
json::Value toJson(const std::string& jsonString);

// reads a string from a file 
std::string stringFromFile(const std::string& fileName);
// reads a string from a file 
void fromFile(std::string& dest, const std::string& fileName);
// reads a string from a file 
void fromFile(std::vector<unsigned char>& dest, const std::string& fileName);
void fromFile(std::vector<unsigned short>& dest, const std::string& fileName);
// writes the string to a file
void toFile(const std::string& stringToSerialize, const std::string& fileName);
// writes memory to a file
void toFile(const void* data, size_t lenInBytes, const std::string& fileName);
// writes memory to a file
void toFile(std::vector<unsigned char> data, const std::string& fileName);
void toFile(std::vector<unsigned short> data, const std::string& fileName);
// just for jsons
void toFileReadableJson(const std::string& compactJsonString, const std::string& fileName);
