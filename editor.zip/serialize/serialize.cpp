#include "serialize.h"
#include <stdio.h>
#include <fstream>
#include <streambuf>

void write_escaped(std::string const& s, std::stringstream& out) {
//	out << '"';
	for (std::string::const_iterator i = s.begin(), end = s.end(); i != end; ++i) {
		unsigned char c = *i;
		if (' ' <= c and c <= '~' and c != '\\' and c != '"') {
			out << c;
		}
		else {
			out << '\\';
			switch (c) {
			case '"':  out << '"';  break;
			case '\\': out << '\\'; break;
			case '\t': out << 't';  break;
			case '\r': out << 'r';  break;
			case '\n': out << 'n';  break;
			default:
				char const* const hexdig = "0123456789ABCDEF";
				out << 'x';
				out << hexdig[c >> 4];
				out << hexdig[c & 0xF];
			}
		}
	}
//  out << '"';
}


std::string toString(const json::Value& jsonObject)
{
	return json::Serialize(jsonObject);
}

json::Value toJson(const std::string& jsonString)
{
	return json::Deserialize(jsonString);
}

std::string stringFromFile(const std::string& fileName)
{
	std::string ret;
	fromFile(ret, fileName);
	return ret;
}

void fromFile(std::string& dest, const std::string& fileName)
{
	dest.clear();

	std::ifstream t(fileName);
	if (t.is_open())
	{
		std::string str;

		t.seekg(0, std::ios::end);
		dest.reserve((size_t)t.tellg());
		t.seekg(0, std::ios::beg);

		dest.assign((std::istreambuf_iterator<char>(t)),
			std::istreambuf_iterator<char>());
	}
	t.close();
}


void fromFile(std::vector<unsigned char>& dest, const std::string& fileName)
{
	// Todo: better solution later on (das muss unbedingt besser (0 terminierung bei string etc..)
	FILE* in;
	fopen_s(&in, fileName.c_str(), "rb");
	if (in)
	{
		dest.clear();
		fseek(in, 0, SEEK_END);
		int fileSize = ftell(in);
		fseek(in, 0, SEEK_SET);
		char* mem = (char*)malloc(fileSize);
		fread(mem, 1, fileSize, in);
		dest.resize(fileSize);
		for (int i = 0; i < fileSize; ++i)
			dest[i] = mem[i];
		free(mem);
		fclose(in);
	}
}

void toFile(const std::string& stringToSerialize, const std::string& fileName)
{
	toFile(stringToSerialize.c_str(), stringToSerialize.size(), fileName);
}

void toFile(const void* data, size_t lenInBytes, const std::string& fileName)
{
	// Todo: better solution later on
	FILE* out;
	fopen_s(&out, fileName.c_str(), "wb");
	if (out)
	{
		fwrite(data, 1, lenInBytes, out);
		fclose(out);
	}
}

void toFile(std::vector<unsigned char> data, const std::string& fileName)
{
	// Todo: better solution later on
	FILE* out;
	fopen_s(&out, fileName.c_str(), "wb");
	if (out)
	{
		for (size_t i = 0; i < data.size(); ++i)
			fwrite(&data[i], 1, 1, out);
		fclose(out);
	}
}

void toFile(std::vector<unsigned short> data, const std::string& fileName)
{
	std::vector<unsigned char> fileData;
	for (size_t i = 0; i < data.size(); i++)
	{
		fileData.push_back(data[i] & 0xff);
		fileData.push_back((data[i] >> 8) & 0xff);
	}
	toFile(fileData, fileName);
}

void toFileReadableJson(const std::string& compactJsonString, const std::string& fileName)
{
	FILE* out;
	fopen_s(&out, fileName.c_str(), "wb");
	if (out)
	{
		for (size_t i = 0; i < compactJsonString.size(); ++i)
		{
			unsigned char c = compactJsonString[i];
			if (c == '}' || c == ']')
			{
				unsigned char delimiter[2] = { 0x0d,0x0a };
				fwrite(delimiter, 1, 2, out);
			}
			fwrite(&c, 1, 1, out);
			if (c == '{' || c == ',' || c == '[')
			{
				unsigned char delimiter[2] = { 0x0d,0x0a };
				fwrite(delimiter, 1, 2, out);
			}
		}
		fclose(out);
	}
	int i = errno; // sometimes errno was 0x0d and out = NULL
}
