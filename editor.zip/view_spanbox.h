#pragma once

void paint_spanbox(class GuiData *data);