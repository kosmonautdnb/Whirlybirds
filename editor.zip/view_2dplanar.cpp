#define _CRT_SECURE_NO_WARNINGS
#include "view_2dplanar.h"
#include "imgui/imgui.h"
#include "guidata.h"
namespace g = ImGui;

double getZoom(const GuiData* data) {
	return pow(2.0, data->scene.zoom);
}

bool keepMouseY = false;
bool keepMouseX = false;
double keepMouseYCoord = -1;
double keepMouseXCoord = -1;

int lastSelectedRoom = 0;

GuiData::XPoint mousePos(GuiData* data, bool locking = true) {
	ImVec2 p0 = g::GetCursorScreenPos();
	GuiData::XPoint ret;
	ret.x = g::GetIO().MousePos.x - p0.x;
	ret.y = g::GetIO().MousePos.y - p0.y;
	ret.x = (ret.x * getZoom(data) + 0.5);
	ret.y = (ret.y * getZoom(data) + 0.5);
	ret.x -= data->scene.center.x;
	ret.y -= data->scene.center.y;
	if (locking) {
		if (keepMouseY)
			ret.y = keepMouseYCoord;
		if (keepMouseX)
			ret.x = keepMouseXCoord;
	}
	return ret;
}

ImVec2 xPoint(const GuiData* data, const GuiData::XPoint& point) {
	ImVec2 ret;
	ImVec2 p0 = g::GetCursorScreenPos();
	ret.x = point.x;
	ret.y = point.y;
	ret.x += data->scene.center.x;
	ret.y += data->scene.center.y;
	double zoom = getZoom(data);
	if (zoom != 0.0)
		zoom = 1.0 / zoom;
	ret.x *= zoom;
	ret.y *= zoom;
	ret.x += p0.x;
	ret.y += p0.y;
	return ret;
}

#include "bsp_exporter.h"
extern ROOM currentBSPRoom;

int translatedPlayerPos2X;
int translatedPlayerPos2Y;
int processedBspDepth = 0;

void paintBspPlane(GuiData* data, BSP* r, uint32_t color) {
	ImVec2 p0 = xPoint(data, GuiData::XPoint(r->plane.px, -r->plane.py));
	double nx = r->plane.nx;
	double ny = -r->plane.ny;
	double tx = ny;
	double ty = -nx;
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x - tx, p0.y - ty), ImVec2(p0.x + tx, p0.y + ty), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y), ImVec2(p0.x + nx * 0.1, p0.y + ny * 0.1), color, 1.0);
}

void paintBspPoly(GuiData* data, ROOM& room, int polyIndex, uint32_t color) {
	POLY p = room.polies[polyIndex];
	int p1 = p.id_start;
	POINT2D v1 = (p1 & FLAG_SPECIALPOINT) ? POINT2D(room.specialpoints[p1 & (~FLAG_SPECIALPOINT)].calcedX, room.specialpoints[p1 & (~FLAG_SPECIALPOINT)].calcedY) : room.points[p1];
	
	if (p.polyType == POLYTYPE_BILLBOARD) {
		double dx = 20;
		ImVec2 d1 = xPoint(data, GuiData::XPoint(v1.x, -v1.y));
		d1.x -= dx;
		ImVec2 d2 = xPoint(data, GuiData::XPoint(v1.x, -v1.y));
		d2.x += dx;
		g::GetWindowDrawList()->AddLine(d1, d2, color, 1.0);
		return;
	}
	int p2 = p.id_end;
	POINT2D v2 = (p2 & FLAG_SPECIALPOINT) ? POINT2D(room.specialpoints[p2 & (~FLAG_SPECIALPOINT)].calcedX, room.specialpoints[p2 & (~FLAG_SPECIALPOINT)].calcedY) : room.points[p2];
	ImVec2 d1 = xPoint(data, GuiData::XPoint(v1.x, -v1.y));
	ImVec2 d2 = xPoint(data, GuiData::XPoint(v2.x, -v2.y));
	//printf("%f,%f %f,%f\n", d1.x, d1.y, d2.x, d2.y);
	g::GetWindowDrawList()->AddLine(d1, d2, color, 1.0);
	processedBspDepth++;
}

void maybeDisplayNode(GuiData* data, BSP* node, ROOM& room) {
	if (processedBspDepth < 1) {
		for (int i = 0; i < node->polyIndex.size(); ++i)
			paintBspPoly(data, room, node->polyIndex[i], IM_COL32(255, 255, 255, 255));
	}
}

void paintBspNode(GuiData* data, int nr, ROOM& room) {
	if (nr == -1)
		return;
	BSP* node = room.bsp[nr];
	double nx = node->plane.nx;
	double ny = node->plane.ny;
	double px = node->plane.px;
	double py = node->plane.py;
	double dotti = nx * (translatedPlayerPos2X - px) + ny * (translatedPlayerPos2Y - py);
	if (dotti >= 0) { // bmi otherorder
		paintBspNode(data, node->computedLeftArrayIndex, room);
		maybeDisplayNode(data, node, room);
		paintBspNode(data, node->computedRightArrayIndex, room);
	}
	else {
		paintBspNode(data, node->computedRightArrayIndex, room);
		maybeDisplayNode(data, node, room);
		paintBspNode(data, node->computedLeftArrayIndex, room);
	}
}

void paintBspSplitPlanes(GuiData* data) {
	if (!currentBSPRoom.bsp.empty() && data->showAllBSPPlanes) {
		processedBspDepth = 0;
		translatedPlayerPos2X = mousePos(data).x;
		translatedPlayerPos2Y = -mousePos(data).y;
		paintBspNode(data, 0, currentBSPRoom);
		for (int i = 0; i < currentBSPRoom.bsp.size(); ++i) {
			BSP* r = currentBSPRoom.bsp[i];
			paintBspPlane(data, currentBSPRoom.bsp[i], IM_COL32(0, 0, 255, 150));
		}
	}
}

void paintCenterCross(GuiData *data) {
	uint32_t color = IM_COL32(255, 0, 0, 255);
	ImVec2 p0 = xPoint(data,GuiData::XPoint(0.0,0.0));
	double rad = 1000000;
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x-rad, p0.y), ImVec2(p0.x+rad, p0.y), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y-rad), ImVec2(p0.x, p0.y+rad), color, 1.0);
}

void paint2DPlayer(GuiData* data) {
	uint32_t color = IM_COL32(255, 0, 0, 90);
	ImVec2 p0 = xPoint(data, GuiData::XPoint(data->engine.playerPosX, data->engine.playerPosY));
	double rad = 4;
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x - rad, p0.y), ImVec2(p0.x + rad, p0.y), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y - rad), ImVec2(p0.x, p0.y + rad), color, 1.0);

	double xa = -sin((double)data->engine.playerRotation / 0x10000 * 2.0 * 3.1415927);
	double ya = -cos((double)data->engine.playerRotation / 0x10000 * 2.0 * 3.1415927);
	double farPlane = 256 * 2; 
	double widen = 256;

	GuiData::XPoint p1(data->engine.playerPosX + xa * farPlane + ya * widen, data->engine.playerPosY + ya * farPlane - xa * widen);
	GuiData::XPoint p2(data->engine.playerPosX + xa * farPlane - ya * widen, data->engine.playerPosY + ya * farPlane + xa * widen);
	ImVec2 a1 = xPoint(data, p1);
	ImVec2 a2 = xPoint(data, p2);
	g::GetWindowDrawList()->AddLine(p0, a1, color, 1.0);
	g::GetWindowDrawList()->AddLine(p0, a2, color, 1.0);
}

void paintBoundingBox(GuiData* data) {
	uint32_t color = IM_COL32(155, 0, 155, 255);
	ImVec2 p0 = xPoint(data, GuiData::XPoint(-32760, -32760));
	ImVec2 p1 = xPoint(data, GuiData::XPoint(32760, 32760));
	double rad = 1000000;
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y), ImVec2(p1.x, p0.y), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p1.y), ImVec2(p1.x, p1.y), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y), ImVec2(p0.x, p1.y), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(p1.x, p0.y), ImVec2(p1.x, p1.y), color, 1.0);
}


void paintMouseCursor(GuiData* data) {
	ImVec2 pt = xPoint(data, mousePos(data));
	double d = 4.0;
	uint32_t color = IM_COL32(0, 255, 0, 200);
	g::GetWindowDrawList()->AddLine(ImVec2(pt.x - d, pt.y), ImVec2(pt.x + d, pt.y), color, 1.0);
	g::GetWindowDrawList()->AddLine(ImVec2(pt.x, pt.y - d), ImVec2(pt.x, pt.y + d), color, 1.0);
}

//void paintBoundingBox(GuiData::XBBox& box, uint32_t color = IM_COL32(255, 255, 255, 255), double thickness = 1.0) {
//	ImVec2 p0 = g::GetCursorScreenPos();
//	ImVec2 p1(box.xmin + p0.x, box.ymin + p0.y);
//	ImVec2 p2(box.xmax + p0.x, box.ymax + p0.y);
//	g::GetWindowDrawList()->AddLine(ImVec2(p1.x, p1.y), ImVec2(p2.x, p1.y), color, thickness);
//	g::GetWindowDrawList()->AddLine(ImVec2(p2.x, p1.y), ImVec2(p2.x, p2.y), color, thickness);
//	g::GetWindowDrawList()->AddLine(ImVec2(p2.x, p2.y), ImVec2(p1.x, p2.y), color, thickness);
//	g::GetWindowDrawList()->AddLine(ImVec2(p1.x, p1.y), ImVec2(p1.x, p2.y), color, thickness);
//}


bool isClicked(GuiData* data, GuiData::XPoint& point, int rad = 0) {
	GuiData::XPoint p = mousePos(data);
	int xd = abs(point.x - p.x);
	int yd = abs(point.y - p.y);
	return xd <= rad && yd <= rad;
}

bool isClicked(GuiData* data, GuiData::XPoly& poly, double radius = 4.0) {
	ImVec2 p0 = g::GetIO().MousePos;
	ImVec2 point1 = xPoint(data, data->scene.points[poly.id1]);
	ImVec2 point2 = xPoint(data, data->scene.points[poly.id2]);
	double nx = (point2.x - point1.x);
	double ny = (point2.y - point1.y);
	double l = nx * nx + ny * ny;
	if (l != 0.0)
		l = 1.0/sqrt(l);
	nx *= l;
	ny *= l;
	int cx1 = p0.x - point1.x;
	int cy1 = p0.y - point1.y;
	double k1 = cx1 * ny + cy1 * -nx;
	if (abs(k1) < radius) {
		double k2 = cx1 * nx + cy1 * ny;
		int cx2 = p0.x - point2.x;
		int cy2 = p0.y - point2.y;
		double k3 = cx2 * nx + cy2 * ny;
		if (k2 > -radius && k3 < radius)
			return true;
	}
	return false;
}

void paint2DPoint(GuiData* data, GuiData::XPoint& point, uint32_t color = IM_COL32(255, 255, 255, 255), double crossSize = 4.0, double thickness = 1.0) {
	ImVec2 pt = xPoint(data, point);
	ImVec2 p1(pt.x - crossSize, pt.y - crossSize);
	ImVec2 p2(pt.x + crossSize, pt.y + crossSize);
	g::GetWindowDrawList()->AddLine(ImVec2(p1.x, p1.y), ImVec2(p2.x, p2.y), color, thickness);
	g::GetWindowDrawList()->AddLine(ImVec2(p2.x, p1.y), ImVec2(p1.x, p2.y), color, thickness);
}

GuiData::XPoint getPointForId(const GuiData *data,int id) {
	if (id & 0x10000)
		return data->selectedPoints[id & 0xffff];
	return data->scene.points[id & 0xffff];
}

void paintBillBoard(GuiData* data, GuiData::XBillBoard& bboard, uint32_t color = IM_COL32(255, 255, 255, 255), double thickness = 1.0) {
	ImVec2 pt = xPoint(data,getPointForId(data, bboard.id));
	double dx = 20;
	double dy = 4;
	g::GetWindowDrawList()->AddLine(ImVec2(pt.x - dx, pt.y), ImVec2(pt.x + dx, pt.y), color, thickness);
	g::GetWindowDrawList()->AddLine(ImVec2(pt.x, pt.y - dy), ImVec2(pt.x, pt.y + dy), color, thickness);
}

void paintRectangle(GuiData* data, GuiData::XRect& rectangle, uint32_t color = IM_COL32(255, 255, 255, 255), double thickness = 1.0) {
	ImVec2 p0 = xPoint(data, getPointForId(data, rectangle.id1));
	ImVec2 p1 = xPoint(data, getPointForId(data, rectangle.id2));
	if (p0.x > p1.x) {
		double t = p0.x;
		p0.x = p1.x;
		p1.x = t;
	}
	if (p0.y > p1.y) {
		double t = p0.y;
		p0.y = p1.y;
		p1.y = t;
	}
	ImVec2 k0 = xPoint(data, GuiData::XPoint(0, 0));
	ImVec2 k1 = xPoint(data, GuiData::XPoint(rectangle.expandX, rectangle.expandY));
	p0.x -= k1.x - k0.x;
	p1.x += k1.x - k0.x;
	p0.y -= k1.y - k0.y;
	p1.y += k1.y - k0.y;
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y), ImVec2(p1.x, p0.y), color, thickness);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p0.y), ImVec2(p0.x, p1.y), color, thickness);
	g::GetWindowDrawList()->AddLine(ImVec2(p0.x, p1.y), ImVec2(p1.x, p1.y), color, thickness);
	g::GetWindowDrawList()->AddLine(ImVec2(p1.x, p0.y), ImVec2(p1.x, p1.y), color, thickness);
}

void paint2DPoly(GuiData* data, GuiData::XPoly& poly, uint32_t color = IM_COL32(255, 255, 255, 255), double thickness = 1.0) {
	if (poly.isOtherRoomPoly != poly.editOtherRoomPoly) {
		int a = (color >> 24) & 255;
		a -= 20;
		color = (color & 0x00ffffff) | (a << 24);
	}
	GuiData::XPoint p1 = getPointForId(data, poly.id1);
	GuiData::XPoint p2 = getPointForId(data, poly.id2);
	
	if (poly.portal) {
		ImVec2 a0, a1;
		a0 = xPoint(data, p1);
		a1 = xPoint(data, p2);
		g::GetWindowDrawList()->AddLine(ImVec2(a0.x, a0.y), ImVec2(a1.x, a1.y), color, 3.0);
		ImVec2 p3;
		p3.x = (a0.x + a1.x) * 0.5;
		p3.y = (a0.y + a1.y) * 0.5;
		double nx = a1.x - a0.x;
		double ny = a1.y - a0.y;
		double l = sqrt(nx * nx + ny * ny);
		if (l != 0.0) {
			l = 1.0 / sqrt(l);
		}
		nx *= l;
		ny *= l;
		double d = 1.0;
		if (poly.portalRoomNrBack == data->highlighRoomNr && data->highlighRoomNr >= 0)
			d *= -1;
		g::GetWindowDrawList()->AddLine(ImVec2(p3.x, p3.y), ImVec2(p3.x + ny * d, p3.y - nx * d), color, thickness);
		return;
	}
	
	for (int i = 0; i < poly.divisions+1; ++i) {
		bool lastOne = i == poly.divisions;
		float fi0 = (float)(i+0) / poly.divisions;
		float fi1 = (float)(i+1) / poly.divisions;
		GuiData::XPoint k0, k1;
		k0.x = int((p2.x - p1.x) * fi0 + p1.x);
		k0.y = int((p2.y - p1.y) * fi0 + p1.y);
		k1.x = int((p2.x - p1.x) * fi1 + p1.x);
		k1.y = int((p2.y - p1.y) * fi1 + p1.y);
		ImVec2 a0, a1;
		a0 = xPoint(data, k0);
		a1 = xPoint(data, k1);
		if (!lastOne)
			g::GetWindowDrawList()->AddLine(ImVec2(a0.x, a0.y), ImVec2(a1.x, a1.y), color, thickness);
		double nx = a1.x - a0.x;
		double ny = a1.y - a0.y;
		double l = sqrt(nx * nx + ny * ny);
		if (l != 0.0) {
			l = 1.0 / sqrt(l);
		}
		nx *= l;
		ny *= l;
		double d = 1.0;
		ImVec2 p3;
		p3.x = (a1.x - a0.x) * 0.5 + a0.x;
		p3.y = (a1.y - a0.y) * 0.5 + a0.y;
		if (!lastOne)
			g::GetWindowDrawList()->AddLine(ImVec2(p3.x, p3.y), ImVec2(p3.x + ny * d, p3.y - nx * d), color, thickness);
		unsigned int color2 = color;
		color2 &= 0x00ffffff;
		color2 |= 0x80000000;
		double d2 = d * 0.5f;
		g::GetWindowDrawList()->AddLine(ImVec2(a0.x - ny * d2, a0.y + nx * d2), ImVec2(a0.x + ny * d2, a0.y - nx * d2), color2, thickness);
	}
}

int moveStartMouseX = 0;
int moveStartMouseY = 0;
int moveStartCenterX = 0;
int moveStartCenterY = 0;
#define MOUSEWHEELINIT -100000
double lastMouseWheel = MOUSEWHEELINIT;
int lastChar = -1;
unsigned int selectionCycler = 0;
unsigned int selectionCyclerPoly = 0;

bool lineModeOn = false;
int lineModeStartPoint = -1;

bool selectModeOn = false;
bool selectModeAdd = false;
double selectionStartX = -1;
double selectionStartY = -1;
double selectionEndX = -1;
double selectionEndY = -1;

bool selectionToSecondPosOn = false;
double selectionToSecondPosOnStartX = -1;
double selectionToSecondPosOnStartY = -1;

void paintSelectionRect(const GuiData *data) {
	if (selectModeOn) {
		GuiData::XPoint p0(selectionStartX, selectionStartY);
		GuiData::XPoint p1(selectionEndX, selectionEndY);
		ImVec2 sp0 = xPoint(data, p0);
		ImVec2 sp1 = xPoint(data, p1);
		double thickness = 1.0;
		uint32_t color = IM_COL32(255, 0, 0, 255);
		g::GetWindowDrawList()->AddLine(ImVec2(sp0.x, sp0.y), ImVec2(sp1.x, sp0.y), color, thickness);
		g::GetWindowDrawList()->AddLine(ImVec2(sp0.x, sp0.y), ImVec2(sp0.x, sp1.y), color, thickness);
		g::GetWindowDrawList()->AddLine(ImVec2(sp0.x, sp1.y), ImVec2(sp1.x, sp1.y), color, thickness);
		g::GetWindowDrawList()->AddLine(ImVec2(sp1.x, sp0.y), ImVec2(sp1.x, sp1.y), color, thickness);
	}
}

bool isInSelection(GuiData* data, GuiData::XPoint& point) {
	if (!selectModeOn)
		return false;
	int signX = selectionEndX - selectionStartX;
	int signY = selectionEndY - selectionStartY;

	if (signX > 0) {
		if (point.x > selectionEndX)
			return false;
		if (point.x < selectionStartX)
			return false;
	}
	else {
		if (point.x < selectionEndX)
			return false;
		if (point.x > selectionStartX)
			return false;
	}

	if (signY > 0) {
		if (point.y > selectionEndY)
			return false;
		if (point.y < selectionStartY)
			return false;
	}
	else {
		if (point.y < selectionEndY)
			return false;
		if (point.y > selectionStartY)
			return false;
	}
	return true;
}

bool isInSelection(GuiData* data, GuiData::XPoly& poly) {
	return isInSelection(data,data->scene.points[poly.id1]) || isInSelection(data, data->scene.points[poly.id2]);
}


void resetMode() {
	lineModeOn = false;
}

int lastMode = -1;
const double radScaleUp = 4;

std::vector<int> selectPointsByMouse(GuiData* data, int rad = 8) {
	rad *= radScaleUp;
	std::vector<int> points;
	do {
		for (int i = 0; i < data->scene.points.size(); ++i) {
			if (isClicked(data, data->scene.points[i], rad)) {
				points.push_back(i);
			}
		}
		rad--;
	} while (points.size() > 1 && rad >= 0);
	return points;
}

std::vector<int> selectPolysByMouse(GuiData* data) {
	std::vector<int> polys;
	for (int i = 0; i < data->scene.polys.size(); ++i) {
		if (isClicked(data, data->scene.polys[i])) {
			lastSelectedRoom = data->scene.polys[i].roomNr;
			polys.push_back(i);
		}
	}
	return polys;
}

void splitPolyOnMousePos(GuiData* data, int polyToSplit) {
	GuiData::XPoint p = mousePos(data);
	if (data->isPointAlreadyThere(p))
		return;
	int index = data->scene.points.size();
	data->scene.points.push_back(p);
	GuiData::XPoly b = data->scene.polys[polyToSplit];
	data->scene.polys[polyToSplit].id2 = index;
	b.id1 = index;
	b.ceiling_tx1 = (b.ceiling_tx1 + b.ceiling_tx2) * 0.5;
	b.floor_tx1 = (b.floor_tx1 + b.floor_tx2) * 0.5;
	data->scene.polys[polyToSplit].ceiling_tx2 = b.ceiling_tx1;
	data->scene.polys[polyToSplit].floor_tx2 = b.floor_tx1;
	data->addPoly(b);
}

void normalFlip(GuiData* data, int polyToSplit) {
	GuiData::XPoly &b = data->scene.polys[polyToSplit];
	int t = b.id1;
	b.id1 = b.id2;
	b.id2 = t;
	// if normals are flipped only the points are flipped
	//double k = b.ceiling_tx1;
	//b.ceiling_tx1 = b.ceiling_tx2;
	//b.ceiling_tx2 = k;
	//k = b.floor_tx1;
	//b.floor_tx1 = b.floor_tx2;
	//b.floor_tx2 = k;
}

void prepareSelection(GuiData* data, bool removeOld = false) {
	GuiData::XPoint m = mousePos(data);
	data->selectedPoints.clear();
	data->selectedPolys.clear();
	std::map<int, int> remap;
	double midX = 0, midY = 0;
	int midC = 0;

	for (int i = 0; i < data->scene.points.size(); ++i) {
		if (data->scene.points[i].selected) {
			remap.insert(std::make_pair(i, data->selectedPoints.size()));
			GuiData::XPoint p = data->scene.points[i];
			midX += p.x;
			midY += p.y;
			midC++;
			data->selectedPoints.push_back(p);
		}
	}
	if (midC != 0) {
		midX /= midC;
		midY /= midC;
	}
	for (int i = 0; i < data->selectedPoints.size(); ++i) {
		data->selectedPoints[i].x -= midX - m.x;
		data->selectedPoints[i].y -= midY - m.y;
	}
	for (int i = 0; i < data->scene.polys.size(); ++i) {
		if (data->scene.polys[i].selected) {
			GuiData::XPoly p = data->scene.polys[i];
			if (remap.find(p.id1) != remap.end())
				p.id1 = remap[p.id1] | 0x10000;
			if (remap.find(p.id2) != remap.end())
				p.id2 = remap[p.id2] | 0x10000;
			p.hasRectangle = false;
			p.rectangleNr = -1;
			data->selectedPolys.push_back(p);
		}
	}
	for (int i = data->scene.billboards.size() - 1; i >= 0; --i) {
		GuiData::XBillBoard p = data->scene.billboards[i];
		if (remap.find(p.id) != remap.end()) {
			p.id = remap[p.id] | 0x10000;
			p.hasRectangle = false;
			p.rectangleNr = -1;
			data->selectedBillBoards.push_back(p);
		}
	}

	if (removeOld) {
		for (int i = data->scene.billboards.size() - 1; i >= 0; --i) {
			GuiData::XBillBoard &p = data->scene.billboards[i];
			if (remap.find(p.id) != remap.end()) {
				data->removeBillboard(i);
			}
		}
		for (int i = data->scene.polys.size() - 1; i >= 0; --i) {
			if (remap.find(data->scene.polys[i].id1) != remap.end())
				data->scene.polys[i].selected = true;
			if (remap.find(data->scene.polys[i].id2) != remap.end())
				data->scene.polys[i].selected = true;
		}
		for (int i = data->scene.points.size() - 1; i >= 0; --i) {
			if (data->scene.points[i].selected) {
				data->removePoint(i);
			}
		}
		for (int i = data->scene.polys.size() - 1; i >= 0; --i) {
			if (data->scene.polys[i].selected) {
				data->removePoly(i);
			}
		}
	}
	for (int i = data->scene.points.size() - 1; i >= 0; --i) {
		data->scene.points[i].selected = false;
	}
	for (int i = data->scene.polys.size() - 1; i >= 0; --i) {
		data->scene.polys[i].selected = false;
	}
}

void clearSelections(GuiData* data) {
	for (int i = 0; i < data->scene.points.size(); ++i)
		data->scene.points[i].selected = false;
	for (int i = 0; i < data->scene.polys.size(); ++i)
		data->scene.polys[i].selected = false;
	data->selectedPolys.clear();
	data->selectedPoints.clear();
	data->selectedBillBoards.clear();
}

void endObjectMoveMode(GuiData *data, bool placeIt = true) {
	selectionToSecondPosOn = false;
	if (placeIt) {
		std::map<int, int> remap;
		for (int i = 0; i < data->selectedPoints.size(); ++i) {
			GuiData::XPoint point = data->selectedPoints[i];
			int id = data->pointThere(point);
			if (id < 0) {
				data->scene.points.push_back(point);
				id = data->scene.points.size() - 1;
			}
			remap[i] = id;
		}
		for (int i = 0; i < data->selectedPolys.size(); ++i) {
			GuiData::XPoly poly = data->selectedPolys[i];
			if (((poly.id1 & 0x10000)!=0) && remap.find(poly.id1 & 0xffff) != remap.end())
				poly.id1 = remap[poly.id1 & 0xffff];
			if (((poly.id2 & 0x10000)!=0) && remap.find(poly.id2 & 0xffff) != remap.end())
				poly.id2 = remap[poly.id2 & 0xffff];
			data->addPoly(poly);
		}
		for (int i = 0; i < data->selectedBillBoards.size(); ++i) {
			GuiData::XBillBoard bboard = data->selectedBillBoards[i];
			if (((bboard.id & 0x10000) != 0) && remap.find(bboard.id & 0xffff) != remap.end())
				bboard.id = remap[bboard.id & 0xffff];
			data->scene.billboards.push_back(bboard);
		}
	}
	clearSelections(data);
}

void expandSelectionToConnectedPolygons(GuiData* data) {
	bool somethingLeftToDo ;
	std::set<int> portalPoints;
	for (int x = 0; x < data->scene.polys.size(); ++x) {
		GuiData::XPoly& p1 = data->scene.polys[x];
		if (p1.portal) {
			portalPoints.insert(p1.id1);
			portalPoints.insert(p1.id2);
		}
	}

	do {
		somethingLeftToDo = false;
		for (int x = 0; x < data->scene.polys.size(); ++x) {
			GuiData::XPoly& p1 = data->scene.polys[x];
			if (p1.selected) {
				for (int y = 0; y < data->scene.polys.size(); ++y) {
					GuiData::XPoly& p2 = data->scene.polys[y];
					if ((!p2.selected) && (p2.id1 == p1.id1 || p2.id2 == p1.id1 || p2.id1 == p1.id2 || p2.id2 == p1.id2)) {
						//if (portalPoints.find(p2.id1) == portalPoints.end() && portalPoints.find(p2.id2) == portalPoints.end()) {
						if ((p1.hasFloor && p2.hasFloor && p1.textureFloor == p2.textureFloor) ||
							(p2.hasCeiling && p2.hasCeiling && p1.textureCeiling == p2.textureCeiling)) {
							p2.selected = true;
							somethingLeftToDo = true;
						}
					}
				}
			}
		}
	} while (somethingLeftToDo);
}


void vertexMode(GuiData* data) {
	if (g::GetIO().MouseWheel != 0 && g::IsWindowHovered()) {
		double fluid = 0.2;
		GuiData::XPoint before = mousePos(data);
		data->scene.zoom += g::GetIO().MouseWheel < 0 ? fluid : -fluid;
		if (data->scene.zoom < -6.0) // magnification
			data->scene.zoom = -6.0;
		if (data->scene.zoom > 6.0) // minification
			data->scene.zoom = 6.0;
		GuiData::XPoint after = mousePos(data);
		data->scene.center.x += (after.x - before.x);
		data->scene.center.y += (after.y - before.y);
	}
	if (g::GetIO().MouseDown[2] && g::IsWindowHovered()) {
		int dx = (g::GetIO().MousePos.x - moveStartMouseX) * getZoom(data);
		int dy = (g::GetIO().MousePos.y - moveStartMouseY) * getZoom(data);
		data->scene.center.x = moveStartCenterX + dx;
		data->scene.center.y = moveStartCenterY + dy;
	}
	else {
		moveStartMouseX = g::GetIO().MousePos.x;
		moveStartMouseY = g::GetIO().MousePos.y;
		moveStartCenterX = data->scene.center.x;
		moveStartCenterY = data->scene.center.y;
	}

	if (g::GetIO().KeyShift || g::GetIO().KeyCtrl || g::GetIO().KeyAlt && g::IsWindowHovered()) {
		if (!selectModeOn) {
			if (g::GetIO().KeyShift) {
				clearSelections(data);
			}
			GuiData::XPoint point = mousePos(data);
			selectModeOn = true;
			selectionStartX = point.x;
			selectionStartY = point.y;
			selectionEndX = point.x;
			selectionEndY = point.y;
			selectModeAdd = g::GetIO().KeyShift || g::GetIO().KeyAlt;
		}
		else {
			GuiData::XPoint point = mousePos(data);
			selectionEndX = point.x;
			selectionEndY = point.y;
		}
		return;
	}
	else {
		if (selectionToSecondPosOn) {
			GuiData::XPoint pt = mousePos(data);
			int dx = pt.x - selectionToSecondPosOnStartX;
			int dy = pt.y - selectionToSecondPosOnStartY;
			selectionToSecondPosOnStartX = pt.x;
			selectionToSecondPosOnStartY = pt.y;
			for (int i = 0; i < data->selectedPoints.size(); ++i) {
				if (data->selectedPoints[i].selected) {
					data->selectedPoints[i].x += dx;
					data->selectedPoints[i].y += dy;
				}
			}
		}
		if (selectModeOn) {
			for (int i = 0; i < data->scene.points.size(); ++i) {
				if (isInSelection(data, data->scene.points[i]))
					data->scene.points[i].selected = selectModeAdd;
			}
			for (int i = 0; i < data->scene.polys.size(); ++i) {
				if (isInSelection(data, data->scene.polys[i]))
					data->scene.polys[i].selected = selectModeAdd;
			}
		}
		selectModeOn = false;
	}
	if (g::GetIO().MouseClicked[0] && g::IsWindowHovered()) {
		endObjectMoveMode(data, true);
		lineModeOn = false;
		keepMouseX = false;
		keepMouseY = false;
		std::vector<int> polys = selectPolysByMouse(data);
		std::vector<int> points = selectPointsByMouse(data);
		for (int i = 0; i < polys.size(); ++i)
			data->scene.polys[polys[i]].selected = true;
		for (int i = 0; i < points.size(); ++i)
			data->scene.points[points[i]].selected = true;
	}

	if (g::GetIO().MouseClicked[1] && g::IsWindowHovered()) {
		endObjectMoveMode(data, true);
		clearSelections(data);
		std::vector<int> k = selectPointsByMouse(data);
		if (!k.empty()) {
			int p = k[selectionCycler % k.size()];
			selectionCycler++;
			if (lineModeOn) {
				int p1 = lineModeStartPoint;
				int p2 = p;
				if (
					(unsigned int)p1 < data->scene.points.size() &&
					(unsigned int)p2 < data->scene.points.size()
					) {
					bool already = false;
					for (int i = 0; i < data->scene.polys.size(); ++i) {
						GuiData::XPoly pl = data->scene.polys[i];
						if (pl.id1 == p1 && pl.id2 == p2)
							already = true;
						if (pl.id1 == p2 && pl.id2 == p1)
							already = true;
					}
					if (!already) {
						GuiData::XPoly newPoly;
						newPoly.id1 = p1;
						newPoly.id2 = p2;
						newPoly.roomNr = lastSelectedRoom;
						data->addPoly(newPoly);
					}
				}
				lineModeStartPoint = p;
			}
			else {
				if ((unsigned int)(p) < data->scene.points.size()) {
					lineModeOn = true;
					lineModeStartPoint = p;
				}
				else {
					lineModeOn = false;
				}
			}
		}
	}

	int currentChar = 0x00;
	if (!g::GetIO().InputQueueCharacters.empty())
		currentChar = g::GetIO().InputQueueCharacters[0];
	if (currentChar != lastChar) {
		lastChar = currentChar;
		switch (currentChar) {
		case L'+': {
			data->engine.playerRotation += 0x100;
			break;
		}
		case L'-': {
			data->engine.playerRotation -= 0x100;
			break;
		}
		case L'p': {
			GuiData::XPoint newPoint = mousePos(data);
			data->engine.playerPosX = newPoint.x;
			data->engine.playerPosY = newPoint.y;
			break;
		}
		case L'a': {
			// add point
			bool already = false;
			GuiData::XPoint newPoint = mousePos(data);
			if (!data->isPointAlreadyThere(newPoint)) {
				data->addPoint(newPoint);
			}
			break;
		}
		case L'b': {
			// add billboard (with vertex)
			bool already = false;
			GuiData::XPoint newPoint = mousePos(data);
			if (!data->isPointAlreadyThere(newPoint)) {
				int id = data->addPoint(newPoint);
				GuiData::XBillBoard bboard;
				bboard.id = id;
				data->scene.billboards.push_back(bboard);
			}
			break;
		}
		case L'd': {
			prepareSelection(data, true); // hack to delete all selected stuff
			endObjectMoveMode(data, false); // hack to delete all selected stuff
			std::vector<int> k = selectPointsByMouse(data);
			if (!k.empty()) {
				data->removePoint(k[selectionCycler % k.size()]);
				selectionCycler++;
			}
			else {
				std::vector<int> k = selectPolysByMouse(data);
				if (!k.empty()) {
					data->removePoly(k[selectionCyclerPoly % k.size()]);
					selectionCyclerPoly++;
				}
			}
			break;
		}
		case L'x': {
			keepMouseY ^= true;
			keepMouseX = false;
			keepMouseYCoord = mousePos(data, false).y;
			break;
		}
		case L'y': {
			keepMouseX ^= true;
			keepMouseY = false;
			keepMouseXCoord = mousePos(data, false).x;
			break;
		}
		case L'z': {
			std::vector<int> k = selectPointsByMouse(data, 20);
			if (!k.empty()) {
				data->scene.center.x += mousePos(data).x - data->scene.points[k[0]].x;
				data->scene.center.y += mousePos(data).y - data->scene.points[k[0]].y;
			}
			break;
		}
		case L's': {
			GuiData::XPoint pt = mousePos(data);
			int dx = -pt.x;
			int dy = -pt.y;
			for (int i = 0; i < data->scene.points.size(); ++i) {
				data->scene.points[i].x += dx;
				data->scene.points[i].y += dy;
			}
			data->scene.center.x -= dx;
			data->scene.center.y -= dy;
			break;
		}
		case L't': {
			std::vector<int> k = selectPolysByMouse(data);
			if (!k.empty()) {
				int ply = k[selectionCyclerPoly % k.size()];
				selectionCyclerPoly++;
				splitPolyOnMousePos(data, ply);
			}
			break;
		}
		case L'u': {
			std::vector<GuiData::XPoly *> polies = data->collectAllSelectedPolys();
			std::map<int, int> pointCounts;
			for (auto &a : polies) {
				pointCounts[a->id1]++;
				pointCounts[a->id2]++;
			}
			std::vector<int> r;
			for (auto& a : pointCounts) {
				if (a.second == 1) {
					r.push_back(a.first);
				}
			}
			if (r.size() == 2) {
				for (int i = 0; i < polies.size(); ++i) {
					if (polies[i]->id1 == r[0]) {
						polies[i]->id2 = r[1];
						polies.erase(polies.begin() + i);
						break;
					}
					if (polies[i]->id2 == r[0]) {
						polies[i]->id1 = r[1];
						polies.erase(polies.begin() + i);
						break;
					}
				}
				data->removePolys(polies);
			}
			break;
		}
		case L'i': {
			std::vector<int> k = selectPolysByMouse(data);
			if (!k.empty()) {
				int ply = k[selectionCyclerPoly % k.size()];
				selectionCyclerPoly++;
				normalFlip(data, ply);
			}
			break;
		}
		case L'm': {
			bool doIt = false;
			for (int i = 0; i < data->scene.points.size(); ++i)
				if (data->scene.points[i].selected) {
					doIt = true;
					break;
				}
			if (!selectionToSecondPosOn && doIt) {
				selectionToSecondPosOn = true;
				GuiData::XPoint pt = mousePos(data);
				selectionToSecondPosOnStartX = pt.x;
				selectionToSecondPosOnStartY = pt.y;
				prepareSelection(data, true);
			}
			break;
		}
		case L'c': {
			bool doIt = false;
			for (int i = 0; i < data->scene.points.size(); ++i)
				if (data->scene.points[i].selected) {
					doIt = true;
					break;
				}
			if (!selectionToSecondPosOn) {
				selectionToSecondPosOn = true;
				GuiData::XPoint pt = mousePos(data);
				selectionToSecondPosOnStartX = pt.x;
				selectionToSecondPosOnStartY = pt.y;
				prepareSelection(data, false);
			}
			break;
		}
		case L'e': {
			expandSelectionToConnectedPolygons(data);
			break;
		}
		}
	}

	if (lineModeOn) {
		if ((unsigned int)(lineModeStartPoint) < data->scene.points.size()) {
			ImVec2 p1 = xPoint(data, data->scene.points[lineModeStartPoint]);
			ImVec2 p2 = xPoint(data, mousePos(data));
			g::GetWindowDrawList()->AddLine(ImVec2(p1.x, p1.y), ImVec2(p2.x, p2.y), IM_COL32(255, 255, 255, 255), 1.0);
		}
	}
}

void paint_2dplanar(GuiData* data) {
	if (data->editMode != lastMode) {
		lastMode = data->editMode;
		resetMode();
	}
	
	g::SetNextWindowSize(ImVec2(640, 480), ImGuiCond_FirstUseEver);
	g::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1));

	int windowFlags = 0;
	if (g::GetIO().KeyShift) {
		windowFlags |= ImGuiWindowFlags_NoMove;
	}
	g::Begin("2D Plane View", nullptr, windowFlags);
	g::Text("zoom:%f", data->scene.zoom);
	int mx = mousePos(data).x;
	int my = mousePos(data).y;
	g::Text("mouse:<%d,%d>", mx, my);
	paintBspSplitPlanes(data);
	paintBoundingBox(data);
	paintCenterCross(data);
	paint2DPlayer(data);
	for (int i = 0; i < data->scene.polys.size(); ++i) {
		GuiData::XPoly p = data->scene.polys[i];
		uint32_t color = IM_COL32(255, 255, 255, 63);
		if (p.selected) {
			color = IM_COL32(0, 155, 155, 255);
		}
		if (isInSelection(data, p)) {
			color = IM_COL32(0, 255, 255, 255);
		}
		if (isClicked(data, p)) {
			color = IM_COL32(255, 0, 0, 255);
		}
		if (p.roomNr == data->highlighRoomNr && data->highlighRoomNr >= 0) {
			color = IM_COL32(255, 255, 128, 255);
		}
		if (p.portal) {
			if (p.portalRoomNrBack == data->highlighRoomNr && data->highlighRoomNr >= 0) {
				color = IM_COL32(255, 255, 128, 255);
			}
		}
		int nr = p.rectangleNr;
		if (nr >= 0) {
			GuiData::XRect* rect = &(data->scene.rectangles[nr]);
			rect->roomNr = p.roomNr;
			if (p.portal)
				rect->portalRoomNrBack = p.portalRoomNrBack;
			else
				rect->portalRoomNrBack = -1;
			rect->polyNr = i;
			rect->id1 = p.id1;
			rect->id2 = p.id2;
		}

		paint2DPoly(data, p, color);
	}
	for (int i = 0; i < data->scene.points.size(); ++i) {
		GuiData::XPoint p = data->scene.points[i];
		uint32_t color = IM_COL32(255, 255, 255, 63);
		if (p.selected) {
			color = IM_COL32(0, 155, 155, 255);
		}
		if (isInSelection(data, p)) {
			color = IM_COL32(0, 255, 255, 255);
		}
		if (isClicked(data, p))
			color = IM_COL32(255, 0, 0, 255);
		paint2DPoint(data, p, color);

		for (int j = 0; j < data->scene.billboards.size(); ++j) {
			if (data->scene.billboards[j].id == i) {
				data->scene.billboards[j].color = color; // selection state and so on
			}
		}
	}

	for (int i = 0; i < data->scene.billboards.size(); ++i) {
		GuiData::XBillBoard p = data->scene.billboards[i];
		uint32_t color = p.color;
		if (p.roomNr == data->highlighRoomNr && data->highlighRoomNr >= 0) {
			color = IM_COL32(255, 255, 128, 255);
		}
		int nr = p.rectangleNr;
		if (nr >= 0) {
			GuiData::XRect* rect = &(data->scene.rectangles[nr]);
			rect->roomNr = p.roomNr;
			rect->polyNr = i;
			rect->id1 = p.id;
			rect->id2 = p.id;
		}
		paintBillBoard(data, p, color);
	}

	for (int i = 0; i < data->scene.rectangles.size(); ++i) {
		GuiData::XRect p = data->scene.rectangles[i];
		uint32_t color = IM_COL32(64, 255, 64, 255);
		if (p.roomNr == data->highlighRoomNr || p.portalRoomNrBack == data->highlighRoomNr && data->highlighRoomNr >= 0) {
			color = IM_COL32(255, 255, 128, 255);
		}
		if (p.enabled)
			paintRectangle(data, p, color);
	}

	if (data->selectedPoints.size()) {
		for (int i = 0; i < data->selectedPolys.size(); ++i) {
			GuiData::XPoly p = data->selectedPolys[i];
			uint32_t color = IM_COL32(255, 100, 100, 255);
			paint2DPoly(data, p, color);
		}
	}
	if (data->selectedPolys.size()) {
		for (int i = 0; i < data->selectedPoints.size(); ++i) {
			GuiData::XPoint p = data->selectedPoints[i];
			uint32_t color = IM_COL32(255, 100, 100, 255);
			paint2DPoint(data, p, color);
		}
	}
	if (data->selectedBillBoards.size()) {
		for (int i = 0; i < data->selectedBillBoards.size(); ++i) {
			GuiData::XBillBoard p = data->selectedBillBoards[i];
			uint32_t color = p.color;
			paintBillBoard(data, p, color);
		}
	}

	paintSelectionRect(data);
	paintMouseCursor(data);
	if (data->editMode == MODE_VERTEXMODE)
		vertexMode(data);
	g::End();
	g::PopStyleColor();
}
