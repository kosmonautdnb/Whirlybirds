#pragma once

void paint_3dengine(class GuiData *data);