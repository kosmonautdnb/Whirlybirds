#pragma once

#include <string>
#include <vector>
#include <set>
#include <iostream>
#ifndef STANDALONE
#include "serialize/serialize.h"
#endif

#define IMGUIID_2DPLANAR 1
#define IMGUIID_3DENGINE 2

#define MODE_VERTEXMODE 0

#define SAVE_FILENAME "data/scene.dat"
#define BSP_FILENAMESTEM "bsp"

#ifdef STANDALONE
class SerializeInterface {
public:
	virtual void serialize(class Serializer& ser) {
	}
};
#endif


class GuiData : public SerializeInterface {
public:

	int editMode = MODE_VERTEXMODE;

	class XTexture : public SerializeInterface {
	public:
		std::string fileName;
		std::string binFileName;
		int width = 0, height = 0;
		std::vector<unsigned int> pixels;
		int convertedWidth = 0;
		std::vector<unsigned char> converted;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	class XTextures : public SerializeInterface {
	public:
		std::vector<XTexture> textures;
		unsigned char color0, color1, color2, color3;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	class X3DEngine : public SerializeInterface {
	public:
		int playerPosX, playerPosY;
		int playerRotation;
		int playerHeight = 200 + -127*4;
		virtual void serialize(class Serializer& ser) override;
	};

	class XPoint : public SerializeInterface {
	public:
		XPoint(int x = 0, int y = 0) {
			this->x = x;
			this->y = y;
		}
		bool selected = false;
		int x = -1, y = -1;
		virtual void serialize(class Serializer& ser) override;
	};

	class XRect : public SerializeInterface {
	public:
		int id1 = 0, id2 = 0;
		int expandX = 256;
		int expandY = 256;
		int polyNr = -1;
		int switchType = 0;
		int switchNr = 0;
		int roomNr = 0;
		int portalRoomNrBack = -1;
		bool enabled = true;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	class XPoly : public SerializeInterface {
	public:
		int otherRoomPoly = -1;
		bool editOtherRoomPoly = false;
		bool isOtherRoomPoly = false;
		int id1 = -1, id2 = -1;
		double floor_tx1 = 0, floor_tx2 = 1;
		double ceiling_tx1 = 0, ceiling_tx2 = 1;
		bool hasCeiling = false;
		bool hasFloor = false;
		bool ceilingNormalFlipped = false;
		bool floorWithTransparencies = false;
		bool floorDoubleSided = false;
		bool ceilingDoubleSided = false;
		bool isFloorDoor = false;
		int ceiling_up = 0;
		int ceiling_down = 0;
		int floor_up = 0;
		int floor_down = 0;
		int divisions = 1;
		int textureFloor = 0;
		int textureCeiling = 0;
		int floor_color_up = 0;
		int floor_color_down = 3;
		bool floor_has_start_white_line = true;
		bool floor_color_backface_span = false;
		int ceiling_color_up = 0;
		int ceiling_color_down = 0;
		bool ceiling_color_backface_span = false;
		bool ceiling_has_start_white_line = true;
		bool selected = false;
		int internaltemp = 0;
		bool portal = false;
		bool portalWithSpan = false;
		int roomNr = 0;
		int portalRoomNrBack = 0;
		bool hasRectangle = false;
		int rectangleNr = -1;
		bool hasModifier = false;
		int modifierId = -1;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	class XBBox : public SerializeInterface {
	public:
		double xmin = -32767, ymin = -32767;
		double xmax = 32767, ymax = 32767;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	class XBillBoard : public SerializeInterface {
	public:
		int id = 0;
		int height = 100;
		int width = 255;
		int texture = 0;
		int ground = 0;
		int colorUp = 0;
		int colorDown = 3;
		int roomNr = 0;
		unsigned int color = 0xffffffff;
		bool hasRectangle = false;
		int rectangleNr = -1;
		bool ceilingBillboard = false;
		bool hasModifier = false;
		int modifierId = -1;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	class XScene : public SerializeInterface {
	public:
		XScene() {
		}
		double zoom = -1;
		int rootRoom;
		XPoint center;
		XBBox sceneBound;
		std::vector<XPoly> polys;
		std::vector<XPoint> points;
		std::vector<XBillBoard> billboards;
		std::vector<XRect> rectangles;
		int floorHeight = 127;
		int ceilingHeight = -127;
#ifndef STANDALONE
		virtual void serialize(class Serializer& ser) override;
#endif
	};

	std::vector<XPoint> selectedPoints;
	std::vector<XPoly> selectedPolys;
	std::vector<XBillBoard> selectedBillBoards;

	XScene scene;
	X3DEngine engine;
	XTextures textures;

	int highlighRoomNr = -1;
	bool showAllBSPPlanes = false;
	int bspByteSize = 0;
	double texCoordToWorld = 100.0;

	void polyremoved(int p) {
		for (int i = 0; i < scene.rectangles.size(); ++i) {
			if (scene.rectangles[i].polyNr == p) {
				scene.rectangles[i].polyNr = -1;
			}
			else {
				if (scene.rectangles[i].polyNr > p) {
					scene.rectangles[i].polyNr--;
				}
			}
		}
		for (int i = 0; i < scene.polys.size(); ++i) {
			if (scene.polys[i].otherRoomPoly == p) {
				scene.polys[i].otherRoomPoly = -1;
			}
			else {
				if (scene.polys[i].otherRoomPoly > p) {
					scene.polys[i].otherRoomPoly--;
				}
			}
		}
	}

	void rectangleremoved(int p) {
		for (int i = 0; i < scene.polys.size(); ++i) {
			if (scene.polys[i].rectangleNr == p) {
				scene.polys[i].rectangleNr = -1;
			}
			else {
				if (scene.polys[i].rectangleNr > p) {
					scene.polys[i].rectangleNr--;
				}
			}
		}
		for (int i = 0; i < scene.billboards.size(); ++i) {
			if (scene.billboards[i].rectangleNr == p) {
				scene.billboards[i].rectangleNr = -1;
			}
			else {
				if (scene.billboards[i].rectangleNr > p) {
					scene.billboards[i].rectangleNr--;
				}
			}
		}
	}

	void removePoly(int p) {
		scene.polys.erase(scene.polys.begin() + p);
		polyremoved(p);
	}

	void removeBillboard(int p) {
		//removePoint(scene.billboards[p].id);
		scene.billboards.erase(scene.billboards.begin() + p);
	}

	void removePolys(std::vector<GuiData::XPoly *> polies) {
		for (int i = scene.polys.size() - 1; i >= 0; --i) {
			scene.polys[i].internaltemp = 0;
		}
		for (auto&& a : polies) {
			a->internaltemp = 1;
		}
		for (int i = scene.polys.size() - 1; i >= 0; --i) {
			if (scene.polys[i].internaltemp != 0) {
				removePoly(i);
			}
		}
	}

	void removePoint(int p) {
		scene.points.erase(scene.points.begin() + p);
		for (int i = scene.polys.size() - 1; i >= 0; --i) {
			GuiData::XPoly& poly = scene.polys[i];
			bool erase = false;
			if (poly.id1 == p)
				erase = true;
			if (poly.id2 == p)
				erase = true;
			if (poly.id1 > p)
				poly.id1--;
			if (poly.id2 > p)
				poly.id2--;
			if (erase) {
				scene.polys.erase(scene.polys.begin() + i);
				polyremoved(i);
			}
		}
		for (int i = selectedPolys.size() - 1; i >= 0; --i) {
			GuiData::XPoly& poly = selectedPolys[i];
			bool erase = false;
			if (poly.id1 == p && (!(poly.id1 & 0x10000)))
				erase = true;
			if (poly.id2 == p && (!(poly.id2 & 0x10000)))
				erase = true;
			if (poly.id1 > p && (!(poly.id1 & 0x10000)))
				poly.id1--;
			if (poly.id2 > p && (!(poly.id2 & 0x10000)))
				poly.id2--;
			if (erase)
				selectedPolys.erase(selectedPolys.begin() + i);
		}
		for (int i = scene.billboards.size() - 1; i >= 0; --i) {
			GuiData::XBillBoard& b = scene.billboards[i];
			bool erase = false;
			if (b.id == p && (!(b.id & 0x10000)))
				erase = true;
			if (b.id > p && (!(b.id & 0x10000)))
				b.id--;
			if (erase)
				if (b.id == p)
					scene.billboards.erase(scene.billboards.begin() + i);
		}
		for (int i = scene.rectangles.size() - 1; i >= 0; --i) {
			GuiData::XRect& rect = scene.rectangles[i];
			bool erase = false;
			if (rect.id1 == p && (!(rect.id1 & 0x10000)))
				erase = true;
			if (rect.id2 == p && (!(rect.id2 & 0x10000)))
				erase = true;
			if (rect.id1 > p && (!(rect.id1 & 0x10000)))
				rect.id1--;
			if (rect.id2 > p && (!(rect.id2 & 0x10000)))
				rect.id2--;
			if (erase) {
				scene.rectangles.erase(scene.rectangles.begin() + i);
				rectangleremoved(i);
			}
		}
	}

	int addRectangle() {
		scene.rectangles.push_back(XRect());
		return scene.rectangles.size() - 1;
	}

	int getAddRectangle(int oldPos) {
		if ((unsigned int)oldPos < scene.rectangles.size())
			return oldPos;
		scene.rectangles.push_back(XRect());
		return scene.rectangles.size() - 1;
	}

	int addPoint() {
		scene.points.push_back(XPoint());
		return scene.points.size() - 1;
	}

	int addPoint(const XPoint &p) {
		scene.points.push_back(p);
		return scene.points.size() - 1;
	}

	int addPoly() {
		scene.polys.push_back(XPoly());
		return scene.polys.size() - 1;
	}

	int addPoly(XPoly p, bool flipped = false) {
		if (flipped) {
			XPoly k = p;
			p.id1 = k.id2;
			p.id2 = k.id1;
			p.ceiling_tx1 = k.ceiling_tx2;
			p.ceiling_tx2 = k.ceiling_tx1;
			p.floor_tx1 = k.floor_tx2;
			p.floor_tx2 = k.floor_tx1;
		}
		scene.polys.push_back(p);
		return scene.polys.size() - 1;
	}

	XPoint getPoint(int id) {
		if (id & 0x10000)
			return selectedPoints[id & 0xffff];
		return scene.points[id & 0xffff];
	}

	bool pointDiffers(const GuiData::XPoint& a, const GuiData::XPoint& b) {
		const int dx = a.x - b.x;
		const int dy = a.y - b.y;
		return (abs(dx) > 0) || (abs(dy) > 0);
	}

	int pointThere(const GuiData::XPoint& p) {
		for (int i = 0; i < scene.points.size(); ++i)
			if (!pointDiffers(p, scene.points[i]))
				return i;
		return -1;
	}

	bool isPointAlreadyThere(const GuiData::XPoint& p) {
		return pointThere(p) >= 0;
	}

	std::vector<XPoly*> collectAllSelectedPolys(int& polyNr, bool otherRoomPolysToo = false) {
		std::vector<XPoly*> ret;
		polyNr = -1;
		for (int i = 0; i < scene.polys.size(); ++i)
			if (scene.polys[i].selected) {
				if (scene.polys[i].isOtherRoomPoly)
					if (!otherRoomPolysToo)
						continue;
				ret.push_back(&scene.polys[i]);
				if (polyNr == -1)
					polyNr = i;
				else
					polyNr = -2;
			}
		return ret;
	}
	std::vector<XPoly*> collectAllSelectedPolys() {
		int i = 0;
		return collectAllSelectedPolys(i);
	}

	std::vector<XPoint*> collectAllSelectedPoints(int& pointNr) {
		std::vector<XPoint*> ret;
		pointNr = -1;
		for (int i = 0; i < scene.points.size(); ++i)
			if (scene.points[i].selected) {
				ret.push_back(&scene.points[i]);
				if (pointNr == -1)
					pointNr = i;
				else
					pointNr = -2;
			}
		return ret;
	}

	std::vector<XBillBoard*> collectAllSelectedBillBoards(int& billBoardNr) {
		std::vector<XBillBoard*> ret;
		billBoardNr = -1;
		for (int i = 0; i < scene.points.size(); ++i) {
			if (scene.points[i].selected) {
				for (int j = 0; j < scene.billboards.size(); ++j) {
					if (scene.billboards[j].id == i) {
						ret.push_back(&scene.billboards[j]);
						if (billBoardNr == -1)
							billBoardNr = j;
						else
							billBoardNr = -2;
						break;
					}
				}
			}
		}
		return ret;
	}

	std::vector<XRect*> collectAllSelectedRectangles(int& rectNr) {
		std::vector<XRect*> ret;
		rectNr = -1;
		for (int i = 0; i < scene.rectangles.size(); ++i) {
			int id1 = scene.rectangles[i].id1;
			int id2 = scene.rectangles[i].id2;
			bool selected = (unsigned int)id1 < scene.points.size() ? scene.points[id1].selected : false;
			selected |= (unsigned int)id2 < scene.points.size() ? scene.points[id2].selected : false;
			if (selected) {
				ret.push_back(&scene.rectangles[i]);
				if (rectNr == -1)
					rectNr = i;
				else
					rectNr = -2;
			}
		}
		return ret;
	}
	std::vector<XRect*> collectAllSelectedRectangles() {
		int i = 0;
		return collectAllSelectedRectangles(i);
	}

	XTexture& getTexture(int id) {
		if ((unsigned int)id < textures.textures.size())
			return textures.textures[id];
		return textures.textures[0];
	}

	std::vector<XPoint*> collectAllSelectedPoints() {
		int i = 0;
		return collectAllSelectedPoints(i);
	}

	int textureWidth(int nr) {
		return textures.textures[nr].convertedWidth;
	}

	virtual void serialize(class Serializer& ser) override;
	void load(const std::string& path);
	void save(const std::string& path);
};
