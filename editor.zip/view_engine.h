#pragma once

void paint_engine(class GuiData *data);