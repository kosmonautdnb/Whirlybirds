#pragma once

#include <vector>
#include <string>

#define MAXWIDTH 4096
#define MAXHEIGHT (4096*2)

extern unsigned int pictureS[MAXWIDTH * MAXHEIGHT];
extern unsigned int pictureWriteOut[MAXWIDTH * MAXHEIGHT];
extern int pictureWidth;
extern int pictureHeight;

class Plus4Bitmap {
public:
	std::string name;
	// !!!!ATTENTION!!!!! textures are currently not deleted
	int width = 0;
	int height = 0;
	std::vector<unsigned char> pixels;
	unsigned int openGLId = 0;
	void upload(bool asC64);
};

class C64Bitmap {
public:
	std::string name;
	// !!!!ATTENTION!!!!! textures are currently not deleted
	int width = 0;
	int height = 0;
	std::vector<unsigned char> pixels;
	unsigned int openGLId = 0;
	void upload();
};

void LoadPNG(const char* png);
void SavePNG(const char* file_name, bool flipped = false);

extern unsigned int palette[256];
void setupPalette(const std::string& paletteKichyPath);
void toPlus4Colors();